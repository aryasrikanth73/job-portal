# **Job Portal Web Application – MVP**

**Project Documentation (Revised Scope)**

---

## **1\. Project Introduction**

### **1.1 Purpose of the System**

This Job Portal MVP is a **basic recruitment platform** that connects Job Seekers and Employers with **essential job posting and application features**.

Due to budget constraints, the system will focus only on **core functionality** required to validate the business idea and launch a minimum viable product (MVP).

---

### **1.2 Target Users**

1. **Job Seekers**

   * Individuals searching for jobs

2. **Employers**

   * Companies posting job openings

3. **Admin**

   * Platform operator for basic control

---

### **1.3 Business Goals**

* Launch a basic job portal quickly

* Test market demand

* Start user onboarding

* Collect feedback for future upgrades

* Minimize initial development cost

---

## **2\. User Roles & Permissions**

### **2.1 Job Seeker**

**Permissions:**

* Register and log in

* Create a basic profile

* Upload one resume

* View job listings

* Apply for jobs

* View applied jobs list

---

### **2.2 Employer**

**Permissions:**

* Register and log in

* Create a basic company profile

* Post job vacancies

* Edit or delete own jobs

* View job applications

### **2.3 Admin**

**Permissions:**

* View all users

* View all jobs

* Delete inappropriate jobs

* Block users

* Basic system settings

---

## **3\. System Features (Reduced)**

### **3.1 Job Seeker Features**

* Signup & login

* Profile creation (basic)

* Resume upload (single file)

* Job browsing

* Job application

* Applied jobs list

* Create profile with:  
  * Skills  
  * Experience  
  * Qualification  
  * Location  
  * Resume upload

* Update profile details

### **3.2 Employer Features**

* Signup & login

* Company profile (basic)

* Job posting

* Job edit & delete

* View applicants list

* Search candidates by:  
  * Skills  
  * Experience  
  * Qualification  
  * Location

* View candidate profiles

* Download/view resumes (based on access level)

**3.3 Employer Access Levels**  

* Free Employer:  
  * Can view unskilled/basic candidate profile

* Paid Employer:  
  * Can view all candidate profiles  
  * Can access candidate resumes

### **3.4 Admin Features**

* Admin login

* View all users

* View all employers

* View all jobs

* Block / unblock users

* Delete jobs

* Create Employer 

* Create Job 

---

## **4\. Page List (Site Map)**

### **4.1 Public Pages**

* Home

* Job Listings

* Job Details

* Login

* Signup

* Contact

* About

* Privacy Policy and T\&C

---

### **4.2 Job Seeker Pages**

* Dashboard

* Profile

* Upload Resume

* Browse Jobs

* My Applications

* Logout

---

### **4.3 Employer Pages**

* Dashboard

* Company Profile

* Post Job

* Manage Jobs

* Job Applications

* Logout

---

### **4.4 Admin Pages**

* Admin Login

* Dashboard

* Manage Users

* Manage Jobs

* Settings

* Logout

---

## **5\. Page Count Summary**

| Role | Pages |
| ----- | ----- |
| Public | 6 |
| Job Seeker | 6 |
| Employer | 6 |
| Admin | 6 |
| **Total** | **24 Pages** |

---

## **6\. Wireframes (Low-Fidelity)**

### **6.1 Home Page**

`-----------------------------------------`  
`| LOGO        Home  Jobs  Login Signup |`  
`-----------------------------------------`  
`| Hero Section: "Find Your Job"         |`  
`| [Search Jobs]                         |`  
`-----------------------------------------`  
`| Latest Jobs                           |`  
`| [Job Card] [Job Card]                 |`  
`-----------------------------------------`  
`| Footer                                |`  
`-----------------------------------------`

---

### **6.2 Job Seeker Signup**

`-----------------------------------------`  
`| LOGO         Signup                   |`  
`-----------------------------------------`  
`| Name | Email | Password               |`  
`| Upload Resume                         |`  
`| [Create Account]                     |`  
`-----------------------------------------`

---

### **6.3 Job Seeker Dashboard**

`-----------------------------------------`  
`| LOGO        Dashboard  Logout        |`  
`-----------------------------------------`  
`| Sidebar:                              |`  
`| - Dashboard                          |`  
`| - Profile                            |`  
`| - Jobs                               |`  
`| - Applications                       |`  
`-----------------------------------------`  
`| Main Content:                        |`  
`| Applied Jobs: 3                      |`  
`| [Browse Jobs]                        |`  
`-----------------------------------------`

---

### **6.4 Employer Dashboard**

`-----------------------------------------`  
`| LOGO        Dashboard  Logout        |`  
`-----------------------------------------`  
`| Sidebar:                              |`  
`| - Dashboard                          |`  
`| - Company Profile                    |`  
`| - Post Job                           |`  
`| - Manage Jobs                        |`  
`-----------------------------------------`  
`| Main Content:                        |`  
`| Active Jobs: 2                       |`  
`| [Post Job]                           |`  
`-----------------------------------------`

---

### **6.5 Job Posting Page**

`-----------------------------------------`  
`| LOGO        Dashboard  Logout        |`  
`-----------------------------------------`  
`| Job Posting Form:                    |`  
`| Job Title                            |`  
`| Description                          |`  
`| Location                             |`  
`| Job Type                             |`  
`| [Post Job]                           |`  
`-----------------------------------------`

---

### **6.6 Admin Dashboard**

`-----------------------------------------`  
`| ADMIN PANEL                          |`  
`-----------------------------------------`  
`| Sidebar:                              |`  
`| - Users                              |`  
`| - Jobs                               |`  
`| - Settings                           |`  
`-----------------------------------------`  
`| Main Content:                        |`  
`| Total Users: 120                     |`  
`| Total Jobs: 40                       |`  
`-----------------------------------------`

---

## 

## **7\. User Flow Diagrams (Text-Based)**

### **7.1 Job Seeker Flow**

`Visit Website`  
   `↓`  
`Signup`  
   `↓`  
`Create Profile`  
   `↓`  
`Upload Resume`  
   `↓`  
`Browse Jobs`  
   `↓`  
`Apply for Job`  
   `↓`  
`View My Applications`

---

### 

### **7.2 Employer Flow**

`Signup / Login`  
   `↓`  
`Create Company Profile`  
   `↓`  
`Post Job`  
   `↓`  
`Search Candidates`  
   `↓`  
`View Candidate Profiles/Resumes`  
   `↓`  
`View Applications`

---

### **7.3 Admin Flow**

`Admin Login`  
   `↓`  
`View Dashboard`  
   `↓`  
`Manage Users`  
   `↓`  
`Manage employers`  
   `↓`  
`Manage Jobs`

## **8\. Technology Stack**

### **Backend**

* Core PHP

### **Frontend**

* HTML

* CSS

* Bootstrap

### **Database**

* MySQL

---

## **9\. Future Upgrade Plan**

Once MVP gains traction, the following enhancements can be added:

* Paid courses module

* Payment gateway

* Laravel migration

* Notifications

* Resume matching

* Employer subscriptions

* Advanced admin panel

* Mobile application

---

## **10\. Project Delivery Summary (Revised)**

| Item | Details |
| ----- | ----- |
| Development Stack | Core PHP \+ MySQL |
| Daily Working Hours | 3 Hours / Day |
| Total Estimated Effort | 60–70 Development Hours |
| Estimated Timeline | **4–6 Weeks** |
| Development Cost | **₹40,000** |
| Domain, Server & SSL | **Client Responsibility (Cost Not Included)**  |
| Future Upgrade Option | Available |

---

## **11\. One-Line Client Commitment**

“This MVP job portal will deliver essential job posting and application features. Advanced monetization and automation features can be added in future upgrade phases.”

