<?php
require_once __DIR__ . '/includes/public_init.php';

$email = trim($_GET['email'] ?? '');
$role = trim($_GET['role'] ?? 'job_seeker');
if (!in_array($role, fp_password_reset_roles(), true)) {
    $role = 'job_seeker';
}

$currentPage = 'forgot-password';
$footerClass = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $email = trim($_POST['email'] ?? '');
    $role = trim($_POST['role'] ?? 'job_seeker');
    if (!in_array($role, fp_password_reset_roles(), true)) {
        $role = 'job_seeker';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fp_flash('danger', 'Enter a valid email address.');
    } else {
        try {
            fp_request_password_reset($email, $role);
            fp_flash('success', 'If an account exists for that email, we sent password reset instructions.');
            fp_redirect('forgot-password.php?email=' . urlencode($email) . '&role=' . urlencode($role));
        } catch (Throwable $exception) {
            fp_flash('danger', $exception->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Finance Port</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <?php include __DIR__ . '/includes/public_chrome_styles.php'; ?>
    <style>
        body { background:#F8FAFC; color:#1E293B; min-height:100vh; }
        .auth-page { padding: 120px 16px 60px; max-width: 520px; margin: 0 auto; }
        .auth-card { background:#fff; border:1px solid var(--border-light); border-radius:24px; padding:40px 32px; box-shadow:0 20px 40px -10px rgba(13,43,78,0.08); }
        .btn-brand { background:var(--primary); color:#fff; border:none; border-radius:14px; padding:14px; font-weight:700; }
        .btn-brand:hover { background:var(--accent); color:#fff; }
        .form-control, .form-select { border-radius:14px; padding:14px 16px; border-color:var(--border-light); }
        .form-control:focus, .form-select:focus { border-color:var(--accent); box-shadow:0 0 0 0.12rem rgba(216,64,0,0.16); }
    </style>
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<main class="auth-page">
    <?php fp_render_flashes(); ?>
    <div class="auth-card">
        <div class="text-center mb-4">
            <div class="text-uppercase small fw-bold text-danger mb-2" style="letter-spacing:0.08em;">Account recovery</div>
            <h1 class="h3 mb-2">Forgot password?</h1>
            <p class="text-muted mb-0">Enter your email and we will send a reset link valid for 1 hour.</p>
        </div>

        <form method="post" action="forgot-password.php" novalidate>
            <?php echo fp_csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label fw-semibold" for="role">Account type</label>
                <select class="form-select" id="role" name="role" style="border-radius:14px;padding:12px 16px;">
                    <option value="job_seeker" <?php echo $role === 'job_seeker' ? 'selected' : ''; ?>>Job Seeker</option>
                    <option value="employer" <?php echo $role === 'employer' ? 'selected' : ''; ?>>Employer</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold" for="email">Email address</label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo e($email); ?>" placeholder="you@example.com" required>
            </div>
            <button class="btn btn-brand w-100" type="submit">
                <i class="fa-solid fa-paper-plane me-2"></i>Send reset link
            </button>
        </form>

        <p class="text-muted text-center mt-4 mb-0 small">
            Remember your password?
            <a class="fw-bold text-decoration-none" style="color:#D84000;" href="<?php echo e(fp_role_login_url($role, $email)); ?>">Back to login</a>
        </p>
    </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php include __DIR__ . '/includes/public_chrome_scripts.php'; ?>
</body>
</html>
