<?php
require_once __DIR__ . '/includes/public_init.php';

$latestJobs = fp_fetch_open_jobs(fp_build_job_filters(array()), 4, 0);
$totalOpenJobs = fp_count_open_jobs(fp_build_job_filters(array()));
$currentPage = 'home';
$footerClass = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Port | Premium Accounting & Finance Recruitment</title>
    
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    
    <style>
        /* =========================================
        DESIGN SYSTEM & VARIABLES
        ========================================= */
        :root {
            --primary: #071126;         /* Deep Navy */
            --secondary: #1E63FF;       /* Royal Blue */
            --accent: #D84000;          /* Deep Orange */
            --accent-light: #FF8C42;    /* Light Orange */
            --bg-base: #FFFFFF;         /* White */
            --bg-light: #F8FAFC;        /* Light Gray/Blue background */
            
            --text-main: #1E293B;       /* Slate 800 - Main Text */
            --text-muted: #64748B;      /* Slate 500 - Secondary Text */
            
            --border-light: #E2E8F0;    /* Soft borders */
            --border-accent: rgba(216, 64, 0, 0.3);
            
            --radius-lg: 24px;
            --radius-md: 16px;
            --radius-sm: 8px;
            
            --shadow-sm: 0 4px 6px -1px rgba(13, 43, 78, 0.05);
            --shadow-md: 0 10px 30px -5px rgba(13, 43, 78, 0.08);
            --shadow-lg: 0 20px 40px -10px rgba(13, 43, 78, 0.12);
            --shadow-glow: 0 0 20px rgba(216, 64, 0, 0.3);
            
            --transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* Strict Overflow Control */
        html, body {
            overflow-x: hidden;
            width: 100%;
            max-width: 100vw;
            position: relative;
        }

        body {
            background-color: var(--bg-base);
            color: var(--text-main);
            font-family: 'Inter', sans-serif;
            -webkit-font-smoothing: antialiased;
        }

        /* Typography */
        h1, h2, h3, h4, h5, h6 {
            font-weight: 700;
            color: var(--primary);
            letter-spacing: -0.02em;
        }
        
        h2 { font-size: clamp(1.75rem, 4vw, 2.75rem) !important; }

        .text-gradient {
            background: linear-gradient(135deg, #D84000 0%, #FF7A4D 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .text-primary-custom { color: var(--primary) !important; }
        .text-accent { color: var(--accent) !important; }

        /* Responsive Fluid Spacing System */
        .section-py { padding-top: clamp(40px, 8vw, 100px); padding-bottom: clamp(40px, 8vw, 100px); }
        .section-mt { margin-top: clamp(30px, 5vw, 80px); }
        .section-mb { margin-bottom: clamp(30px, 5vw, 80px); }
        .bg-alternate { background-color: var(--bg-light); }

        /* Utilities */
        .premium-card {
            background: var(--bg-base);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
        }

        .premium-card:hover {
            border-color: rgba(13, 43, 78, 0.2);
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
        }

        /* Buttons */
        .btn-premium {
            background: var(--accent);
            color: white;
            border: 1px solid var(--accent);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            text-align: center;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            white-space: nowrap;
        }

        .btn-premium:hover {
            background: #A83000;
            border-color: #A83000;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(13, 43, 78, 0.2);
            color: white;
        }

        .btn-outline-custom {
            background: transparent;
            color: var(--primary);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            white-space: nowrap;
        }

        .btn-outline-custom:hover {
            background: var(--bg-light);
            border-color: var(--primary);
            color: var(--primary);
        }

        /* =========================================
        NAVBAR
        ========================================= */
        .navbar-premium {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-light);
            padding: 16px 0; 
            transition: background-color 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease; 
            box-shadow: var(--shadow-sm);
        }
        .navbar-brand {
            font-weight: 800;
            font-size: clamp(1.2rem, 3vw, 1.5rem);
            color: var(--primary) !important;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: color 0.3s ease;
        }
        .brand-dot {
            width: clamp(10px, 2vw, 14px);
            height: clamp(10px, 2vw, 14px);
            background: var(--accent);
            border-radius: 50%;
        }
        .nav-link {
            color: var(--text-muted) !important;
            font-weight: 600;
            font-size: 0.95rem;
            margin: 0 12px;
            transition: color 0.3s ease;
        }
        .nav-link:hover, .nav-link.active {
            color: var(--accent) !important;
        }
        
        /* SCROLLED NAVBAR STATE */
        .navbar-scrolled {
            background: rgba(13, 43, 78, 0.98) !important; 
            box-shadow: 0 10px 30px rgba(13, 43, 78, 0.2) !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
        }
        .navbar-scrolled .navbar-brand { color: #FFFFFF !important; }
        .navbar-scrolled .nav-link { color: rgba(255, 255, 255, 0.8) !important; }
        .navbar-scrolled .nav-link:hover, .navbar-scrolled .nav-link.active { color: var(--accent-light) !important; }
        .navbar-scrolled .btn-outline-custom {
            color: #FFFFFF !important;
            border-color: rgba(255, 255, 255, 0.4) !important;
        }
        .navbar-scrolled .btn-outline-custom:hover {
            background: rgba(255, 255, 255, 0.1) !important;
            border-color: #FFFFFF !important;
            color: #FFFFFF !important;
        }
        .navbar-scrolled .navbar-toggler { border-color: rgba(255, 255, 255, 0.3) !important; }
        .navbar-scrolled .navbar-toggler-icon { filter: brightness(0) invert(1); }
        
        @media (max-width: 991px) {
            .navbar-collapse {
                background: var(--bg-base);
                border: 1px solid var(--border-light);
                border-radius: var(--radius-md);
                padding: 20px;
                box-shadow: var(--shadow-lg);
                position: absolute;
                top: 100%;
                left: 15px;
                right: 15px;
                margin-top: 10px;
                max-height: calc(100vh - 80px);
                overflow-y: auto;
                z-index: 1050;
            }
            .navbar-nav { margin-bottom: 20px; }
            .nav-link { margin: 8px 0; font-size: 1.1rem; }
            .navbar-scrolled .navbar-collapse {
                background: var(--primary);
                border-color: rgba(255, 255, 255, 0.1);
            }
        }

        /* =========================================
        SECTION 1: HERO & MARKETPLACE VISUALIZATION
        ========================================= */
        .hero-section {
            background-color: var(--primary);
            height: 100vh; /* Force exact viewport height */
            min-height: 600px; /* Prevent collapse on extremely tiny screens */
            display: flex;
            align-items: center;
            position: relative;
            padding-top: 80px; /* Clear fixed navbar */
            padding-bottom: 0;
            overflow: hidden;
            color: white;
        }

        .hero-container {
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            padding-top: clamp(20px, 4vh, 50px);
        }
        
        /* NEW HERO TEXT STYLES */
        .hero-badge {
            background: white;
            color: var(--secondary); /* Blue color matching the image */
            padding: clamp(6px, 1.5vw, 10px) clamp(16px, 3vw, 24px);
            border-radius: 50px;
            font-size: clamp(0.7rem, 1.5vw, 0.85rem);
            font-weight: 800;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            display: inline-block;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .hero-title {
            line-height: 1.1;
            letter-spacing: -0.02em;
            margin-bottom: 0;
            text-align: center;
        }

        .hero-title-line1 {
            display: block;
            font-size: clamp(1.2rem, 4vw, 4.5rem);
            white-space: nowrap; /* Forces exactly 1 line */
            color: white;
        }

        .hero-title-line2 {
            display: block;
            font-size: clamp(1.8rem, 6vw, 5.5rem);
            white-space: nowrap; /* Forces exactly 1 line */
            color: var(--accent);
        }
                
        .hero-pattern {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-image: linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            opacity: 0.5;
            pointer-events: none;
        }

        /* Ambient Glowing Orbs */
        .hero-glow {
            position: absolute;
            width: 60vw;
            height: 60vw;
            background: radial-gradient(circle, rgba(216, 64, 0, 0.15) 0%, transparent 70%);
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            pointer-events: none;
            z-index: 0;
            animation: pulseGlow 8s infinite alternate;
        }

        @keyframes pulseGlow {
            0% { opacity: 0.6; transform: translate(-50%, -50%) scale(1); }
            100% { opacity: 1; transform: translate(-50%, -50%) scale(1.1); }
        }

        /* 100% Responsive Grid System that dynamically fills remaining vertical space */
        .node-container {
            position: relative;
            display: block;
            width: 100%;
            max-width: 1000px;
            flex-grow: 1; /* Automatically expands to fill space below text */
            margin: clamp(10px, 2vh, 30px) auto 20px auto;
            z-index: 10;
        }

        .svg-lines {
            display: block;
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            z-index: 1;
            pointer-events: none;
        }
        
        .svg-lines path {
            stroke: rgba(255, 255, 255, 0.15); /* Light visible line on dark background */
            stroke-width: 2.5;
            fill: none;
            stroke-dasharray: 8 8;
            animation: dash 25s linear infinite;
        }

        .center-node {
            position: absolute;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            width: clamp(110px, 20vw, 180px);
            height: clamp(110px, 20vw, 180px);
            background: linear-gradient(135deg, var(--accent) 0%, #FF6B00 100%);
            border: clamp(2px, 0.5vw, 4px) solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        /* Central Pulse Ripple Effect */
        .center-node::before {
            content: '';
            position: absolute;
            top: -10%; left: -10%; right: -10%; bottom: -10%;
            border-radius: 50%;
            border: 2px solid var(--accent);
            opacity: 0;
            animation: ripple 2.5s cubic-bezier(0.21, 0.53, 0.56, 0.8) infinite;
            z-index: -1;
        }

        @keyframes ripple {
            0% { transform: scale(0.8); opacity: 0.8; }
            100% { transform: scale(1.4); opacity: 0; }
        }

        .center-node:hover {
            box-shadow: 0 0 80px rgba(216, 64, 0, 0.9);
            border-color: white;
            transform: translate(-50%, -50%) scale(1.05);
        }
        
        .center-node span { 
            font-weight: 800; 
            font-size: clamp(0.9rem, 2vw, 1.4rem); 
            color: white;
            line-height: 1.1;
            text-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        .orbit-node {
            position: absolute;
            padding: clamp(8px, 1.5vw, 16px) clamp(12px, 3vw, 24px);
            border-radius: 40px;
            
            /* Premium Glassmorphism */
            background: rgba(255, 255, 255, 0.04);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-top: 1px solid rgba(255, 255, 255, 0.25); /* Top highlight */
            box-shadow: 0 16px 32px rgba(0, 0, 0, 0.2), inset 0 0 12px rgba(255, 255, 255, 0.03);
            
            font-size: clamp(0.65rem, 1.8vw, 1rem);
            font-weight: 600;
            color: white;
            white-space: nowrap; 
            z-index: 2;
            transition: border-color 0.4s ease, background 0.4s ease, transform 0.4s ease;
            transform: translate(-50%, -50%); /* Absolute centering anchor */
        }

        .orbit-node:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.4);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3), inset 0 0 20px rgba(255, 255, 255, 0.1);
            transform: translate(-50%, -50%) scale(1.05); /* Maintain center point on scale */
        }

        /* Absolute Positions matching exact SVG path endpoints to guarantee perfect alignment */
        .on-1 { left: 20%; top: 25%; animation: floatTL 5s ease-in-out infinite; }
        .on-2 { left: 80%; top: 25%; animation: floatTR 6s ease-in-out infinite reverse; }
        .on-3 { left: 25%; top: 75%; animation: floatBL 7s ease-in-out infinite; }
        .on-4 { left: 75%; top: 75%; animation: floatBR 5.5s ease-in-out infinite reverse; }

        @keyframes dash { to { stroke-dashoffset: 1000; } }
        
        /* Animating 'top' coordinates directly ensures it never breaks the translate(-50%,-50%) centering */
        @keyframes floatTL { 0%, 100% { top: 25%; } 50% { top: calc(25% - 10px); } }
        @keyframes floatTR { 0%, 100% { top: 25%; } 50% { top: calc(25% - 10px); } }
        @keyframes floatBL { 0%, 100% { top: 75%; } 50% { top: calc(75% - 10px); } }
        @keyframes floatBR { 0%, 100% { top: 75%; } 50% { top: calc(75% - 10px); } }

        .svg-lines {
            display: block;
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            z-index: 1;
            pointer-events: none;
        }
        
        .svg-lines path {
            stroke: rgba(255, 255, 255, 0.15); /* Light visible line on dark background */
            stroke-width: 2.5;
            fill: none;
            stroke-dasharray: 8 8;
            animation: dash 25s linear infinite;
        }

        .center-node {
            position: absolute;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            width: clamp(90px, 20vw, 180px);
            height: clamp(90px, 20vw, 180px);
            background: var(--accent);
            border: clamp(2px, 0.5vw, 4px) solid rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10;
            box-shadow: 0 0 clamp(20px, 5vw, 50px) rgba(216, 64, 0, 0.4);
            text-align: center;
            transition: box-shadow 0.3s ease, border-color 0.3s ease;
        }
        
        .center-node:hover {
            box-shadow: 0 0 70px rgba(216, 64, 0, 0.8);
            border-color: rgba(255, 255, 255, 0.5);
        }
        
        .center-node span { 
            font-weight: 800; 
            font-size: clamp(0.7rem, 2vw, 1.4rem); 
            color: white;
            line-height: 1.1;
        }
        
        .orbit-node {
            position: absolute;
            padding: clamp(6px, 1.5vw, 16px) clamp(8px, 2vw, 24px);
            border-radius: 30px;
            /* Premium Dark Glassmorphism */
            background: rgba(255, 255, 255, 0.06);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            font-size: clamp(0.55rem, 1.5vw, 1.1rem);
            font-weight: 600;
            color: white;
            text-align: center;
            width: max-content; 
            max-width: clamp(110px, 26vw, 240px); /* Controlled width prevents arbitrary expansion */
            white-space: normal;
            z-index: 2;
            transform: translate(-50%, -50%) scale(1); /* Absolute centering anchor */
            transition: transform 0.4s ease, border-color 0.4s ease;
        }

        .orbit-node:hover {
            transform: translate(-50%, -50%) scale(1.05);
            border-color: var(--accent-light);
            background: rgba(255, 255, 255, 0.1);
        }

        /* Positions matching exact SVG path endpoints to guarantee alignment across all devices */
        .on-1 { left: 20%; top: 30%; animation: float1 5s ease-in-out infinite; }
        .on-2 { left: 80%; top: 30%; animation: float2 6s ease-in-out infinite reverse; }
        .on-3 { left: 30%; top: 75%; animation: float3 7s ease-in-out infinite; }
        .on-4 { left: 70%; top: 75%; animation: float4 5.5s ease-in-out infinite reverse; }

        @keyframes dash { to { stroke-dashoffset: 1000; } }
        
        /* Animating 'top' coordinates directly ensures it never breaks the translate(-50%,-50%) centering */
        @keyframes float1 { 0%, 100% { top: 30%; } 50% { top: calc(30% - 15px); } }
        @keyframes float2 { 0%, 100% { top: 30%; } 50% { top: calc(30% - 15px); } }
        @keyframes float3 { 0%, 100% { top: 75%; } 50% { top: calc(75% - 15px); } }
        @keyframes float4 { 0%, 100% { top: 75%; } 50% { top: calc(75% - 15px); } }

        .section-tag {
            display: inline-block;
            padding: 6px 16px;
            background: rgba(216, 64, 0, 0.1);
            color: var(--accent);
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            margin-bottom: 16px;
            border: 1px solid var(--border-accent);
        }

        /* =========================================
        CAREER INTELLIGENCE (BENTO)
        ========================================= */
        .bento-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: clamp(16px, 3vw, 24px);
        }
        
        @media (min-width: 768px) {
            .bento-grid { grid-template-columns: repeat(2, 1fr); }
            .bento-col-8, .bento-col-4 { grid-column: span 1; }
            .bento-col-12 { grid-column: span 2; }
        }

        @media (min-width: 992px) {
            .bento-grid { grid-template-columns: repeat(12, 1fr); }
            .bento-col-8 { grid-column: span 8; }
            .bento-col-4 { grid-column: span 4; }
            .bento-col-12 { grid-column: span 12; }
        }

        .bento-item {
            padding: clamp(24px, 5vw, 40px);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
        }
        .bento-icon {
            width: 56px;
            height: 56px;
            border-radius: 14px;
            background: var(--bg-light);
            color: var(--accent);
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 24px;
            font-size: 1.8rem;
            flex-shrink: 0;
            border: 1px solid var(--border-light);
        }

        /* =========================================
        STATS SECTION
        ========================================= */
        .stats-section {
            background-color: var(--primary);
            color: white;
            position: relative;
        }
        .stat-number {
            font-size: clamp(2.5rem, 6vw, 4.5rem);
            font-weight: 800;
            line-height: 1;
            margin-bottom: 12px;
            color: var(--accent-light);
        }
        .stat-label {
            color: rgba(255, 255, 255, 0.8);
            font-size: clamp(0.9rem, 2vw, 1.1rem);
            font-weight: 500;
        }

        /* =========================================
        MOBILE & CTA
        ========================================= */
        .cta-section {
            background: radial-gradient(circle at center, var(--bg-light) 0%, var(--bg-base) 100%);
            text-align: center;
            border-top: 1px solid var(--border-light);
            border-bottom: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }
        .phone-mockup-wrapper {
            display: flex;
            justify-content: center;
            width: 100%;
            margin-top: clamp(40px, 8vw, 0px);
        }
        .phone-mockup {
            width: 100%;
            max-width: 320px;
            aspect-ratio: 1 / 2.03;
            background: var(--bg-light);
            border: clamp(6px, 1.5vw, 12px) solid #E2E8F0;
            border-radius: clamp(24px, 5vw, 40px);
            position: relative;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            padding: clamp(12px, 3vw, 20px);
        }
        .phone-notch {
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 35%;
            max-width: 120px;
            height: clamp(15px, 4vw, 25px);
            background: #E2E8F0;
            border-bottom-left-radius: 16px;            border-bottom-right-radius: 16px;
            z-index: 10;
        }
        .mobile-notification {
            background: white;
            border: 1px solid var(--border-light);
            box-shadow: var(--shadow-sm);
            border-radius: 16px;
            padding: clamp(12px, 3vw, 16px);
            margin-top: clamp(24px, 6vw, 40px);
            margin-bottom: 16px;
            animation: slideUpFade 1s forwards;
            opacity: 0;
            text-align: left;
        }
        
        .pulse-dot {
            width: 10px;
            height: 10px;
            background: var(--accent);
            border-radius: 50%;
            box-shadow: 0 0 10px var(--accent);
            animation: pulse 2s infinite;
            flex-shrink: 0;
        }

        @keyframes pulse {
            0% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.3); opacity: 0.7; }
            100% { transform: scale(1); opacity: 1; }
        }

        @keyframes slideUpFade {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* =========================================
        FOOTER
        ========================================= */
        footer {
            background: var(--primary);
            color: white;
        }
        .footer-heading {
            color: var(--accent-light);
            font-weight: 600;
            margin-bottom: 24px;
            font-size: clamp(1rem, 2vw, 1.1rem);
        }
        .footer-link {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            display: block;
            margin-bottom: 12px;
            transition: var(--transition);
            font-size: clamp(0.9rem, 2vw, 1rem);
        }
        .footer-link:hover { color: white; padding-left: 4px; }
        
        .footer-social { transition: var(--transition); }
        .footer-social:hover { color: var(--accent) !important; }

        /* Animations for Scroll Reveal */
        .reveal {
            opacity: 0;
            transform: translateY(40px);
            transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .reveal.active {
            opacity: 1;
            transform: translateY(0);
        }
        
        .text-balance { text-wrap: balance; }
    </style>
</head>
<body>

    <?php include __DIR__ . '/includes/header.php'; ?>
    <?php fp_render_flashes(); ?>

    <!-- SECTION 1: HERO (Replaced with Finance Core Ecosystem Graphics) -->
    <section class="hero-section text-center">
        <div class="hero-pattern"></div>
        <div class="hero-glow"></div>
        
        <div class="container relative z-10 w-100 hero-container">
            
            <div class="hero-badge mb-3">Finance Recruitment OS</div>
            
            <h1 class="hero-title mb-4">
                <span class="hero-title-line1">The Future of Finance Hiring</span>
                <span class="hero-title-line2">Starts Here.</span>
            </h1>
            
            <div class="node-container">
                <svg class="svg-lines" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid meet">
                    <path d="M200,150 Q350,150 500,300" />
                    <path d="M800,150 Q650,150 500,300" />
                    <path d="M250,450 Q375,450 500,300" />
                    <path d="M750,450 Q625,450 500,300" />
                </svg>

                <button type="button" class="center-node text-decoration-none border-0 fp-open-auth" data-auth-mode="login" style="cursor:pointer;">
                    <span>Apply Here</span>
                </button>

                <div class="orbit-node on-1">Corporate Finance</div>
                <div class="orbit-node on-2">Audit & Assurance</div>
                <div class="orbit-node on-3">Tax Advisory</div>
                <div class="orbit-node on-4">Investment Banking</div>
            </div>

        </div>
    </section>

    <!-- LATEST JOBS -->
    <section class="section-py bg-alternate">
        <div class="container reveal">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 section-mb">
                <div>
                    <div class="section-tag mb-3">Latest Jobs</div>
                    <h2 class="mb-0 text-balance">Fresh finance opportunities</h2>
                </div>
                <a href="<?php echo fp_url('job-listings.php'); ?>" class="btn btn-outline-custom">View All Jobs</a>
            </div>

            <?php if (empty($latestJobs)): ?>
                <div class="premium-card p-5 text-center">
                    <p class="text-muted mb-3">No open roles yet. Check back soon or post a role as an employer.</p>
                    <button type="button" class="btn btn-premium fp-open-auth" data-auth-mode="signup" data-auth-role="employer">Post a Role</button>
                </div>
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($latestJobs as $job): ?>
                        <div class="col-md-6">
                            <div class="premium-card p-4 h-100">
                                <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
                                    <div>
                                        <h3 class="h5 mb-1"><a class="text-decoration-none text-primary" href="<?php echo fp_url('job-details.php?id=' . (int) $job['id']); ?>"><?php echo e($job['title']); ?></a></h3>
                                        <p class="text-muted mb-0 small"><?php echo e($job['company_name']); ?> &bull; <?php echo e($job['location']); ?></p>
                                    </div>
                                    <span class="badge text-bg-light border"><?php echo e(fp_time_ago($job['posted_at'] ?? $job['created_at'])); ?></span>
                                </div>
                                <p class="text-muted small mb-3"><?php echo e($job['short_description'] ?: substr(strip_tags($job['description']), 0, 120) . '...'); ?></p>
                                <div class="d-flex gap-2">
                                    <a href="<?php echo fp_url('job-details.php?id=' . (int) $job['id']); ?>" class="btn btn-outline-custom btn-sm">View Details</a>
                                    <button type="button" class="btn btn-premium btn-sm fp-open-auth" data-return-url="<?php echo e('job-details.php?id=' . (int) $job['id']); ?>">Apply</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- CAREER INTELLIGENCE (BENTO) -->
    <section class="bg-alternate section-py">
        <div class="container reveal">
            <div class="section-tag mb-4">Platform Features</div>
            <h2 class="section-mb text-balance">Built for Finance Professionals.</h2>

            <div class="bento-grid">
                <div class="premium-card bento-item bento-col-8">
                    <div>
                        <div class="bento-icon"><i class="fa-solid fa-handshake"></i></div>
                        <h3>Direct Employer Access</h3>
                        <p class="text-muted mt-3 fs-6" style="max-width: 90%;">Skip the middleman. Our platform connects your verified CA, CMA, or CPA credentials directly with active hiring managers at top-tier firms and growing enterprises.</p>
                    </div>
                </div>
                <div class="premium-card bento-item bento-col-4">
                    <div>
                        <div class="bento-icon"><i class="fa-solid fa-chart-line"></i></div>
                        <h3>Salary Insights</h3>
                        <p class="text-muted mt-3 fs-6">Real-time compensation data for CA, CMA, CPA, and finance roles aggregated from verified recent offers.</p>
                    </div>
                </div>
                <div class="premium-card bento-item bento-col-4">
                    <div>
                        <div class="bento-icon"><i class="fa-solid fa-user-tie"></i></div>
                        <h3>Interview Prep</h3>
                        <p class="text-muted mt-3 fs-6">Firm-specific question banks for Big 4 and global banks, sourced directly from recent candidates.</p>
                    </div>
                </div>
                <div class="premium-card bento-item bento-col-8" style="position: relative; overflow: hidden;">
                    <div style="position: absolute; right: -30px; bottom: -30px; opacity: 0.1;">
                        <i class="fa-solid fa-arrow-trend-up" style="font-size: 180px; color: var(--primary);"></i>
                    </div>
                    <div class="position-relative z-10">
                        <div class="bento-icon"><i class="fa-solid fa-route"></i></div>
                        <h3>Career Growth Roadmaps</h3>
                        <p class="text-muted mt-3 fs-6" style="max-width: 85%;">Visualize your trajectory. See the exact certifications (CFA, FRM, CPA) and skills needed to transition to Management or Partner level.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 5: PLATFORM STATISTICS -->
    <section class="stats-section section-py reveal">
        <div class="container">
            <div class="row text-center g-4 g-md-5">
                <div class="col-md-3 col-6">
                    <div class="stat-number counter" data-target="250">0</div>
                    <div class="stat-label">Active Employers</div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-number"><span class="counter" data-target="150">0</span>k+</div>
                    <div class="stat-label">Registered Candidates</div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-number counter" data-target="<?php echo max(1, min(999, $totalOpenJobs)); ?>">0</div>
                    <div class="stat-label">Open Finance Jobs</div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-number"><span class="counter" data-target="98">0</span>%</div>
                    <div class="stat-label">Successful Placements</div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 6: MOBILE APP & EMPLOYER CTA -->
    <section class="cta-section section-py reveal">
        <div class="container d-flex flex-column flex-lg-row align-items-center justify-content-between gap-5">
            <div class="text-start text-center text-lg-start" style="max-width: 500px; margin: 0 auto;">
                <div class="section-tag mb-3">For Firms & Enterprises</div>
                <h2 class="mb-4 text-balance">Hire Exceptional Finance Talent.</h2>
                <p class="text-muted fs-5 mb-5 text-balance">
                    Drop the outdated spreadsheets. Experience a modern recruitment workflow designed specifically for the accounting and finance industry.
                </p>
                <div class="d-flex flex-column flex-sm-row justify-content-center justify-content-lg-start gap-3">
                    <a href="<?php echo fp_url('signup.php?role=employer'); ?>" class="btn btn-premium px-4 py-3 text-center">Start Hiring Today</a>
                    <button class="btn btn-outline-custom px-4 py-3">Book Demo</button>
                </div>
            </div>

            <!-- Fully Responsive CSS Phone Mockup -->
            <div class="phone-mockup-wrapper">
                <div class="phone-mockup">
                    <div class="phone-notch"></div>
                    
                    <div class="mobile-notification">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <div class="pulse-dot"></div>
                            <span style="font-size: clamp(0.75rem, 1.5vw, 0.85rem); color: var(--text-muted); font-weight: 600;">Candidate Update</span>
                        </div>
                        <div style="font-weight: 700; font-size: clamp(0.9rem, 2vw, 1rem); color: var(--primary);">Offer Accepted</div>
                        <div style="font-size: clamp(0.8rem, 1.5vw, 0.85rem); color: var(--text-muted); margin-top: 6px;">Michael T. accepted the Tax Manager role.</div>
                    </div>
                    
                    <div class="mobile-notification" style="animation-delay: 1.5s; opacity: 0;">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <div class="pulse-dot" style="background: var(--secondary); box-shadow: none;"></div>
                            <span style="font-size: clamp(0.75rem, 1.5vw, 0.85rem); color: var(--text-muted); font-weight: 600;">Interview Scheduled</span>
                        </div>
                        <div style="font-weight: 700; font-size: clamp(0.9rem, 2vw, 1rem); color: var(--primary);">Senior Auditor Panel</div>
                        <div style="font-size: clamp(0.8rem, 1.5vw, 0.85rem); color: var(--text-muted); margin-top: 6px;">Today at 2:00 PM via Teams.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include __DIR__ . '/includes/footer.php'; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom Interactions -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            
            // 1. Scroll Reveal Animation via Intersection Observer
            const revealElements = document.querySelectorAll('.reveal');
            
            const revealOptions = {
                threshold: 0.1,
                rootMargin: "0px 0px -50px 0px"
            };

            const revealObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('active');
                        observer.unobserve(entry.target);
                    }
                });
            }, revealOptions);

            revealElements.forEach(el => {
                revealObserver.observe(el);
            });

            // 2. Animated Counters
            const counters = document.querySelectorAll('.counter');
            let hasCounted = false;

            const counterObserver = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && !hasCounted) {
                    hasCounted = true;
                    counters.forEach(counter => {
                        const target = +counter.getAttribute('data-target');
                        const duration = 2000; 
                        const increment = target / (duration / 16); 
                        
                        let current = 0;
                        const updateCounter = () => {
                            current += increment;
                            if (current < target) {
                                counter.innerText = Math.ceil(current);
                                requestAnimationFrame(updateCounter);
                            } else {
                                counter.innerText = target;
                            }
                        };
                        updateCounter();
                    });
                }
            }, { threshold: 0.5 });

            const statsSection = document.querySelector('.stat-number');
            if (statsSection) {
                counterObserver.observe(statsSection.parentElement.parentElement);
            }

            // 3. Dynamic Navbar Background based on scroll
            const navbar = document.querySelector('.navbar-premium');
            const heroSection = document.querySelector('.hero-section');
            const footer = document.querySelector('footer');
            
            window.addEventListener('scroll', () => {
                const scrollThreshold = heroSection ? heroSection.offsetHeight - 80 : 50;
                
                const navbarRect = navbar.getBoundingClientRect();
                const footerRect = footer ? footer.getBoundingClientRect() : { top: Infinity };
                const isTouchingFooter = footerRect.top <= navbarRect.bottom;
                
                if (window.scrollY > scrollThreshold && !isTouchingFooter) {
                    navbar.classList.add('navbar-scrolled');
                } else {
                    navbar.classList.remove('navbar-scrolled');
                }
            });
        });
    </script>
</body>
</html>