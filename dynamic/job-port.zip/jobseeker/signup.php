<?php
require_once __DIR__ . '/../includes/jobseeker_layout.php';

$existingUser = fp_current_user();
if ($existingUser && $existingUser['role'] === 'job_seeker' && $existingUser['status'] === 'active') {
    fp_redirect('dashboard.php');
}

$form = array(
    'name' => '',
    'email' => '',
    'phone' => '',
    'headline' => '',
    'skills' => '',
    'experience_years' => '0',
    'qualification' => '',
    'current_location' => '',
    'preferred_location' => '',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    if (fp_get_admin_setting('allow_public_signup', '1') !== '1') {
        fp_flash('danger', 'Public signup is currently disabled. Please contact the platform administrator.');
        fp_redirect('signup.php');
    }

    foreach ($form as $key => $value) {
        $form[$key] = trim($_POST[$key] ?? '');
    }

    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');
    $errors = array();

    if ($form['name'] === '') {
        $errors[] = 'Name is required.';
    }

    if (!filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    }

    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    }

    if ($password !== $confirmPassword) {
        $errors[] = 'Password confirmation does not match.';
    }

    $experienceYears = max(0, (float) $form['experience_years']);

    if (empty($errors)) {
        $existing = fp_db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $existing->execute(array($form['email']));

        if ($existing->fetch()) {
            $errors[] = 'An account already exists with this email address.';
        }
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            fp_flash('danger', $error);
        }
    } else {
        $pdo = fp_db();

        try {
            $pdo->beginTransaction();

            $userStatement = $pdo->prepare(
                "INSERT INTO users (role, name, email, phone, password_hash, status)
                 VALUES ('job_seeker', ?, ?, ?, ?, 'active')"
            );
            $userStatement->execute(array(
                $form['name'],
                $form['email'],
                $form['phone'] !== '' ? $form['phone'] : null,
                password_hash($password, PASSWORD_DEFAULT),
            ));

            $userId = (int) $pdo->lastInsertId();
            $profileLevel = ($form['skills'] !== '' || $experienceYears > 0 || $form['qualification'] !== '') ? 'skilled' : 'basic';

            $profileStatement = $pdo->prepare(
                "INSERT INTO job_seeker_profiles
                    (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            );
            $profileStatement->execute(array(
                $userId,
                $form['headline'] !== '' ? $form['headline'] : null,
                $form['skills'] !== '' ? $form['skills'] : null,
                $experienceYears,
                $form['qualification'] !== '' ? $form['qualification'] : null,
                $form['current_location'] !== '' ? $form['current_location'] : null,
                $form['preferred_location'] !== '' ? $form['preferred_location'] : null,
                $profileLevel,
            ));

            $resume = fp_upload_resume('resume', $userId);
            if ($resume) {
                $pdo->prepare(
                    'UPDATE job_seeker_profiles
                     SET resume_file_path = ?, resume_original_name = ?, resume_uploaded_at = NOW()
                     WHERE user_id = ?'
                )->execute(array($resume['path'], $resume['original_name'], $userId));
            }

            $pdo->commit();

            $statement = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
            $statement->execute(array($userId));
            $user = $statement->fetch();

            fp_login_user($user);
            fp_flash('success', 'Your jobseeker account is ready.');
            fp_redirect('dashboard.php');
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            fp_flash('danger', $exception->getMessage());
        }
    }
}

fp_jobseeker_page_start('Create Job Seeker Account', 'signup', 'jobseeker-login', true);
?>
<section class="auth-shell auth-shell-wide">
    <div class="panel">
        <div class="mb-4 text-center text-md-start">
            <div class="section-tag">Job Seeker</div>
            <h1 class="h3 mb-2">Create your account</h1>
            <p class="muted mb-0">Set up your basic profile now. You can update everything later from your dashboard.</p>
        </div>

        <form method="post" action="signup.php" enctype="multipart/form-data" novalidate>
            <?php echo fp_csrf_field(); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label" for="name">Full name</label>
                    <input class="form-control" type="text" id="name" name="name" value="<?php echo e($form['name']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="email">Email address</label>
                    <input class="form-control" type="email" id="email" name="email" value="<?php echo e($form['email']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="phone">Phone</label>
                    <input class="form-control" type="tel" id="phone" name="phone" value="<?php echo e($form['phone']); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="headline">Profile headline</label>
                    <input class="form-control" type="text" id="headline" name="headline" value="<?php echo e($form['headline']); ?>" placeholder="Finance Analyst, Tax Consultant">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="password">Password</label>
                    <input class="form-control" type="password" id="password" name="password" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="confirm_password">Confirm password</label>
                    <input class="form-control" type="password" id="confirm_password" name="confirm_password" required>
                </div>
                <div class="col-md-12">
                    <label class="form-label" for="skills">Skills</label>
                    <input class="form-control" type="text" id="skills" name="skills" value="<?php echo e($form['skills']); ?>" placeholder="Accounting, GST, Audit, Excel">
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="experience_years">Experience</label>
                    <input class="form-control" type="number" min="0" step="0.5" id="experience_years" name="experience_years" value="<?php echo e($form['experience_years']); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="qualification">Qualification</label>
                    <input class="form-control" type="text" id="qualification" name="qualification" value="<?php echo e($form['qualification']); ?>" placeholder="CA, MBA, B.Com">
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="current_location">Location</label>
                    <input class="form-control" type="text" id="current_location" name="current_location" value="<?php echo e($form['current_location']); ?>" placeholder="Hyderabad">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="preferred_location">Preferred location</label>
                    <input class="form-control" type="text" id="preferred_location" name="preferred_location" value="<?php echo e($form['preferred_location']); ?>" placeholder="Bangalore, Remote">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="resume">Resume</label>
                    <input class="form-control" type="file" id="resume" name="resume" accept=".pdf,.doc,.docx">
                    <div class="form-text">PDF, DOC, or DOCX. Max 5 MB.</div>
                </div>
            </div>

            <button class="btn btn-premium w-100 py-3 mt-4" type="submit">
                <i class="fa-solid fa-user-plus"></i>
                Create Account
            </button>
        </form>

        <p class="muted mt-4 mb-0">
            Already registered? <a class="fw-bold text-decoration-none" href="login.php">Sign in</a>.
        </p>
    </div>
</section>
<?php fp_jobseeker_page_end(); ?>
