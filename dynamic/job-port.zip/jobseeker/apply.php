<?php
require_once __DIR__ . '/../includes/app.php';

fp_require_login('job_seeker', 'login.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fp_redirect('jobs.php');
}

fp_require_csrf();

$jobId = (int) ($_POST['job_id'] ?? 0);
$user = fp_current_user();
$profile = fp_ensure_jobseeker_profile($user['id']);

try {
    if (empty($profile['resume_file_path'])) {
        throw new RuntimeException('Upload your resume before applying.');
    }

    fp_apply_to_job((int) $profile['id'], $jobId, $profile['resume_file_path']);
    fp_flash('success', 'Your application was submitted successfully.');
    fp_redirect('applications.php');
} catch (Throwable $exception) {
    fp_flash('danger', $exception->getMessage());
    fp_redirect('job.php?id=' . $jobId);
}
