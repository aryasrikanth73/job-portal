<?php
require_once __DIR__ . '/../includes/jobseeker_layout.php';

$user = fp_require_login('job_seeker', 'login.php');
$resume = fp_jobseeker_resume_for_user($user['id']);

if (!$resume) {
    fp_flash('warning', 'Upload a resume first to view it here.');
    fp_redirect('profile.php');
}

fp_jobseeker_portal_start('My Resume', 'profile');
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Resume</div>
        <h1>My Resume</h1>
        <p class="muted mb-0">Preview what employers receive when you apply.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="resume-file.php?download=1" class="btn btn-outline-custom">
            <i class="fa-solid fa-download"></i> Download
        </a>
        <a href="profile.php" class="btn btn-premium">
            <i class="fa-solid fa-pen"></i> Update Resume
        </a>
    </div>
</div>

<div class="panel mb-3">
    <div class="d-flex align-items-start gap-3 flex-wrap">
        <div class="resume-file-icon">
            <i class="fa-solid <?php echo $resume['extension'] === 'pdf' ? 'fa-file-pdf' : 'fa-file-word'; ?>"></i>
        </div>
        <div class="flex-grow-1 min-w-0">
            <h2 class="h5 mb-1 text-truncate"><?php echo e($resume['original_name']); ?></h2>
            <p class="muted small mb-0">
                <?php echo e(strtoupper($resume['extension'])); ?> file
                &bull; Uploaded <?php echo e(fp_time_ago($resume['uploaded_at'])); ?>
            </p>
        </div>
    </div>
</div>

<?php if ($resume['is_previewable']): ?>
<div class="panel p-0 overflow-hidden resume-preview-panel">
    <iframe
        class="resume-preview-frame"
        src="resume-file.php"
        title="Resume preview"
    ></iframe>
</div>
<?php else: ?>
<div class="panel text-center py-5">
    <i class="fa-solid fa-file-word d-block mb-3" style="font-size:2.5rem;color:var(--accent);"></i>
    <h2 class="h5 mb-2">Preview not available</h2>
    <p class="muted mb-4">Word documents cannot be previewed in the browser. Download the file to open it on your device.</p>
    <a href="resume-file.php?download=1" class="btn btn-premium">
        <i class="fa-solid fa-download"></i> Download Resume
    </a>
</div>
<?php endif; ?>
<?php fp_jobseeker_portal_end('profile'); ?>
