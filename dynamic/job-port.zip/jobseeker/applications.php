<?php
require_once __DIR__ . '/../includes/jobseeker_layout.php';

$ctx = fp_jobseeker_portal_start('My Applications', 'applications');
$user = $ctx['user'];
$profileId = fp_jobseeker_profile_id($user['id']);
$applications = fp_fetch_seeker_applications($profileId, 50);
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Application Tracker</div>
        <h1>My Applications</h1>
        <p class="muted mb-0"><?php echo e(count($applications)); ?> total applications</p>
    </div>
    <a href="jobs.php" class="btn btn-premium">Browse Jobs</a>
</div>

<?php if (empty($applications)): ?>
    <div class="empty-card panel">
        <i class="fa-solid fa-file-circle-check d-block"></i>
        <h2 class="h5">No applications yet</h2>
        <p class="muted mb-3">Start applying to finance roles that match your profile.</p>
        <a href="jobs.php" class="btn btn-premium">Browse Jobs</a>
    </div>
<?php else: ?>
    <?php foreach ($applications as $application): ?>
        <div class="job-card">
            <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
                <div class="d-flex gap-3 flex-grow-1">
                    <div class="job-logo"><?php echo e(fp_company_initials($application['company_name'])); ?></div>
                    <div>
                        <h2 class="h6 mb-1">
                            <a href="job.php?id=<?php echo (int) $application['job_id']; ?>" class="text-decoration-none text-primary">
                                <?php echo e($application['title']); ?>
                            </a>
                        </h2>
                        <p class="muted small mb-2"><?php echo e($application['company_name']); ?> &bull; <?php echo e($application['location']); ?></p>
                        <span class="status-pill <?php echo e(fp_application_status_class($application['status'])); ?>">
                            <?php echo e(fp_format_application_status($application['status'])); ?>
                        </span>
                    </div>
                </div>
                <div class="text-end">
                    <div class="muted small">Applied</div>
                    <div class="fw-semibold small"><?php echo e(date('M j, Y', strtotime($application['applied_at']))); ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<?php fp_jobseeker_portal_end('applications'); ?>
