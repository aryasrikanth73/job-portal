<?php
require_once __DIR__ . '/../includes/jobseeker_layout.php';

$user = fp_require_login('job_seeker', 'login.php');
$profile = fp_ensure_jobseeker_profile($user['id']);
$profileId = fp_jobseeker_profile_id($user['id']);

$jobId = (int) ($_GET['id'] ?? 0);
$job = $jobId > 0 ? fp_fetch_job_by_id($jobId) : null;

if (!$job) {
    fp_jobseeker_portal_start('Job Details', 'jobs');
    ?>
    <div class="empty-card panel">
        <i class="fa-solid fa-circle-exclamation d-block"></i>
        <h1 class="h5">Job not found</h1>
        <p class="muted">This role may have been closed or removed.</p>
        <a href="jobs.php" class="btn btn-premium">Back to Jobs</a>
    </div>
    <?php
    fp_jobseeker_portal_end('jobs');
    exit;
}

$applied = fp_seeker_has_applied($profileId, $jobId);
if ($applied) {
    fp_sweetalert_notice('success', 'You have already applied for this job.');
}
$hasResume = !empty($profile['resume_file_path']);
$companyName = $job['company_name'];
$initials = fp_company_initials($companyName);
$tags = array_filter(array_map('trim', explode(',', (string) ($job['skills_required'] ?? ''))));
fp_jobseeker_portal_start('Job Details', 'jobs');
?>
<div class="page-heading">
    <div class="d-flex gap-3 align-items-start">
        <div class="job-logo" style="width:64px;height:64px;font-size:1.2rem;"><?php echo e($initials); ?></div>
        <div>
            <div class="section-tag">Job Details</div>
            <h1 class="mb-1"><?php echo e($job['title']); ?></h1>
            <p class="muted mb-0"><?php echo e($companyName); ?> &bull; <?php echo e($job['location']); ?></p>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="panel mb-3">
            <div class="d-flex flex-wrap gap-3 muted small fw-semibold mb-4">
                <span><i class="fa-solid fa-briefcase"></i> <?php echo e(fp_format_job_type($job['job_type'])); ?></span>
                <span><i class="fa-solid fa-building"></i> <?php echo e(ucfirst(str_replace('_', ' ', $job['workplace_type']))); ?></span>
                <span><i class="fa-solid fa-money-bill-wave"></i> <?php echo e(fp_money_range($job['salary_currency'], $job['salary_min'], $job['salary_max'])); ?></span>
                <span><i class="fa-regular fa-clock"></i> <?php echo e(fp_time_ago($job['posted_at'] ?? $job['created_at'])); ?></span>
            </div>
            <?php if (!empty($job['short_description'])): ?>
                <p class="lead muted"><?php echo e($job['short_description']); ?></p>
            <?php endif; ?>
            <h2 class="h6">Description</h2>
            <div class="muted" style="line-height:1.7;"><?php echo nl2br(e($job['description'])); ?></div>
            <?php if (!empty($job['requirements'])): ?>
                <h2 class="h6 mt-4">Requirements</h2>
                <div class="muted" style="line-height:1.7;"><?php echo nl2br(e($job['requirements'])); ?></div>
            <?php endif; ?>
            <?php if (!empty($tags)): ?>
                <div class="mt-4">
                    <?php foreach ($tags as $tag): ?>
                        <span class="tag"><?php echo e($tag); ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="panel sticky-top" style="top:88px;" id="apply">
            <h2 class="h6 mb-3">Apply for this role</h2>
            <?php if ($applied): ?>
                <span class="status-pill status-shortlisted d-inline-flex mb-3">Already applied</span>
                <a href="applications.php" class="btn btn-outline-custom w-100">View My Applications</a>
            <?php elseif (!$hasResume): ?>
                <p class="muted small">Upload your resume before applying.</p>
                <a href="profile.php" class="btn btn-premium w-100 mb-2">Upload Resume</a>
            <?php else: ?>
                <form method="post" action="apply.php">
                    <?php echo fp_csrf_field(); ?>
                    <input type="hidden" name="job_id" value="<?php echo (int) $jobId; ?>">
                    <p class="muted small mb-3">Your profile and resume will be shared with the employer.</p>
                    <button class="btn btn-premium w-100 py-3" type="submit">
                        <i class="fa-solid fa-paper-plane"></i> Apply Now
                    </button>
                </form>
            <?php endif; ?>
            <a href="jobs.php" class="btn btn-outline-custom w-100 mt-3">Back to Jobs</a>
            <?php if (!empty($job['qualification_required'])): ?>
                <hr>
                <p class="muted small mb-1"><strong>Qualification:</strong> <?php echo e($job['qualification_required']); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if (!$applied && $hasResume): ?>
<div class="portal-sticky-apply is-visible">
    <form method="post" action="apply.php">
        <?php echo fp_csrf_field(); ?>
        <input type="hidden" name="job_id" value="<?php echo (int) $jobId; ?>">
        <button class="btn btn-premium py-3" type="submit">
            <i class="fa-solid fa-paper-plane"></i> Apply Now
        </button>
    </form>
</div>
<script>
document.body.classList.add('has-sticky-apply');
var portalShell = document.querySelector('.portal-shell');
if (portalShell) { portalShell.classList.add('has-sticky-apply'); }
</script>
<?php elseif (!$applied && !$hasResume): ?>
<div class="portal-sticky-apply is-visible">
    <a href="profile.php" class="btn btn-premium py-3">
        <i class="fa-solid fa-upload"></i> Upload Resume to Apply
    </a>
</div>
<script>
document.body.classList.add('has-sticky-apply');
var portalShell = document.querySelector('.portal-shell');
if (portalShell) { portalShell.classList.add('has-sticky-apply'); }
</script>
<?php endif; ?>

<?php fp_jobseeker_portal_end('jobs'); ?>
