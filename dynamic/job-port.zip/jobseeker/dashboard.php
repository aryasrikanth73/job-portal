<?php
require_once __DIR__ . '/../includes/jobseeker_layout.php';

$ctx = fp_jobseeker_portal_start('Dashboard', 'dashboard');
$user = $ctx['user'];
$profile = $ctx['profile'];
$completion = $ctx['completion'];
$profileId = fp_jobseeker_profile_id($user['id']);
$applicationCount = fp_count_seeker_applications($profileId);
$recentApplications = fp_fetch_seeker_applications($profileId, 3);
$hasResume = is_array($profile) && !empty($profile['resume_file_path']);
$recommendedJobs = fp_fetch_open_jobs(fp_build_job_filters(array()), 3, 0);
$firstName = explode(' ', trim($user['name']))[0];
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Student Dashboard</div>
        <h1>Hi, <?php echo e($firstName); ?></h1>
        <p class="muted mb-0">Track applications, complete your profile, and discover finance roles.</p>
    </div>
    <a href="jobs.php" class="btn btn-premium">Browse Jobs</a>
</div>

<?php if ($completion < 100): ?>
<div class="completion-banner">
    <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
        <div>
            <h2 class="h5 text-white mb-1">Complete your profile</h2>
            <p class="mb-0 small" style="color:rgba(255,255,255,0.75);">Employers are more likely to shortlist complete profiles with a resume.</p>
        </div>
        <span class="fw-bold" style="font-size:1.5rem;"><?php echo e($completion); ?>%</span>
    </div>
    <div class="completion-bar"><span style="width:<?php echo e($completion); ?>%;"></span></div>
    <a href="profile.php" class="btn btn-premium btn-sm">Complete Profile</a>
</div>
<?php endif; ?>

<div class="metric-grid">
    <div class="metric-card">
        <div class="metric-value"><?php echo e($applicationCount); ?></div>
        <div class="metric-label">Applications</div>
    </div>
    <div class="metric-card">
        <div class="metric-value"><?php echo e($completion); ?>%</div>
        <div class="metric-label">Profile Strength</div>
    </div>
    <div class="metric-card">
        <?php if ($hasResume): ?>
            <a href="resume.php" class="metric-value text-decoration-none d-inline-block" style="font-size:1.25rem;color:var(--accent);">View</a>
            <div class="metric-label">My Resume</div>
        <?php else: ?>
            <div class="metric-value" style="font-size:1.25rem;">No</div>
            <div class="metric-label">Resume Uploaded</div>
            <a href="profile.php" class="small fw-bold mt-1 d-inline-block">Upload</a>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="panel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Recent Applications</h2>
                <a href="applications.php" class="small fw-bold">View all</a>
            </div>
            <?php if (empty($recentApplications)): ?>
                <div class="empty-card border-0 shadow-none p-4">
                    <i class="fa-solid fa-paper-plane d-block"></i>
                    <p class="muted mb-3">You have not applied to any jobs yet.</p>
                    <a href="jobs.php" class="btn btn-premium">Find Jobs</a>
                </div>
            <?php else: ?>
                <?php foreach ($recentApplications as $application): ?>
                    <div class="job-card mb-0">
                        <div class="d-flex justify-content-between align-items-start gap-3">
                            <div>
                                <h3 class="h6 mb-1">
                                    <a href="job.php?id=<?php echo (int) $application['job_id']; ?>" class="text-decoration-none text-primary">
                                        <?php echo e($application['title']); ?>
                                    </a>
                                </h3>
                                <p class="muted small mb-2"><?php echo e($application['company_name']); ?> &bull; <?php echo e($application['location']); ?></p>
                                <span class="status-pill <?php echo e(fp_application_status_class($application['status'])); ?>">
                                    <?php echo e(fp_format_application_status($application['status'])); ?>
                                </span>
                            </div>
                            <span class="muted small text-nowrap"><?php echo e(fp_time_ago($application['applied_at'])); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="panel">
            <h2 class="h5 mb-3">Recommended Jobs</h2>
            <?php if (empty($recommendedJobs)): ?>
                <p class="muted mb-0">No open roles right now. Check back soon.</p>
            <?php else: ?>
                <?php foreach ($recommendedJobs as $job): ?>
                    <div class="d-flex gap-3 mb-3 pb-3 border-bottom">
                        <div class="job-logo"><?php echo e(fp_company_initials($job['company_name'])); ?></div>
                        <div class="flex-grow-1 min-w-0">
                            <h3 class="h6 mb-1 text-truncate">
                                <a href="job.php?id=<?php echo (int) $job['id']; ?>" class="text-decoration-none text-primary"><?php echo e($job['title']); ?></a>
                            </h3>
                            <p class="muted small mb-2"><?php echo e($job['company_name']); ?></p>
                            <a href="job.php?id=<?php echo (int) $job['id']; ?>" class="btn btn-outline-custom btn-sm">View</a>
                        </div>
                    </div>
                <?php endforeach; ?>
                <a href="jobs.php" class="btn btn-premium w-100 mt-2">Browse All Jobs</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php fp_jobseeker_portal_end('dashboard'); ?>
