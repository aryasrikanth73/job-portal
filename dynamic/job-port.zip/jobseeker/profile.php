<?php
require_once __DIR__ . '/../includes/jobseeker_layout.php';

$user = fp_require_login('job_seeker', 'login.php');
$profile = fp_ensure_jobseeker_profile($user['id']);

$form = array(
    'name' => $user['name'],
    'phone' => $user['phone'] ?? '',
    'headline' => $profile['headline'] ?? '',
    'skills' => $profile['skills'] ?? '',
    'experience_years' => (string) ($profile['experience_years'] ?? '0'),
    'qualification' => $profile['qualification'] ?? '',
    'current_location' => $profile['current_location'] ?? '',
    'preferred_location' => $profile['preferred_location'] ?? '',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $action = $_POST['action'] ?? 'profile';

    if ($action === 'profile') {
        foreach (array_keys($form) as $key) {
            if ($key !== 'name' && $key !== 'phone') {
                $form[$key] = trim($_POST[$key] ?? '');
            }
        }
        $form['name'] = trim($_POST['name'] ?? '');
        $form['phone'] = trim($_POST['phone'] ?? '');

        if ($form['name'] === '') {
            fp_flash('danger', 'Name is required.');
        } else {
            try {
                fp_update_jobseeker_user($user['id'], $form);
                fp_update_jobseeker_profile($user['id'], $form);
                fp_flash('success', 'Profile updated successfully.');
                fp_redirect('profile.php');
            } catch (Throwable $exception) {
                fp_flash('danger', $exception->getMessage());
            }
        }
    }

    if ($action === 'resume') {
        try {
            $resume = fp_upload_resume('resume', $user['id']);
            if (!$resume) {
                fp_flash('warning', 'Choose a resume file to upload.');
            } else {
                fp_db()->prepare(
                    'UPDATE job_seeker_profiles
                     SET resume_file_path = ?, resume_original_name = ?, resume_uploaded_at = NOW()
                     WHERE user_id = ?'
                )->execute(array($resume['path'], $resume['original_name'], $user['id']));
                fp_flash('success', 'Resume uploaded successfully.');
                fp_redirect('profile.php');
            }
        } catch (Throwable $exception) {
            fp_flash('danger', $exception->getMessage());
        }
    }
}

$profile = fp_jobseeker_profile($user['id']);
$completion = fp_profile_completion($profile);
fp_jobseeker_portal_start('Profile', 'profile');
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Your Profile</div>
        <h1>Profile & Resume</h1>
        <p class="muted mb-0">Keep your details current so employers can find and shortlist you.</p>
    </div>
    <span class="profile-pill"><?php echo e($completion); ?>% complete</span>
</div>

<div class="row g-3">
    <div class="col-12 col-xl-8">
        <div class="panel mb-3">
            <h2 class="h5 mb-4">Personal & Professional Details</h2>
            <form method="post" action="profile.php" novalidate>
                <?php echo fp_csrf_field(); ?>
                <input type="hidden" name="action" value="profile">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="name">Full name</label>
                        <input class="form-control" type="text" id="name" name="name" value="<?php echo e($form['name']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="phone">Phone</label>
                        <input class="form-control" type="tel" id="phone" name="phone" value="<?php echo e($form['phone']); ?>" placeholder="+91 XXXXX XXXXX">
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="headline">Profile headline</label>
                        <input class="form-control" type="text" id="headline" name="headline" value="<?php echo e($form['headline']); ?>" placeholder="Finance Analyst, Tax Consultant">
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="skills">Skills</label>
                        <input class="form-control" type="text" id="skills" name="skills" value="<?php echo e($form['skills']); ?>" placeholder="Accounting, GST, Audit, Excel">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="experience_years">Experience (years)</label>
                        <input class="form-control" type="number" min="0" step="0.5" id="experience_years" name="experience_years" value="<?php echo e($form['experience_years']); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="qualification">Qualification</label>
                        <input class="form-control" type="text" id="qualification" name="qualification" value="<?php echo e($form['qualification']); ?>" placeholder="CA, MBA, B.Com">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="current_location">Current location</label>
                        <input class="form-control" type="text" id="current_location" name="current_location" value="<?php echo e($form['current_location']); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="preferred_location">Preferred location</label>
                        <input class="form-control" type="text" id="preferred_location" name="preferred_location" value="<?php echo e($form['preferred_location']); ?>" placeholder="Hyderabad, Remote">
                    </div>
                </div>
                <button class="btn btn-premium w-100 w-md-auto mt-4" type="submit">
                    <i class="fa-solid fa-floppy-disk"></i> Save Profile
                </button>
            </form>
        </div>
    </div>
    <div class="col-12 col-xl-4">
        <div class="panel resume-panel">
            <h2 class="h5 mb-3">Resume</h2>
            <div class="resume-box mb-3">
                <?php if (!empty($profile['resume_file_path'])): ?>
                    <div class="resume-current">
                        <div class="resume-current-icon" aria-hidden="true">
                            <i class="fa-solid <?php echo (pathinfo($profile['resume_file_path'], PATHINFO_EXTENSION) === 'pdf') ? 'fa-file-pdf' : 'fa-file-word'; ?>"></i>
                        </div>
                        <div class="resume-current-body">
                            <div class="resume-current-name"><?php echo e($profile['resume_original_name'] ?? 'Resume'); ?></div>
                            <div class="muted small">Uploaded <?php echo e(fp_time_ago($profile['resume_uploaded_at'] ?? null)); ?></div>
                        </div>
                    </div>
                    <div class="resume-actions">
                        <a href="resume.php" class="btn btn-premium btn-sm">
                            <i class="fa-solid fa-eye"></i> View
                        </a>
                        <a href="resume-file.php?download=1" class="btn btn-outline-custom btn-sm">
                            <i class="fa-solid fa-download"></i> Download
                        </a>
                    </div>
                <?php else: ?>
                    <p class="muted mb-0">No resume uploaded yet. Add one to apply faster.</p>
                <?php endif; ?>
            </div>
            <form method="post" action="profile.php" enctype="multipart/form-data" class="resume-upload-form" novalidate>
                <?php echo fp_csrf_field(); ?>
                <input type="hidden" name="action" value="resume">
                <label class="form-label" for="resume"><?php echo !empty($profile['resume_file_path']) ? 'Replace resume' : 'Upload resume'; ?></label>
                <div class="resume-file-picker">
                    <input type="file" id="resume" name="resume" accept=".pdf,.doc,.docx" required>
                    <label class="resume-file-picker-btn" for="resume">
                        <i class="fa-solid fa-folder-open"></i>
                        <span>Choose file</span>
                    </label>
                    <span class="resume-file-name" data-resume-file-name>No file chosen</span>
                </div>
                <p class="muted small mb-3">PDF, DOC, or DOCX. Max 5 MB.</p>
                <button class="btn btn-premium w-100" type="submit">
                    <i class="fa-solid fa-upload"></i> Upload Resume
                </button>
            </form>
        </div>
    </div>
</div>
<script>
(function () {
    var input = document.getElementById('resume');
    var label = document.querySelector('[data-resume-file-name]');
    if (!input || !label) return;
    input.addEventListener('change', function () {
        label.textContent = (input.files && input.files[0]) ? input.files[0].name : 'No file chosen';
    });
})();
</script>
<?php fp_jobseeker_portal_end('profile'); ?>
