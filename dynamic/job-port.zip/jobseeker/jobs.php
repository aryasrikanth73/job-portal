<?php
require_once __DIR__ . '/../includes/jobseeker_layout.php';

$ctx = fp_jobseeker_portal_start('Browse Jobs', 'jobs');
$user = $ctx['user'];
$profileId = fp_jobseeker_profile_id($user['id']);

$filters = fp_build_job_filters($_GET);
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;
$totalJobs = fp_count_open_jobs($filters);
$totalPages = max(1, (int) ceil($totalJobs / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
}
$jobs = fp_fetch_open_jobs($filters, $perPage, ($page - 1) * $perPage);
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Opportunities</div>
        <h1>Browse Jobs</h1>
        <p class="muted mb-0"><?php echo e($totalJobs); ?> open finance roles</p>
    </div>
</div>

<form class="search-bar panel" method="get" action="jobs.php">
    <input class="form-control" type="text" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Job title or keyword">
    <input class="form-control" type="text" name="skills" value="<?php echo e($filters['skills']); ?>" placeholder="Skills">
    <input class="form-control" type="text" name="location" value="<?php echo e($filters['location']); ?>" placeholder="Location">
    <button class="btn btn-premium" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
</form>

<?php if (empty($jobs)): ?>
    <div class="empty-card panel">
        <i class="fa-solid fa-briefcase d-block"></i>
        <h2 class="h5">No jobs found</h2>
        <p class="muted">Try different keywords or clear your search.</p>
        <a href="jobs.php" class="btn btn-outline-custom">Clear Search</a>
    </div>
<?php else: ?>
    <?php foreach ($jobs as $job):
        $applied = fp_seeker_has_applied($profileId, (int) $job['id']);
        $initials = fp_company_initials($job['company_name']);
    ?>
    <div class="job-card">
        <div class="d-flex gap-3">
            <div class="job-logo"><?php echo e($initials); ?></div>
            <div class="flex-grow-1 min-w-0">
                <div class="d-flex justify-content-between align-items-start gap-2 flex-wrap">
                    <div>
                        <h2 class="h6 mb-1">
                            <a href="job.php?id=<?php echo (int) $job['id']; ?>" class="text-decoration-none text-primary"><?php echo e($job['title']); ?></a>
                        </h2>
                        <p class="muted small mb-2"><?php echo e($job['company_name']); ?> &bull; <?php echo e($job['location']); ?></p>
                    </div>
                    <?php if ($applied): ?>
                        <span class="status-pill status-applied">Applied</span>
                    <?php endif; ?>
                </div>
                <div class="d-flex flex-wrap gap-2 muted small fw-semibold mb-3">
                    <span><i class="fa-solid fa-briefcase"></i> <?php echo e(fp_format_job_type($job['job_type'])); ?></span>
                    <span><i class="fa-solid fa-money-bill-wave"></i> <?php echo e(fp_money_range($job['salary_currency'], $job['salary_min'], $job['salary_max'])); ?></span>
                    <span><i class="fa-regular fa-clock"></i> <?php echo e(fp_time_ago($job['posted_at'] ?? $job['created_at'])); ?></span>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="job.php?id=<?php echo (int) $job['id']; ?>" class="btn btn-outline-custom btn-sm">View Details</a>
                    <?php if (!$applied): ?>
                        <a href="job.php?id=<?php echo (int) $job['id']; ?>#apply" class="btn btn-premium btn-sm">Apply</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if ($totalPages > 1): ?>
    <div class="d-flex justify-content-center gap-2 mt-3 flex-wrap">
        <?php if ($page > 1): ?>
            <a class="btn btn-outline-custom" href="jobs.php?<?php echo e(http_build_query(array_merge($filters, array('page' => $page - 1)))); ?>">Previous</a>
        <?php endif; ?>
        <?php if ($page < $totalPages): ?>
            <a class="btn btn-outline-custom" href="jobs.php?<?php echo e(http_build_query(array_merge($filters, array('page' => $page + 1)))); ?>">Next</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php endif; ?>
<?php fp_jobseeker_portal_end('jobs'); ?>
