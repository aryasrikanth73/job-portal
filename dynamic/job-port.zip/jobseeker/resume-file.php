<?php
require_once __DIR__ . '/../includes/app.php';

$user = fp_require_login('job_seeker', 'login.php');
$resume = fp_jobseeker_resume_for_user($user['id']);

if (!$resume) {
    http_response_code(404);
    exit('Resume not found.');
}

$download = isset($_GET['download']) && $_GET['download'] === '1';
$inline = !$download && $resume['is_previewable'];

header('Content-Type: ' . $resume['mime_type']);
header('Content-Length: ' . filesize($resume['absolute_path']));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');

$filename = preg_replace('/[^\w.\- ]+/u', '_', $resume['original_name']);
if ($filename === '') {
    $filename = 'resume.' . $resume['extension'];
}

$disposition = ($inline ? 'inline' : 'attachment') . '; filename="' . str_replace('"', '', $filename) . '"';
header('Content-Disposition: ' . $disposition);

readfile($resume['absolute_path']);
exit;
