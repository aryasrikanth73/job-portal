<?php
require_once __DIR__ . '/../includes/app.php';

fp_logout_user();
fp_flash('success', 'You have been signed out.');
fp_redirect('login.php');
