<?php
require_once __DIR__ . '/../includes/app.php';

$user = fp_require_login('employer', 'login.php');
$profile = fp_employer_profile($user['id']);
if (!$profile) {
    http_response_code(404);
    exit('Employer profile not found.');
}

$employerId = (int) $profile['id'];
$applicationId = (int) ($_GET['application_id'] ?? 0);
$seekerId = (int) ($_GET['seeker_id'] ?? 0);
$download = isset($_GET['download']) && $_GET['download'] === '1';
$action = $download ? 'download_resume' : 'view_resume';

$resumePath = null;
$originalName = 'resume.pdf';
$logSeekerId = 0;
$logApplicationId = null;

if ($applicationId > 0) {
    $application = fp_fetch_employer_application($applicationId, $employerId);
    if (!$application) {
        fp_log_resume_access($employerId, 0, $action, false, $applicationId, 'Application not found');
        http_response_code(404);
        exit('Application not found.');
    }

    $logSeekerId = (int) $application['job_seeker_id'];
    $logApplicationId = $applicationId;
    $resumePath = $application['resume_file_path'] ?: $application['seeker_resume_path'];
    $originalName = $application['resume_original_name'] ?? basename((string) $resumePath);
} elseif ($seekerId > 0) {
    $candidate = fp_fetch_candidate_profile($seekerId);
    if (!$candidate) {
        fp_log_resume_access($employerId, $seekerId, $action, false, null, 'Candidate not found');
        http_response_code(404);
        exit('Candidate not found.');
    }

    $logSeekerId = $seekerId;
    $resumePath = $candidate['resume_file_path'] ?? null;
    $originalName = $candidate['resume_original_name'] ?? 'resume.pdf';
} else {
    http_response_code(400);
    exit('Invalid request.');
}

if (!fp_can_employer_view_resume($profile)) {
    fp_log_resume_access($employerId, $logSeekerId, $action, false, $logApplicationId, 'Plan does not allow resume access');
    http_response_code(403);
    exit('Resume access is not available on your current plan.');
}

$absolutePath = fp_resume_absolute_path($resumePath);
if ($absolutePath === null) {
    fp_log_resume_access($employerId, $logSeekerId, $action, false, $logApplicationId, 'Resume file missing');
    http_response_code(404);
    exit('Resume not found.');
}

fp_log_resume_access($employerId, $logSeekerId, $action, true, $logApplicationId);

$extension = strtolower(pathinfo($absolutePath, PATHINFO_EXTENSION));
$mimeType = fp_resume_mime_type($extension);
$inline = !$download && $extension === 'pdf';

header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($absolutePath));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');

$filename = preg_replace('/[^\w.\- ]+/u', '_', $originalName);
if ($filename === '') {
    $filename = 'resume.' . $extension;
}

$disposition = ($inline ? 'inline' : 'attachment') . '; filename="' . str_replace('"', '', $filename) . '"';
header('Content-Disposition: ' . $disposition);

readfile($absolutePath);
exit;
