<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$ctx = fp_employer_portal_start('Search Talent', 'candidates');
$profile = $ctx['profile'];

$filters = fp_build_candidate_filters($_GET);
$candidates = fp_search_candidates($filters, 50);
$total = fp_count_candidates($filters);
$canViewResume = fp_can_employer_view_resume($profile);
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Talent Pool</div>
        <h1>Search Candidates</h1>
        <p class="muted mb-0"><?php echo e($total); ?> matching profiles</p>
    </div>
</div>

<div class="panel mb-3">
    <form method="get" action="candidates.php" class="search-bar">
        <input class="form-control" type="text" name="skills" value="<?php echo e($filters['skills']); ?>" placeholder="Skills (e.g. GST, Audit)">
        <input class="form-control" type="text" name="location" value="<?php echo e($filters['location']); ?>" placeholder="Location">
        <input class="form-control" type="text" name="qualification" value="<?php echo e($filters['qualification']); ?>" placeholder="Qualification">
        <input class="form-control" type="number" min="0" step="0.5" name="experience_min" value="<?php echo e($filters['experience_min'] !== null ? (string) $filters['experience_min'] : ''); ?>" placeholder="Min experience">
        <button class="btn btn-premium" type="submit">
            <i class="fa-solid fa-magnifying-glass"></i> Search
        </button>
    </form>
</div>

<?php if (!$canViewResume): ?>
<div class="d-none" data-fp-swal-auto data-fp-swal-type="info" data-fp-swal-title="Resume access">
    Candidate profiles are visible on all plans. Resume access requires a paid employer plan.
</div>
<?php endif; ?>

<?php if (empty($candidates)): ?>
    <div class="empty-card panel">
        <i class="fa-solid fa-magnifying-glass d-block"></i>
        <h2 class="h5">No candidates found</h2>
        <p class="muted mb-0">Try broadening your search filters.</p>
    </div>
<?php else: ?>
    <?php foreach ($candidates as $candidate): ?>
        <div class="job-card">
            <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
                <div class="d-flex gap-3 flex-grow-1 min-w-0">
                    <div class="job-logo"><?php echo e(fp_company_initials($candidate['name'])); ?></div>
                    <div class="min-w-0">
                        <h2 class="h6 mb-1">
                            <a href="candidate.php?id=<?php echo (int) $candidate['id']; ?>" class="text-decoration-none text-primary">
                                <?php echo e($candidate['name']); ?>
                            </a>
                        </h2>
                        <p class="muted small mb-1"><?php echo e($candidate['headline'] ?? 'Finance professional'); ?></p>
                        <p class="small mb-2">
                            <?php echo e($candidate['experience_years']); ?> yrs &bull;
                            <?php echo e($candidate['qualification'] ?? '—'); ?> &bull;
                            <?php echo e($candidate['current_location'] ?? '—'); ?>
                        </p>
                        <p class="small mb-0 text-truncate"><?php echo e($candidate['skills'] ?? ''); ?></p>
                    </div>
                </div>
                <a href="candidate.php?id=<?php echo (int) $candidate['id']; ?>" class="btn btn-outline-custom btn-sm">View Profile</a>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<?php fp_employer_portal_end('candidates'); ?>
