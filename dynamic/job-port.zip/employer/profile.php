<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$user = fp_require_login('employer', 'login.php');
$profile = fp_ensure_employer_profile($user['id']);

$form = array(
    'name' => $user['name'],
    'phone' => $user['phone'] ?? '',
    'company_name' => $profile['company_name'] ?? '',
    'company_website' => $profile['company_website'] ?? '',
    'industry' => $profile['industry'] ?? '',
    'company_size' => $profile['company_size'] ?? '',
    'contact_person_name' => $profile['contact_person_name'] ?? '',
    'contact_designation' => $profile['contact_designation'] ?? '',
    'address_line' => $profile['address_line'] ?? '',
    'city' => $profile['city'] ?? '',
    'state' => $profile['state'] ?? '',
    'country' => $profile['country'] ?? 'India',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();
    foreach (array_keys($form) as $key) {
        $form[$key] = trim($_POST[$key] ?? '');
    }

    if ($form['company_name'] === '') {
        fp_flash('danger', 'Company name is required.');
    } else {
        try {
            fp_update_employer_user($user['id'], $form);
            fp_update_employer_profile($user['id'], $form);
            fp_flash('success', 'Company profile updated.');
            fp_redirect('profile.php');
        } catch (Throwable $exception) {
            fp_flash('danger', $exception->getMessage());
        }
    }
}

$profile = fp_employer_profile($user['id']);
fp_employer_portal_start('Company Profile', 'profile');
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Company</div>
        <h1>Company Profile</h1>
        <p class="muted mb-0">Keep your hiring brand and contact details up to date.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <span class="status-pill <?php echo ($profile['access_level'] ?? 'free') === 'paid' ? 'status-shortlisted' : 'status-reviewed'; ?>">
            <?php echo e(ucfirst($profile['access_level'] ?? 'free')); ?> plan
        </span>
        <span class="status-pill <?php echo !empty($profile['is_verified']) ? 'status-shortlisted' : 'status-applied'; ?>">
            <?php echo !empty($profile['is_verified']) ? 'Verified' : 'Pending verification'; ?>
        </span>
    </div>
</div>

<div class="panel">
    <form method="post" action="profile.php" novalidate>
        <?php echo fp_csrf_field(); ?>
        <h2 class="h5 mb-4">Account Contact</h2>
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label" for="name">Account name</label>
                <input class="form-control" type="text" id="name" name="name" value="<?php echo e($form['name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label" for="phone">Phone</label>
                <input class="form-control" type="tel" id="phone" name="phone" value="<?php echo e($form['phone']); ?>">
            </div>
        </div>

        <h2 class="h5 mb-4">Company Details</h2>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label" for="company_name">Company name</label>
                <input class="form-control" type="text" id="company_name" name="company_name" value="<?php echo e($form['company_name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label" for="company_website">Website</label>
                <input class="form-control" type="url" id="company_website" name="company_website" value="<?php echo e($form['company_website']); ?>" placeholder="https://">
            </div>
            <div class="col-md-4">
                <label class="form-label" for="industry">Industry</label>
                <input class="form-control" type="text" id="industry" name="industry" value="<?php echo e($form['industry']); ?>" placeholder="Banking, Consulting">
            </div>
            <div class="col-md-4">
                <label class="form-label" for="company_size">Company size</label>
                <input class="form-control" type="text" id="company_size" name="company_size" value="<?php echo e($form['company_size']); ?>" placeholder="50-200">
            </div>
            <div class="col-md-4">
                <label class="form-label" for="contact_person_name">Contact person</label>
                <input class="form-control" type="text" id="contact_person_name" name="contact_person_name" value="<?php echo e($form['contact_person_name']); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label" for="contact_designation">Designation</label>
                <input class="form-control" type="text" id="contact_designation" name="contact_designation" value="<?php echo e($form['contact_designation']); ?>" placeholder="HR Manager">
            </div>
            <div class="col-md-6">
                <label class="form-label" for="address_line">Address</label>
                <input class="form-control" type="text" id="address_line" name="address_line" value="<?php echo e($form['address_line']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label" for="city">City</label>
                <input class="form-control" type="text" id="city" name="city" value="<?php echo e($form['city']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label" for="state">State</label>
                <input class="form-control" type="text" id="state" name="state" value="<?php echo e($form['state']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label" for="country">Country</label>
                <input class="form-control" type="text" id="country" name="country" value="<?php echo e($form['country']); ?>">
            </div>
        </div>
        <button class="btn btn-premium w-100 w-md-auto mt-4" type="submit">
            <i class="fa-solid fa-floppy-disk"></i> Save Profile
        </button>
    </form>
</div>
<?php fp_employer_portal_end('profile'); ?>
