<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$ctx = fp_employer_portal_start('Applicants', 'applicants');
$user = $ctx['user'];
$profile = $ctx['profile'];
$employerId = (int) $profile['id'];

$jobId = (int) ($_GET['job_id'] ?? 0);
$statusFilter = trim($_GET['status'] ?? '');
if ($statusFilter !== '' && !in_array($statusFilter, array('applied', 'reviewed', 'shortlisted', 'rejected', 'hired', 'withdrawn'), true)) {
    $statusFilter = '';
}

$applications = fp_fetch_employer_applications(
    $employerId,
    $jobId > 0 ? $jobId : null,
    $statusFilter !== '' ? $statusFilter : null,
    100
);

$jobTitle = '';
if ($jobId > 0) {
    $job = fp_fetch_employer_job($jobId, $employerId);
    $jobTitle = $job ? $job['title'] : '';
}
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Hiring Pipeline</div>
        <h1>Applicants</h1>
        <p class="muted mb-0">
            <?php if ($jobTitle !== ''): ?>
                Showing applicants for <strong><?php echo e($jobTitle); ?></strong>
            <?php else: ?>
                <?php echo e(count($applications)); ?> applications across all jobs
            <?php endif; ?>
        </p>
    </div>
    <?php if ($jobId > 0): ?>
        <a href="applicants.php" class="btn btn-outline-custom">All Applicants</a>
    <?php endif; ?>
</div>

<div class="panel mb-3">
    <div class="d-flex flex-wrap gap-2">
        <a href="applicants.php<?php echo $jobId ? '?job_id=' . $jobId : ''; ?>" class="btn btn-sm <?php echo $statusFilter === '' ? 'btn-premium' : 'btn-outline-custom'; ?>">All</a>
        <?php foreach (array('applied', 'reviewed', 'shortlisted', 'rejected', 'hired') as $status): ?>
            <a href="applicants.php?<?php echo $jobId ? 'job_id=' . $jobId . '&' : ''; ?>status=<?php echo e($status); ?>"
               class="btn btn-sm <?php echo $statusFilter === $status ? 'btn-premium' : 'btn-outline-custom'; ?>">
                <?php echo e(fp_format_application_status($status)); ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<?php if (empty($applications)): ?>
    <div class="empty-card panel">
        <i class="fa-solid fa-users d-block"></i>
        <h2 class="h5">No applicants yet</h2>
        <p class="muted mb-3">Applications will appear here when candidates apply to your jobs.</p>
        <a href="jobs.php" class="btn btn-premium">Manage Jobs</a>
    </div>
<?php else: ?>
    <?php foreach ($applications as $application): ?>
        <div class="job-card">
            <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
                <div class="d-flex gap-3 flex-grow-1 min-w-0">
                    <div class="job-logo"><?php echo e(fp_company_initials($application['seeker_name'])); ?></div>
                    <div class="min-w-0">
                        <h2 class="h6 mb-1">
                            <a href="applicant.php?id=<?php echo (int) $application['id']; ?>" class="text-decoration-none text-primary">
                                <?php echo e($application['seeker_name']); ?>
                            </a>
                        </h2>
                        <p class="muted small mb-1"><?php echo e($application['job_title']); ?> &bull; <?php echo e($application['job_location']); ?></p>
                        <p class="small mb-2"><?php echo e($application['headline'] ?? 'Finance professional'); ?></p>
                        <span class="status-pill <?php echo e(fp_application_status_class($application['status'])); ?>">
                            <?php echo e(fp_format_application_status($application['status'])); ?>
                        </span>
                    </div>
                </div>
                <div class="text-end">
                    <div class="muted small">Applied</div>
                    <div class="fw-semibold small"><?php echo e(date('M j, Y', strtotime($application['applied_at']))); ?></div>
                    <a href="applicant.php?id=<?php echo (int) $application['id']; ?>" class="btn btn-outline-custom btn-sm mt-2">Review</a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<?php fp_employer_portal_end('applicants'); ?>
