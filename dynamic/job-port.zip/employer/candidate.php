<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$ctx = fp_employer_portal_start('Candidate', 'candidates');
$profile = $ctx['profile'];
$seekerId = (int) ($_GET['id'] ?? 0);

$candidate = fp_fetch_candidate_profile($seekerId);
if (!$candidate) {
    fp_flash('danger', 'Candidate not found.');
    fp_redirect('candidates.php');
}

$canViewResume = fp_can_employer_view_resume($profile);
$hasResume = !empty($candidate['resume_file_path']);
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Candidate Profile</div>
        <h1><?php echo e($candidate['name']); ?></h1>
        <p class="muted mb-0"><?php echo e($candidate['headline'] ?? 'Finance professional'); ?></p>
    </div>
    <a href="candidates.php" class="btn btn-outline-custom">Back to Search</a>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="panel">
            <div class="d-flex gap-3 mb-4">
                <div class="job-logo"><?php echo e(fp_company_initials($candidate['name'])); ?></div>
                <div>
                    <div class="fw-bold"><?php echo e($candidate['name']); ?></div>
                    <div class="muted small"><?php echo e($candidate['email']); ?></div>
                </div>
            </div>
            <div class="row g-3 small">
                <div class="col-md-6"><span class="text-muted">Phone</span><div class="fw-semibold"><?php echo e($candidate['phone'] ?? '—'); ?></div></div>
                <div class="col-md-6"><span class="text-muted">Experience</span><div class="fw-semibold"><?php echo e($candidate['experience_years']); ?> years</div></div>
                <div class="col-md-6"><span class="text-muted">Qualification</span><div class="fw-semibold"><?php echo e($candidate['qualification'] ?? '—'); ?></div></div>
                <div class="col-md-6"><span class="text-muted">Profile level</span><div class="fw-semibold text-capitalize"><?php echo e($candidate['profile_level'] ?? 'basic'); ?></div></div>
                <div class="col-md-6"><span class="text-muted">Current location</span><div class="fw-semibold"><?php echo e($candidate['current_location'] ?? '—'); ?></div></div>
                <div class="col-md-6"><span class="text-muted">Preferred location</span><div class="fw-semibold"><?php echo e($candidate['preferred_location'] ?? '—'); ?></div></div>
                <div class="col-12">
                    <span class="text-muted">Skills</span>
                    <div class="fw-semibold"><?php echo e($candidate['skills'] ?? '—'); ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="panel">
            <h2 class="h5 mb-3">Resume</h2>
            <?php if (!$hasResume): ?>
                <p class="muted mb-0">This candidate has not uploaded a resume.</p>
            <?php elseif (!$canViewResume): ?>
                <p class="muted small border rounded-4 p-3 mb-0">Upgrade to a paid plan to view resumes from the talent pool.</p>
            <?php else: ?>
                <p class="muted small mb-3"><?php echo e($candidate['resume_original_name'] ?? 'Resume'); ?></p>
                <div class="resume-actions">
                    <a href="resume-file.php?seeker_id=<?php echo (int) $seekerId; ?>" class="btn btn-premium btn-sm" target="_blank" rel="noopener">
                        <i class="fa-solid fa-eye"></i> View
                    </a>
                    <a href="resume-file.php?seeker_id=<?php echo (int) $seekerId; ?>&download=1" class="btn btn-outline-custom btn-sm">
                        <i class="fa-solid fa-download"></i> Download
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php fp_employer_portal_end('candidates'); ?>
