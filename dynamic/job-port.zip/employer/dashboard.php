<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$ctx = fp_employer_portal_start('Dashboard', 'dashboard');
$user = $ctx['user'];
$profile = $ctx['profile'];
$employerId = (int) $profile['id'];

$openJobs = fp_count_employer_jobs($employerId, 'open');
$totalJobs = fp_count_employer_jobs($employerId);
$totalApplicants = fp_count_employer_applications($employerId);
$newApplicants = fp_count_employer_applications($employerId, 'applied');
$recentApplications = fp_fetch_employer_applications($employerId, null, null, 5);
$recentJobs = fp_fetch_employer_jobs($employerId, null, 5);
$firstName = explode(' ', trim($user['name']))[0];
$canViewResume = fp_can_employer_view_resume($profile);
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Employer Dashboard</div>
        <h1>Hi, <?php echo e($firstName); ?></h1>
        <p class="muted mb-0"><?php echo e($profile['company_name']); ?> &mdash; manage jobs and review candidates.</p>
    </div>
    <a href="job-post.php" class="btn btn-premium">
        <i class="fa-solid fa-plus"></i> Post a Job
    </a>
</div>

<?php if (!$canViewResume): ?>
<div class="d-none" data-fp-swal-auto data-fp-swal-type="warning" data-fp-swal-title="Free plan">
    <strong>Free plan:</strong> Resume download is limited on the free employer plan. Upgrade to paid to view applicant resumes.
</div>
<?php endif; ?>

<div class="metric-grid">
    <div class="metric-card">
        <div class="metric-value"><?php echo e($openJobs); ?></div>
        <div class="metric-label">Open Jobs</div>
    </div>
    <div class="metric-card">
        <div class="metric-value"><?php echo e($totalApplicants); ?></div>
        <div class="metric-label">Total Applicants</div>
    </div>
    <div class="metric-card">
        <div class="metric-value"><?php echo e($newApplicants); ?></div>
        <div class="metric-label">New Applications</div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="panel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Recent Applicants</h2>
                <a href="applicants.php" class="small fw-bold">View all</a>
            </div>
            <?php if (empty($recentApplications)): ?>
                <div class="empty-card border-0 shadow-none p-4">
                    <i class="fa-solid fa-users d-block"></i>
                    <p class="muted mb-3">No applications yet. Post a job to start receiving candidates.</p>
                    <a href="job-post.php" class="btn btn-premium">Post a Job</a>
                </div>
            <?php else: ?>
                <?php foreach ($recentApplications as $application): ?>
                    <div class="job-card mb-0">
                        <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
                            <div class="d-flex gap-3 flex-grow-1 min-w-0">
                                <div class="job-logo"><?php echo e(fp_company_initials($application['seeker_name'])); ?></div>
                                <div class="min-w-0">
                                    <h3 class="h6 mb-1 text-truncate">
                                        <a href="applicant.php?id=<?php echo (int) $application['id']; ?>" class="text-decoration-none text-primary">
                                            <?php echo e($application['seeker_name']); ?>
                                        </a>
                                    </h3>
                                    <p class="muted small mb-2"><?php echo e($application['job_title']); ?></p>
                                    <span class="status-pill <?php echo e(fp_application_status_class($application['status'])); ?>">
                                        <?php echo e(fp_format_application_status($application['status'])); ?>
                                    </span>
                                </div>
                            </div>
                            <span class="muted small text-nowrap"><?php echo e(fp_time_ago($application['applied_at'])); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="panel mb-3">
            <h2 class="h6 text-muted mb-3">Account</h2>
            <div class="d-flex flex-wrap gap-2 mb-2">
                <span class="status-pill <?php echo ($profile['access_level'] ?? 'free') === 'paid' ? 'status-shortlisted' : 'status-reviewed'; ?>">
                    <?php echo e(ucfirst($profile['access_level'] ?? 'free')); ?> plan
                </span>
                <span class="status-pill <?php echo !empty($profile['is_verified']) ? 'status-shortlisted' : 'status-applied'; ?>">
                    <?php echo !empty($profile['is_verified']) ? 'Verified' : 'Pending verification'; ?>
                </span>
            </div>
            <p class="muted small mb-0"><?php echo e($totalJobs); ?> total job postings on your account.</p>
        </div>
        <div class="panel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Your Jobs</h2>
                <a href="jobs.php" class="small fw-bold">Manage</a>
            </div>
            <?php if (empty($recentJobs)): ?>
                <p class="muted mb-0">No jobs posted yet.</p>
            <?php else: ?>
                <?php foreach ($recentJobs as $job): ?>
                    <div class="d-flex justify-content-between align-items-start gap-2 mb-3 pb-3 border-bottom">
                        <div class="min-w-0">
                            <h3 class="h6 mb-1">
                                <a href="job-edit.php?id=<?php echo (int) $job['id']; ?>" class="text-decoration-none text-primary text-truncate d-block">
                                    <?php echo e($job['title']); ?>
                                </a>
                            </h3>
                            <p class="muted small mb-0"><?php echo e((int) $job['application_count']); ?> applicants</p>
                        </div>
                        <span class="status-pill <?php echo e(fp_job_status_badge_class($job['status'])); ?>">
                            <?php echo e(fp_format_job_status($job['status'])); ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php fp_employer_portal_end('dashboard'); ?>
