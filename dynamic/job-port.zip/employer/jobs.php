<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$user = fp_require_login('employer', 'login.php');
$profile = fp_ensure_employer_profile($user['id']);
$employerId = (int) $profile['id'];

$statusFilter = trim($_GET['status'] ?? '');
if ($statusFilter !== '' && !in_array($statusFilter, array('draft', 'open', 'closed'), true)) {
    $statusFilter = '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();
    $action = $_POST['action'] ?? '';
    $jobId = (int) ($_POST['job_id'] ?? 0);

    try {
        if ($action === 'close' && fp_close_employer_job($jobId, $employerId)) {
            fp_flash('success', 'Job closed successfully.');
        } elseif ($action === 'reopen' && fp_reopen_employer_job($jobId, $employerId)) {
            fp_flash('success', 'Job reopened successfully.');
        } elseif ($action === 'delete' && fp_delete_employer_job($jobId, $employerId, $user['id'])) {
            fp_flash('success', 'Job removed successfully.');
        } else {
            fp_flash('warning', 'Unable to update that job.');
        }
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }

    fp_redirect('jobs.php' . ($statusFilter !== '' ? '?status=' . urlencode($statusFilter) : ''));
}

$jobs = fp_fetch_employer_jobs($employerId, $statusFilter !== '' ? $statusFilter : null, 100);
fp_employer_portal_start('Manage Jobs', 'jobs');
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Job Listings</div>
        <h1>Manage Jobs</h1>
        <p class="muted mb-0"><?php echo e(count($jobs)); ?> job<?php echo count($jobs) === 1 ? '' : 's'; ?> found</p>
    </div>
    <a href="job-post.php" class="btn btn-premium">
        <i class="fa-solid fa-plus"></i> Post Job
    </a>
</div>

<div class="panel mb-3">
    <div class="d-flex flex-wrap gap-2">
        <a href="jobs.php" class="btn btn-sm <?php echo $statusFilter === '' ? 'btn-premium' : 'btn-outline-custom'; ?>">All</a>
        <a href="jobs.php?status=open" class="btn btn-sm <?php echo $statusFilter === 'open' ? 'btn-premium' : 'btn-outline-custom'; ?>">Open</a>
        <a href="jobs.php?status=draft" class="btn btn-sm <?php echo $statusFilter === 'draft' ? 'btn-premium' : 'btn-outline-custom'; ?>">Draft</a>
        <a href="jobs.php?status=closed" class="btn btn-sm <?php echo $statusFilter === 'closed' ? 'btn-premium' : 'btn-outline-custom'; ?>">Closed</a>
    </div>
</div>

<?php if (empty($jobs)): ?>
    <div class="empty-card panel">
        <i class="fa-solid fa-briefcase d-block"></i>
        <h2 class="h5">No jobs yet</h2>
        <p class="muted mb-3">Create your first vacancy to attract finance talent.</p>
        <a href="job-post.php" class="btn btn-premium">Post a Job</a>
    </div>
<?php else: ?>
    <?php foreach ($jobs as $job): ?>
        <div class="job-card">
            <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
                <div class="flex-grow-1 min-w-0">
                    <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
                        <h2 class="h5 mb-0">
                            <a href="job-edit.php?id=<?php echo (int) $job['id']; ?>" class="text-decoration-none text-primary">
                                <?php echo e($job['title']); ?>
                            </a>
                        </h2>
                        <span class="status-pill <?php echo e(fp_job_status_badge_class($job['status'])); ?>">
                            <?php echo e(fp_format_job_status($job['status'])); ?>
                        </span>
                    </div>
                    <p class="muted small mb-2">
                        <?php echo e($job['location']); ?> &bull;
                        <?php echo e(fp_format_job_type($job['job_type'])); ?> &bull;
                        <?php echo e((int) $job['application_count']); ?> applicants
                    </p>
                    <p class="mb-0 small"><?php echo e($job['short_description'] ?? ''); ?></p>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="applicants.php?job_id=<?php echo (int) $job['id']; ?>" class="btn btn-outline-custom btn-sm">Applicants</a>
                    <a href="job-edit.php?id=<?php echo (int) $job['id']; ?>" class="btn btn-outline-custom btn-sm">Edit</a>
                    <?php if ($job['status'] === 'open'): ?>
                        <form method="post" class="d-inline">
                            <?php echo fp_csrf_field(); ?>
                            <input type="hidden" name="action" value="close">
                            <input type="hidden" name="job_id" value="<?php echo (int) $job['id']; ?>">
                            <button type="submit" class="btn btn-outline-custom btn-sm">Close</button>
                        </form>
                    <?php elseif ($job['status'] === 'closed'): ?>
                        <form method="post" class="d-inline">
                            <?php echo fp_csrf_field(); ?>
                            <input type="hidden" name="action" value="reopen">
                            <input type="hidden" name="job_id" value="<?php echo (int) $job['id']; ?>">
                            <button type="submit" class="btn btn-outline-custom btn-sm">Reopen</button>
                        </form>
                    <?php endif; ?>
                    <form method="post" class="d-inline" data-fp-confirm="Remove this job permanently?">
                        <?php echo fp_csrf_field(); ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="job_id" value="<?php echo (int) $job['id']; ?>">
                        <button type="submit" class="btn btn-outline-custom btn-sm text-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<?php fp_employer_portal_end('jobs'); ?>
