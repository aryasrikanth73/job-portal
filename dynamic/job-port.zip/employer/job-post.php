<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$user = fp_require_login('employer', 'login.php');
$profile = fp_ensure_employer_profile($user['id']);
$employerId = (int) $profile['id'];

$jobForm = array(
    'title' => '',
    'short_description' => '',
    'description' => '',
    'responsibilities' => '',
    'requirements' => '',
    'skills_required' => '',
    'qualification_required' => '',
    'category_id' => '',
    'location' => $profile['city'] ?? '',
    'job_type' => 'full_time',
    'workplace_type' => 'hybrid',
    'experience_min_years' => '0',
    'experience_max_years' => '',
    'salary_min' => '',
    'salary_max' => '',
    'openings' => '1',
    'application_deadline' => '',
    'status' => 'open',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();
    foreach (array_keys($jobForm) as $key) {
        $jobForm[$key] = trim((string) ($_POST[$key] ?? ''));
    }

    try {
        $jobId = fp_save_job($employerId, $user['id'], $jobForm);
        fp_flash('success', 'Job posted successfully.');
        fp_redirect('job-edit.php?id=' . $jobId);
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }
}

fp_employer_portal_start('Post a Job', 'jobs');
?>
<div class="page-heading">
    <div>
        <div class="section-tag">New Vacancy</div>
        <h1>Post a Job</h1>
        <p class="muted mb-0">Publish a role to the Finance Port job board.</p>
    </div>
    <a href="jobs.php" class="btn btn-outline-custom">Back to Jobs</a>
</div>

<div class="panel">
    <form method="post" action="job-post.php" novalidate>
        <?php echo fp_csrf_field(); ?>
        <?php include __DIR__ . '/../includes/partials/employer_job_form.php'; ?>
        <button class="btn btn-premium w-100 w-md-auto mt-4" type="submit">
            <i class="fa-solid fa-paper-plane"></i> Publish Job
        </button>
    </form>
</div>
<?php fp_employer_portal_end('jobs'); ?>
