<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$user = fp_require_login('employer', 'login.php');
$profile = fp_ensure_employer_profile($user['id']);
$employerId = (int) $profile['id'];
$applicationId = (int) ($_GET['id'] ?? 0);

$application = fp_fetch_employer_application($applicationId, $employerId);
if (!$application) {
    fp_flash('danger', 'Application not found.');
    fp_redirect('applicants.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();
    $status = trim($_POST['status'] ?? '');
    $note = trim($_POST['employer_note'] ?? '');

    try {
        fp_update_application_status($applicationId, $employerId, $status, $note);
        fp_flash('success', 'Application updated.');
        fp_redirect('applicant.php?id=' . $applicationId);
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }
}

$canViewResume = fp_can_employer_view_resume($profile);
$resumePath = $application['resume_file_path'] ?: $application['seeker_resume_path'];
$statusOptions = array('applied', 'reviewed', 'shortlisted', 'rejected', 'hired');

fp_employer_portal_start('Applicant', 'applicants');
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Candidate Review</div>
        <h1><?php echo e($application['seeker_name']); ?></h1>
        <p class="muted mb-0">Applied for <?php echo e($application['job_title']); ?></p>
    </div>
    <a href="applicants.php?job_id=<?php echo (int) $application['job_id']; ?>" class="btn btn-outline-custom">Back</a>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="panel mb-3">
            <h2 class="h5 mb-3">Candidate Profile</h2>
            <div class="d-flex gap-3 mb-3">
                <div class="job-logo"><?php echo e(fp_company_initials($application['seeker_name'])); ?></div>
                <div>
                    <div class="fw-bold"><?php echo e($application['seeker_name']); ?></div>
                    <div class="muted small"><?php echo e($application['headline'] ?? ''); ?></div>
                </div>
            </div>
            <div class="row g-3 small">
                <div class="col-md-6"><span class="text-muted">Email</span><div class="fw-semibold"><?php echo e($application['seeker_email']); ?></div></div>
                <div class="col-md-6"><span class="text-muted">Phone</span><div class="fw-semibold"><?php echo e($application['seeker_phone'] ?? '—'); ?></div></div>
                <div class="col-md-6"><span class="text-muted">Experience</span><div class="fw-semibold"><?php echo e($application['experience_years']); ?> years</div></div>
                <div class="col-md-6"><span class="text-muted">Qualification</span><div class="fw-semibold"><?php echo e($application['qualification'] ?? '—'); ?></div></div>
                <div class="col-md-6"><span class="text-muted">Location</span><div class="fw-semibold"><?php echo e($application['current_location'] ?? '—'); ?></div></div>
                <div class="col-md-6"><span class="text-muted">Profile level</span><div class="fw-semibold text-capitalize"><?php echo e($application['profile_level'] ?? 'basic'); ?></div></div>
                <div class="col-12">
                    <span class="text-muted">Skills</span>
                    <div class="fw-semibold"><?php echo e($application['skills'] ?? '—'); ?></div>
                </div>
            </div>
        </div>

        <div class="panel">
            <h2 class="h5 mb-3">Resume</h2>
            <?php if (!$canViewResume): ?>
                <p class="muted small border rounded-4 p-3 mb-0">Resume access requires a paid employer plan. Contact support to upgrade.</p>
            <?php elseif (empty($resumePath)): ?>
                <p class="muted mb-0">No resume attached to this application.</p>
            <?php else: ?>
                <p class="muted small mb-3"><?php echo e($application['resume_original_name'] ?? 'Applicant resume'); ?></p>
                <div class="resume-actions" style="max-width:320px;">
                    <a href="resume-file.php?application_id=<?php echo (int) $applicationId; ?>" class="btn btn-premium btn-sm" target="_blank" rel="noopener">
                        <i class="fa-solid fa-eye"></i> View
                    </a>
                    <a href="resume-file.php?application_id=<?php echo (int) $applicationId; ?>&download=1" class="btn btn-outline-custom btn-sm">
                        <i class="fa-solid fa-download"></i> Download
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="panel">
            <h2 class="h5 mb-3">Application Status</h2>
            <form method="post" action="applicant.php?id=<?php echo (int) $applicationId; ?>">
                <?php echo fp_csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label" for="status">Status</label>
                    <select class="form-select" id="status" name="status">
                        <?php foreach ($statusOptions as $status): ?>
                            <option value="<?php echo e($status); ?>" <?php echo $application['status'] === $status ? 'selected' : ''; ?>>
                                <?php echo e(fp_format_application_status($status)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="employer_note">Internal note</label>
                    <textarea class="form-control" id="employer_note" name="employer_note" rows="4" placeholder="Notes for your hiring team"><?php echo e($application['employer_note'] ?? ''); ?></textarea>
                </div>
                <p class="muted small">Applied <?php echo e(date('M j, Y g:i A', strtotime($application['applied_at']))); ?></p>
                <button class="btn btn-premium w-100" type="submit">
                    <i class="fa-solid fa-floppy-disk"></i> Save Update
                </button>
            </form>
        </div>
    </div>
</div>
<?php fp_employer_portal_end('applicants'); ?>
