<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$user = fp_require_login('employer', 'login.php');
$profile = fp_ensure_employer_profile($user['id']);
$employerId = (int) $profile['id'];
$jobId = (int) ($_GET['id'] ?? 0);

$job = fp_fetch_employer_job($jobId, $employerId);
if (!$job) {
    fp_flash('danger', 'Job not found.');
    fp_redirect('jobs.php');
}

$jobForm = array(
    'title' => $job['title'],
    'short_description' => $job['short_description'] ?? '',
    'description' => $job['description'],
    'responsibilities' => $job['responsibilities'] ?? '',
    'requirements' => $job['requirements'] ?? '',
    'skills_required' => $job['skills_required'] ?? '',
    'qualification_required' => $job['qualification_required'] ?? '',
    'category_id' => (string) ($job['category_id'] ?? ''),
    'location' => $job['location'],
    'job_type' => $job['job_type'],
    'workplace_type' => $job['workplace_type'],
    'experience_min_years' => (string) $job['experience_min_years'],
    'experience_max_years' => $job['experience_max_years'] !== null ? (string) $job['experience_max_years'] : '',
    'salary_min' => $job['salary_min'] !== null ? (string) $job['salary_min'] : '',
    'salary_max' => $job['salary_max'] !== null ? (string) $job['salary_max'] : '',
    'openings' => (string) $job['openings'],
    'application_deadline' => $job['application_deadline'] ?? '',
    'status' => $job['status'],
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();
    foreach (array_keys($jobForm) as $key) {
        $jobForm[$key] = trim((string) ($_POST[$key] ?? ''));
    }

    try {
        fp_save_job($employerId, $user['id'], $jobForm, $jobId);
        fp_flash('success', 'Job updated successfully.');
        fp_redirect('job-edit.php?id=' . $jobId);
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }
}

fp_employer_portal_start('Edit Job', 'jobs');
?>
<div class="page-heading">
    <div>
        <div class="section-tag">Edit Listing</div>
        <h1><?php echo e($job['title']); ?></h1>
        <p class="muted mb-0">Update job details and publishing status.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="applicants.php?job_id=<?php echo (int) $jobId; ?>" class="btn btn-outline-custom">View Applicants</a>
        <a href="jobs.php" class="btn btn-outline-custom">All Jobs</a>
    </div>
</div>

<div class="panel">
    <form method="post" action="job-edit.php?id=<?php echo (int) $jobId; ?>" novalidate>
        <?php echo fp_csrf_field(); ?>
        <?php include __DIR__ . '/../includes/partials/employer_job_form.php'; ?>
        <button class="btn btn-premium w-100 w-md-auto mt-4" type="submit">
            <i class="fa-solid fa-floppy-disk"></i> Save Changes
        </button>
    </form>
</div>
<?php fp_employer_portal_end('jobs'); ?>
