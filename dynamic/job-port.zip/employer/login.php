<?php
require_once __DIR__ . '/../includes/employer_layout.php';

$existingUser = fp_current_user();
if ($existingUser && $existingUser['role'] === 'employer' && $existingUser['status'] === 'active') {
    $return = fp_sanitize_return_url(trim($_GET['return'] ?? ''));
    if ($return !== '' && strpos($return, '/') === false && preg_match('#^[a-z0-9_-]+\.php$#i', $return)) {
        fp_redirect($return);
    }
    fp_redirect('dashboard.php');
}

$email = trim($_GET['email'] ?? '');
$wrongRoleNotice = '';

if ($existingUser && $existingUser['role'] !== 'employer') {
    $wrongRoleNotice = 'You are signed in as ' . $existingUser['role'] . '. Log out from the main site first, or use an employer account.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        fp_flash('danger', 'Enter your email and password.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fp_flash('danger', 'Enter a valid email address.');
    } else {
        $statement = fp_db()->prepare("SELECT * FROM users WHERE email = ? AND role = 'employer' LIMIT 1");
        $statement->execute(array($email));
        $user = $statement->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            fp_flash('danger', 'Invalid employer login credentials.');
        } elseif ($user['status'] !== 'active') {
            fp_flash('danger', 'Your account is not active. Please contact support.');
        } else {
            fp_db()->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?')->execute(array($user['id']));
            fp_login_user($user);
            fp_flash('success', 'Welcome back, ' . $user['name'] . '.');
            $return = fp_sanitize_return_url(trim($_POST['return'] ?? $_GET['return'] ?? ''));
            if ($return !== '' && strpos($return, '/') === false && preg_match('#^[a-z0-9_-]+\.php$#i', $return)) {
                fp_redirect($return);
            }
            fp_redirect('dashboard.php');
        }
    }
}

fp_employer_auth_start('Employer Login');
?>
<section class="auth-shell">
    <div class="panel">
        <div class="mb-4 text-center text-md-start">
            <div class="section-tag">Employer</div>
            <h1 class="h3 mb-2">Employer sign in</h1>
            <p class="muted mb-0">Post jobs, review applicants, and search finance talent.</p>
        </div>

        <?php if ($wrongRoleNotice !== ''): ?>
            <?php fp_sweetalert_notice('warning', $wrongRoleNotice . ' Go to the home page and log out first.'); ?>
        <?php endif; ?>

        <div class="border rounded-4 p-3 mb-4 bg-light" style="font-size:0.88rem;">
            <strong>Demo login:</strong> <code>employer@financeport.com</code> / <code>password</code>
        </div>

        <form method="post" action="login.php<?php echo !empty($_GET['return']) ? '?return=' . urlencode(fp_sanitize_return_url($_GET['return'])) : ''; ?>" novalidate>
            <?php echo fp_csrf_field(); ?>
            <?php if (!empty($_GET['return'])): ?>
                <input type="hidden" name="return" value="<?php echo e(fp_sanitize_return_url($_GET['return'])); ?>">
            <?php endif; ?>
            <div class="mb-3">
                <label class="form-label" for="email">Email address</label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo e($email); ?>" placeholder="hr@company.com" required>
            </div>
            <div class="mb-3">
                <label class="form-label" for="password">Password</label>
                <input class="form-control" type="password" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <button class="btn btn-premium w-100 py-3" type="submit">
                <i class="fa-solid fa-arrow-right-to-bracket"></i>
                Sign In
            </button>
        </form>

        <p class="muted mt-4 mb-0">
            New employer? <a class="fw-bold text-decoration-none" href="../signup.php?role=employer">Create an employer account</a>.
        </p>
        <p class="muted mt-2 mb-0">
            Job seeker? <a class="fw-bold text-decoration-none" href="../jobseeker/login.php">Switch to job seeker login</a>.
        </p>
    </div>
</section>
<?php fp_employer_auth_end(); ?>
