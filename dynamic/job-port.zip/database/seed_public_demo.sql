-- Demo data for Finance Port (public pages + portals)
-- Safe to re-run: uses WHERE NOT EXISTS / INSERT IGNORE patterns
--
-- Demo password for ALL accounts below: password
-- Hash: $2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi
--
-- Accounts seeded:
--   Admin:    admin@financeport.com
--   Employers (5): employer@, kpmg@, ey@, hdfc@, zerodha@financeport.com
--   Job seekers (10): priya.sharma@ ... aditya.khan@financeport.com
--   Jobs: 10 open postings across employers

USE job_portal;

CREATE TABLE IF NOT EXISTS contact_inquiries (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL,
    phone VARCHAR(30) NULL,
    company_name VARCHAR(180) NULL,
    profile_type VARCHAR(50) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_contact_inquiries_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @pwd = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

-- ---------------------------------------------------------------------------
-- Admin
-- ---------------------------------------------------------------------------
INSERT INTO users (role, name, email, password_hash, status)
SELECT 'admin', 'Platform Admin', 'admin@financeport.com', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@financeport.com');

-- ---------------------------------------------------------------------------
-- Employers (5)
-- ---------------------------------------------------------------------------
INSERT INTO users (role, name, email, password_hash, status)
SELECT 'employer', 'Deloitte Hiring', 'employer@financeport.com', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'employer@financeport.com');

INSERT INTO users (role, name, email, password_hash, status)
SELECT 'employer', 'KPMG Talent', 'kpmg@financeport.com', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'kpmg@financeport.com');

INSERT INTO users (role, name, email, password_hash, status)
SELECT 'employer', 'EY Recruiting', 'ey@financeport.com', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'ey@financeport.com');

INSERT INTO users (role, name, email, password_hash, status)
SELECT 'employer', 'HDFC Careers', 'hdfc@financeport.com', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'hdfc@financeport.com');

INSERT INTO users (role, name, email, password_hash, status)
SELECT 'employer', 'Zerodha HR', 'zerodha@financeport.com', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'zerodha@financeport.com');

INSERT INTO employer_profiles (user_id, company_name, industry, city, country, access_level, is_verified)
SELECT u.id, 'Deloitte', 'Consulting', 'Mumbai', 'India', 'paid', 1
FROM users u
WHERE u.email = 'employer@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM employer_profiles ep WHERE ep.user_id = u.id);

INSERT INTO employer_profiles (user_id, company_name, industry, city, country, access_level, is_verified)
SELECT u.id, 'KPMG India', 'Audit & Advisory', 'Bengaluru', 'India', 'paid', 1
FROM users u
WHERE u.email = 'kpmg@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM employer_profiles ep WHERE ep.user_id = u.id);

INSERT INTO employer_profiles (user_id, company_name, industry, city, country, access_level, is_verified)
SELECT u.id, 'EY India', 'Consulting', 'Hyderabad', 'India', 'paid', 1
FROM users u
WHERE u.email = 'ey@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM employer_profiles ep WHERE ep.user_id = u.id);

INSERT INTO employer_profiles (user_id, company_name, industry, city, country, access_level, is_verified)
SELECT u.id, 'HDFC Bank', 'Banking', 'Mumbai', 'India', 'paid', 1
FROM users u
WHERE u.email = 'hdfc@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM employer_profiles ep WHERE ep.user_id = u.id);

INSERT INTO employer_profiles (user_id, company_name, industry, city, country, access_level, is_verified)
SELECT u.id, 'Zerodha', 'FinTech', 'Bengaluru', 'India', 'paid', 1
FROM users u
WHERE u.email = 'zerodha@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM employer_profiles ep WHERE ep.user_id = u.id);

-- ---------------------------------------------------------------------------
-- Job seekers (10)
-- ---------------------------------------------------------------------------
INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Priya Sharma', 'priya.sharma@financeport.com', '+91 98765 43210', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'priya.sharma@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Rahul Mehta', 'rahul.mehta@financeport.com', '+91 98765 43211', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'rahul.mehta@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Ananya Iyer', 'ananya.iyer@financeport.com', '+91 98765 43212', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'ananya.iyer@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Vikram Singh', 'vikram.singh@financeport.com', '+91 98765 43213', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'vikram.singh@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Sneha Reddy', 'sneha.reddy@financeport.com', '+91 98765 43214', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'sneha.reddy@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Arjun Nair', 'arjun.nair@financeport.com', '+91 98765 43215', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'arjun.nair@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Kavya Patel', 'kavya.patel@financeport.com', '+91 98765 43216', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'kavya.patel@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Rohit Gupta', 'rohit.gupta@financeport.com', '+91 98765 43217', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'rohit.gupta@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Meera Joshi', 'meera.joshi@financeport.com', '+91 98765 43218', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'meera.joshi@financeport.com');

INSERT INTO users (role, name, email, phone, password_hash, status)
SELECT 'job_seeker', 'Aditya Khan', 'aditya.khan@financeport.com', '+91 98765 43219', @pwd, 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'aditya.khan@financeport.com');

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Chartered Accountant | GST & Direct Tax', 'GST,Direct Tax,Tally,Excel,Compliance', 4.0, 'CA', 'Mumbai', 'Mumbai, Pune', 'skilled'
FROM users u WHERE u.email = 'priya.sharma@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Financial Analyst | FP&A', 'Financial Modeling,Excel,Power BI,Reporting,MIS', 3.0, 'MBA Finance', 'Bengaluru', 'Bengaluru, Remote', 'skilled'
FROM users u WHERE u.email = 'rahul.mehta@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Audit Associate | Big 4 Aspirant', 'Internal Audit,Risk,MS Excel,Documentation', 2.0, 'B.Com', 'Chennai', 'Chennai, Hyderabad', 'skilled'
FROM users u WHERE u.email = 'ananya.iyer@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Investment Banking Analyst', 'Valuation,M&A,DCF,Pitch Decks,Research', 5.0, 'CFA Level II', 'Mumbai', 'Mumbai', 'skilled'
FROM users u WHERE u.email = 'vikram.singh@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Accounts Executive', 'Bookkeeping,Accounts Payable,Receivables,Tally', 1.5, 'B.Com', 'Hyderabad', 'Hyderabad', 'skilled'
FROM users u WHERE u.email = 'sneha.reddy@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Risk & Compliance Officer', 'Risk Assessment,AML,KYC,Regulatory Reporting', 6.0, 'MBA', 'Kochi', 'Kochi, Bengaluru', 'skilled'
FROM users u WHERE u.email = 'arjun.nair@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'FinTech Product Analyst', 'SQL,Python,Payments,UPI,Product Analytics', 2.5, 'B.Tech', 'Pune', 'Pune, Remote', 'skilled'
FROM users u WHERE u.email = 'kavya.patel@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Tax Consultant | Transfer Pricing', 'Transfer Pricing,Corporate Tax,Research,Documentation', 4.5, 'CA', 'Delhi', 'Delhi NCR', 'skilled'
FROM users u WHERE u.email = 'rohit.gupta@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Insurance Underwriter', 'Underwriting,Actuarial Basics,Policy Analysis', 3.5, 'B.Com', 'Ahmedabad', 'Ahmedabad, Mumbai', 'skilled'
FROM users u WHERE u.email = 'meera.joshi@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

INSERT INTO job_seeker_profiles (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
SELECT u.id, 'Fresh Finance Graduate', 'Excel,Accounting Basics,Communication', 0.0, 'B.Com', 'Jaipur', 'Jaipur, Remote', 'basic'
FROM users u WHERE u.email = 'aditya.khan@financeport.com'
  AND NOT EXISTS (SELECT 1 FROM job_seeker_profiles p WHERE p.user_id = u.id);

-- ---------------------------------------------------------------------------
-- Jobs (10 open postings)
-- ---------------------------------------------------------------------------

-- 1. Deloitte — Senior Tax Consultant
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'taxation' LIMIT 1),
    'Senior Tax Consultant',
    'senior-tax-consultant-deloitte',
    'Lead corporate tax engagements for enterprise clients.',
    'We are looking for a Senior Tax Consultant to manage compliance, advisory, and planning assignments for large corporate clients. You will work with cross-functional teams and mentor junior staff.',
    'Corporate Tax,Compliance,GST,CPA',
    'CA,CPA',
    5, 8,
    'Mumbai, India', 'full_time', 'hybrid', 1200000, 1600000, 'INR',
    'open', NOW()
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'employer@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'senior-tax-consultant-deloitte');

-- 2. Deloitte — Financial Analyst
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'banking' LIMIT 1),
    'Financial Analyst',
    'financial-analyst-deloitte',
    'Support investment analysis and financial modeling.',
    'Join our finance team to build models, prepare board reports, and support strategic decisions across business units.',
    'Financial Modeling,Excel,M&A,Reporting',
    'MBA Finance',
    2, 4,
    'Bengaluru, India', 'full_time', 'onsite', 900000, 1200000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 5 HOUR)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'employer@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'financial-analyst-deloitte');

-- 3. Deloitte — Management Consultant
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'consulting' LIMIT 1),
    'Management Consultant',
    'management-consultant-deloitte',
    'Solve complex business problems for Fortune 500 clients.',
    'Work on strategy, operations, and digital transformation projects. Strong client-facing skills and structured problem solving required.',
    'Strategy,Operations,Client Management,PowerPoint',
    'MBA',
    3, 6,
    'Mumbai, India', 'full_time', 'hybrid', 1400000, 2000000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 2 DAY)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'employer@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'management-consultant-deloitte');

-- 4. KPMG — Internal Auditor
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'audit' LIMIT 1),
    'Internal Auditor',
    'internal-auditor-kpmg',
    'Drive internal audit programs and risk assessments.',
    'Plan and execute audit assignments, document findings, and partner with business leaders on remediation plans.',
    'Internal Audit,Risk Assessment,CA',
    'CA',
    4, 7,
    'Hyderabad, India', 'full_time', 'remote', 1100000, 1450000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 1 DAY)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'kpmg@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'internal-auditor-kpmg');

-- 5. KPMG — GST Analyst
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'taxation' LIMIT 1),
    'GST Analyst',
    'gst-analyst-kpmg',
    'Handle GST compliance and advisory for mid-market clients.',
    'Prepare returns, reconcile ITC, respond to notices, and support client workshops on GST updates.',
    'GST,Compliance,Tally,Excel',
    'CA,CS',
    1, 3,
    'Bengaluru, India', 'full_time', 'onsite', 600000, 900000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 8 HOUR)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'kpmg@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'gst-analyst-kpmg');

-- 6. EY — Audit Associate
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'audit' LIMIT 1),
    'Audit Associate',
    'audit-associate-ey',
    'Join our assurance practice on listed company audits.',
    'Execute audit procedures, test controls, document workpapers, and collaborate with engagement teams during busy season.',
    'Audit,Excel,Documentation,IFRS',
    'CA Inter,CA',
    0, 2,
    'Hyderabad, India', 'full_time', 'onsite', 500000, 750000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 12 HOUR)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'ey@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'audit-associate-ey');

-- 7. HDFC Bank — Relationship Manager
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'banking' LIMIT 1),
    'Relationship Manager — Corporate Banking',
    'relationship-manager-hdfc',
    'Manage corporate client portfolios and drive cross-sell.',
    'Acquire and deepen relationships with SME and corporate clients. Coordinate credit, treasury, and trade finance solutions.',
    'Sales,Credit Analysis,CRM,Banking Products',
    'MBA Finance',
    4, 8,
    'Mumbai, India', 'full_time', 'onsite', 1000000, 1500000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 3 DAY)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'hdfc@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'relationship-manager-hdfc');

-- 8. HDFC Bank — Credit Risk Analyst
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'banking' LIMIT 1),
    'Credit Risk Analyst',
    'credit-risk-analyst-hdfc',
    'Assess creditworthiness and monitor portfolio risk.',
    'Build scorecards, analyze financial statements, and prepare risk reports for retail and SME lending portfolios.',
    'Credit Risk,SQL,Excel,Financial Analysis',
    'MBA,CQF',
    2, 5,
    'Mumbai, India', 'full_time', 'hybrid', 850000, 1150000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 6 HOUR)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'hdfc@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'credit-risk-analyst-hdfc');

-- 9. Zerodha — Equity Research Analyst
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'investment' LIMIT 1),
    'Equity Research Analyst',
    'equity-research-analyst-zerodha',
    'Publish research on listed Indian equities.',
    'Build financial models, write initiation reports, and present investment theses to retail and institutional audiences.',
    'Equity Research,Valuation,Writing,Python',
    'CFA,MBA Finance',
    2, 5,
    'Bengaluru, India', 'full_time', 'hybrid', 950000, 1300000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 18 HOUR)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'zerodha@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'equity-research-analyst-zerodha');

-- 10. Zerodha — FinTech Backend Engineer (Finance domain)
INSERT INTO jobs (
    employer_id, category_id, title, slug, short_description, description,
    skills_required, qualification_required, experience_min_years, experience_max_years,
    location, job_type, workplace_type, salary_min, salary_max, salary_currency,
    status, posted_at
)
SELECT ep.id, (SELECT id FROM job_categories WHERE slug = 'fintech' LIMIT 1),
    'Payments Operations Specialist',
    'payments-ops-specialist-zerodha',
    'Oversee payment reconciliations and settlement workflows.',
    'Monitor UPI, NEFT, and wallet settlements. Coordinate with banks and payment gateways to resolve discrepancies.',
    'Payments,Reconciliation,Operations,Excel',
    'B.Com,MBA',
    1, 4,
    'Bengaluru, India', 'full_time', 'onsite', 550000, 800000, 'INR',
    'open', DATE_SUB(NOW(), INTERVAL 4 DAY)
FROM employer_profiles ep
INNER JOIN users u ON u.id = ep.user_id AND u.email = 'zerodha@financeport.com'
WHERE NOT EXISTS (SELECT 1 FROM jobs WHERE slug = 'payments-ops-specialist-zerodha');

-- ---------------------------------------------------------------------------
-- Demo job applications (for employer portal testing)
-- ---------------------------------------------------------------------------
INSERT INTO job_applications (job_id, job_seeker_id, resume_file_path, status, applied_at)
SELECT j.id, jsp.id, jsp.resume_file_path, 'applied', DATE_SUB(NOW(), INTERVAL 2 DAY)
FROM jobs j
INNER JOIN employer_profiles ep ON ep.id = j.employer_id
INNER JOIN users eu ON eu.id = ep.user_id AND eu.email = 'employer@financeport.com'
INNER JOIN users su ON su.email = 'priya.sharma@financeport.com'
INNER JOIN job_seeker_profiles jsp ON jsp.user_id = su.id
WHERE j.slug = 'senior-tax-consultant-deloitte'
  AND NOT EXISTS (
      SELECT 1 FROM job_applications ja WHERE ja.job_id = j.id AND ja.job_seeker_id = jsp.id
  );

INSERT INTO job_applications (job_id, job_seeker_id, resume_file_path, status, applied_at)
SELECT j.id, jsp.id, jsp.resume_file_path, 'reviewed', DATE_SUB(NOW(), INTERVAL 5 DAY)
FROM jobs j
INNER JOIN employer_profiles ep ON ep.id = j.employer_id
INNER JOIN users eu ON eu.id = ep.user_id AND eu.email = 'employer@financeport.com'
INNER JOIN users su ON su.email = 'rohit.gupta@financeport.com'
INNER JOIN job_seeker_profiles jsp ON jsp.user_id = su.id
WHERE j.slug = 'financial-analyst-deloitte'
  AND NOT EXISTS (
      SELECT 1 FROM job_applications ja WHERE ja.job_id = j.id AND ja.job_seeker_id = jsp.id
  );

INSERT INTO job_applications (job_id, job_seeker_id, resume_file_path, status, applied_at)
SELECT j.id, jsp.id, jsp.resume_file_path, 'shortlisted', DATE_SUB(NOW(), INTERVAL 1 DAY)
FROM jobs j
INNER JOIN employer_profiles ep ON ep.id = j.employer_id
INNER JOIN users eu ON eu.id = ep.user_id AND eu.email = 'kpmg@financeport.com'
INNER JOIN users su ON su.email = 'ananya.iyer@financeport.com'
INNER JOIN job_seeker_profiles jsp ON jsp.user_id = su.id
WHERE j.slug = 'internal-auditor-kpmg'
  AND NOT EXISTS (
      SELECT 1 FROM job_applications ja WHERE ja.job_id = j.id AND ja.job_seeker_id = jsp.id
  );

INSERT INTO job_applications (job_id, job_seeker_id, resume_file_path, status, applied_at)
SELECT j.id, jsp.id, jsp.resume_file_path, 'applied', DATE_SUB(NOW(), INTERVAL 3 DAY)
FROM jobs j
INNER JOIN employer_profiles ep ON ep.id = j.employer_id
INNER JOIN users eu ON eu.id = ep.user_id AND eu.email = 'hdfc@financeport.com'
INNER JOIN users su ON su.email = 'rahul.mehta@financeport.com'
INNER JOIN job_seeker_profiles jsp ON jsp.user_id = su.id
WHERE j.slug = 'relationship-manager-hdfc'
  AND NOT EXISTS (
      SELECT 1 FROM job_applications ja WHERE ja.job_id = j.id AND ja.job_seeker_id = jsp.id
  );

