-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2026 at 12:49 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_settings`
--

CREATE TABLE `admin_settings` (
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value_type` enum('string','number','boolean','json') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'string',
  `updated_by_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_settings`
--

INSERT INTO `admin_settings` (`setting_key`, `setting_value`, `value_type`, `updated_by_user_id`, `updated_at`) VALUES
('allow_public_signup', '1', 'boolean', NULL, '2026-06-27 12:32:46'),
('free_employer_can_view_resume', '0', 'boolean', NULL, '2026-06-27 12:32:46'),
('max_resume_upload_mb', '5', 'number', NULL, '2026-06-27 12:32:46'),
('site_name', 'Finance Port', 'string', NULL, '2026-06-27 12:32:46');

-- --------------------------------------------------------

--
-- Table structure for table `contact_inquiries`
--

CREATE TABLE `contact_inquiries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employer_profiles`
--

CREATE TABLE `employer_profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `company_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_size` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_designation` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'India',
  `access_level` enum('free','paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `subscription_started_at` datetime DEFAULT NULL,
  `subscription_expires_at` datetime DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `verification_notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employer_profiles`
--

INSERT INTO `employer_profiles` (`id`, `user_id`, `company_name`, `company_website`, `industry`, `company_size`, `contact_person_name`, `contact_designation`, `address_line`, `city`, `state`, `country`, `access_level`, `subscription_started_at`, `subscription_expires_at`, `is_verified`, `verification_notes`, `created_at`, `updated_at`) VALUES
(1, 2, 'Deloitte', NULL, 'Consulting', NULL, NULL, NULL, NULL, 'Mumbai', NULL, 'India', 'paid', NULL, NULL, 1, NULL, '2026-06-30 11:49:16', '2026-06-30 11:49:16'),
(2, 3, 'KPMG India', NULL, 'Audit & Advisory', NULL, NULL, NULL, NULL, 'Bengaluru', NULL, 'India', 'paid', NULL, NULL, 1, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(3, 4, 'EY India', NULL, 'Consulting', NULL, NULL, NULL, NULL, 'Hyderabad', NULL, 'India', 'paid', NULL, NULL, 1, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(4, 5, 'HDFC Bank', NULL, 'Banking', NULL, NULL, NULL, NULL, 'Mumbai', NULL, 'India', 'paid', NULL, NULL, 1, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(5, 6, 'Zerodha', NULL, 'FinTech', NULL, NULL, NULL, NULL, 'Bengaluru', NULL, 'India', 'paid', NULL, NULL, 1, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employer_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsibilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requirements` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skills_required` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qualification_required` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experience_min_years` decimal(4,1) UNSIGNED NOT NULL DEFAULT 0.0,
  `experience_max_years` decimal(4,1) UNSIGNED DEFAULT NULL,
  `location` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_type` enum('full_time','part_time','contract','internship','temporary') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full_time',
  `workplace_type` enum('onsite','remote','hybrid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'onsite',
  `salary_min` decimal(12,2) DEFAULT NULL,
  `salary_max` decimal(12,2) DEFAULT NULL,
  `salary_currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `openings` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `application_deadline` date DEFAULT NULL,
  `status` enum('draft','open','closed','deleted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `posted_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `employer_id`, `category_id`, `created_by_user_id`, `title`, `slug`, `short_description`, `description`, `responsibilities`, `requirements`, `skills_required`, `qualification_required`, `experience_min_years`, `experience_max_years`, `location`, `job_type`, `workplace_type`, `salary_min`, `salary_max`, `salary_currency`, `openings`, `application_deadline`, `status`, `posted_at`, `deleted_at`, `deleted_by_user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, NULL, 'Senior Tax Consultant', 'senior-tax-consultant-deloitte', 'Lead corporate tax engagements for enterprise clients.', 'We are looking for a Senior Tax Consultant to manage compliance, advisory, and planning assignments for large corporate clients. You will work with cross-functional teams and mentor junior staff.', NULL, NULL, 'Corporate Tax,Compliance,GST,CPA', 'CA,CPA', '5.0', '8.0', 'Mumbai, India', 'full_time', 'hybrid', '1200000.00', '1600000.00', 'INR', 1, NULL, 'open', '2026-06-30 11:49:16', NULL, NULL, '2026-06-30 11:49:16', '2026-06-30 11:49:16'),
(2, 1, 4, NULL, 'Financial Analyst', 'financial-analyst-goldman', 'Support investment analysis and financial modeling.', 'Join our finance team to build models, prepare board reports, and support strategic decisions across business units.', NULL, NULL, 'Financial Modeling,Excel,M&A,Reporting', 'MBA Finance', '2.0', '4.0', 'Bengaluru, India', 'full_time', 'onsite', '900000.00', '1200000.00', 'INR', 1, NULL, 'open', '2026-06-30 06:49:16', NULL, NULL, '2026-06-30 11:49:16', '2026-06-30 11:49:16'),
(3, 1, 3, NULL, 'Internal Auditor', 'internal-auditor-kpmg', 'Drive internal audit programs and risk assessments.', 'Plan and execute audit assignments, document findings, and partner with business leaders on remediation plans.', NULL, NULL, 'Internal Audit,Risk Assessment,CA', 'CA', '4.0', '7.0', 'Hyderabad, India', 'full_time', 'remote', '1100000.00', '1450000.00', 'INR', 1, NULL, 'deleted', '2026-06-29 11:49:16', '2026-06-30 16:46:30', 2, '2026-06-30 11:49:16', '2026-06-30 16:46:30'),
(4, 1, 4, NULL, 'Financial Analyst', 'financial-analyst-deloitte', 'Support investment analysis and financial modeling.', 'Join our finance team to build models, prepare board reports, and support strategic decisions across business units.', NULL, NULL, 'Financial Modeling,Excel,M&A,Reporting', 'MBA Finance', '2.0', '4.0', 'Bengaluru, India', 'full_time', 'onsite', '900000.00', '1200000.00', 'INR', 1, NULL, 'open', '2026-06-30 06:53:17', NULL, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(5, 1, 8, NULL, 'Management Consultant', 'management-consultant-deloitte', 'Solve complex business problems for Fortune 500 clients.', 'Work on strategy, operations, and digital transformation projects. Strong client-facing skills and structured problem solving required.', NULL, NULL, 'Strategy,Operations,Client Management,PowerPoint', 'MBA', '3.0', '6.0', 'Mumbai, India', 'full_time', 'hybrid', '1400000.00', '2000000.00', 'INR', 1, NULL, 'deleted', '2026-06-28 11:53:17', '2026-06-30 16:39:23', 2, '2026-06-30 11:53:17', '2026-06-30 16:39:23'),
(6, 2, 2, NULL, 'GST Analyst', 'gst-analyst-kpmg', 'Handle GST compliance and advisory for mid-market clients.', 'Prepare returns, reconcile ITC, respond to notices, and support client workshops on GST updates.', NULL, NULL, 'GST,Compliance,Tally,Excel', 'CA,CS', '1.0', '3.0', 'Bengaluru, India', 'full_time', 'onsite', '600000.00', '900000.00', 'INR', 1, NULL, 'open', '2026-06-30 03:53:17', NULL, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(7, 3, 3, NULL, 'Audit Associate', 'audit-associate-ey', 'Join our assurance practice on listed company audits.', 'Execute audit procedures, test controls, document workpapers, and collaborate with engagement teams during busy season.', NULL, NULL, 'Audit,Excel,Documentation,IFRS', 'CA Inter,CA', '0.0', '2.0', 'Hyderabad, India', 'full_time', 'onsite', '500000.00', '750000.00', 'INR', 1, NULL, 'open', '2026-06-29 23:53:17', NULL, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(8, 4, 4, NULL, 'Relationship Manager — Corporate Banking', 'relationship-manager-hdfc', 'Manage corporate client portfolios and drive cross-sell.', 'Acquire and deepen relationships with SME and corporate clients. Coordinate credit, treasury, and trade finance solutions.', NULL, NULL, 'Sales,Credit Analysis,CRM,Banking Products', 'MBA Finance', '4.0', '8.0', 'Mumbai, India', 'full_time', 'onsite', '1000000.00', '1500000.00', 'INR', 1, NULL, 'open', '2026-06-27 11:53:17', NULL, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(9, 4, 4, NULL, 'Credit Risk Analyst', 'credit-risk-analyst-hdfc', 'Assess creditworthiness and monitor portfolio risk.', 'Build scorecards, analyze financial statements, and prepare risk reports for retail and SME lending portfolios.', NULL, NULL, 'Credit Risk,SQL,Excel,Financial Analysis', 'MBA,CQF', '2.0', '5.0', 'Mumbai, India', 'full_time', 'hybrid', '850000.00', '1150000.00', 'INR', 1, NULL, 'open', '2026-06-30 05:53:17', NULL, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(10, 5, 5, NULL, 'Equity Research Analyst', 'equity-research-analyst-zerodha', 'Publish research on listed Indian equities.', 'Build financial models, write initiation reports, and present investment theses to retail and institutional audiences.', NULL, NULL, 'Equity Research,Valuation,Writing,Python', 'CFA,MBA Finance', '2.0', '5.0', 'Bengaluru, India', 'full_time', 'hybrid', '950000.00', '1300000.00', 'INR', 1, NULL, 'open', '2026-06-29 17:53:17', NULL, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(11, 5, 6, NULL, 'Payments Operations Specialist', 'payments-ops-specialist-zerodha', 'Oversee payment reconciliations and settlement workflows.', 'Monitor UPI, NEFT, and wallet settlements. Coordinate with banks and payment gateways to resolve discrepancies.', NULL, NULL, 'Payments,Reconciliation,Operations,Excel', 'B.Com,MBA', '1.0', '4.0', 'Bengaluru, India', 'full_time', 'onsite', '550000.00', '800000.00', 'INR', 1, NULL, 'open', '2026-06-26 11:53:17', NULL, NULL, '2026-06-30 11:53:17', '2026-06-30 11:53:17');

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_id` bigint(20) UNSIGNED NOT NULL,
  `job_seeker_id` bigint(20) UNSIGNED NOT NULL,
  `cover_letter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resume_file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('applied','reviewed','shortlisted','rejected','hired','withdrawn') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'applied',
  `employer_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applied_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_applications`
--

INSERT INTO `job_applications` (`id`, `job_id`, `job_seeker_id`, `cover_letter`, `resume_file_path`, `status`, `employer_note`, `applied_at`, `updated_at`) VALUES
(1, 1, 1, NULL, 'uploads/resumes/resume_7_20260630123043_d4e7ce9f.pdf', 'applied', NULL, '2026-06-28 16:32:10', '2026-06-30 16:32:10'),
(2, 4, 8, NULL, NULL, 'reviewed', NULL, '2026-06-25 16:32:10', '2026-06-30 16:32:10'),
(3, 8, 2, NULL, NULL, 'applied', NULL, '2026-06-27 16:32:10', '2026-06-30 16:32:10');

-- --------------------------------------------------------

--
-- Table structure for table `job_categories`
--

CREATE TABLE `job_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_categories`
--

INSERT INTO `job_categories` (`id`, `name`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Accounting', 'accounting', 'active', '2026-06-27 12:32:46', '2026-06-27 12:32:46'),
(2, 'Taxation', 'taxation', 'active', '2026-06-27 12:32:46', '2026-06-27 12:32:46'),
(3, 'Audit', 'audit', 'active', '2026-06-27 12:32:46', '2026-06-27 12:32:46'),
(4, 'Banking', 'banking', 'active', '2026-06-27 12:32:46', '2026-06-27 12:32:46'),
(5, 'Investment', 'investment', 'active', '2026-06-27 12:32:46', '2026-06-27 12:32:46'),
(6, 'FinTech', 'fintech', 'active', '2026-06-27 12:32:46', '2026-06-27 12:32:46'),
(7, 'Insurance', 'insurance', 'active', '2026-06-27 12:32:46', '2026-06-27 12:32:46'),
(8, 'Consulting', 'consulting', 'active', '2026-06-27 12:32:46', '2026-06-27 12:32:46');

-- --------------------------------------------------------

--
-- Table structure for table `job_seeker_profiles`
--

CREATE TABLE `job_seeker_profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `headline` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skills` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experience_years` decimal(4,1) UNSIGNED NOT NULL DEFAULT 0.0,
  `qualification` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferred_location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_level` enum('basic','skilled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'basic',
  `resume_file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resume_original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resume_uploaded_at` datetime DEFAULT NULL,
  `visibility` enum('public','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_seeker_profiles`
--

INSERT INTO `job_seeker_profiles` (`id`, `user_id`, `headline`, `summary`, `skills`, `experience_years`, `qualification`, `current_location`, `preferred_location`, `profile_level`, `resume_file_path`, `resume_original_name`, `resume_uploaded_at`, `visibility`, `created_at`, `updated_at`) VALUES
(1, 7, 'Chartered Accountant | GST & Direct Tax', NULL, 'GST,Direct Tax,Tally,Excel,Compliance', '4.0', 'CA', 'Mumbai', 'Mumbai, Pune', 'skilled', 'uploads/resumes/resume_7_20260630123043_d4e7ce9f.pdf', 'srikanth-arya-web-dev.pdf', '2026-06-30 16:00:43', 'public', '2026-06-30 11:53:17', '2026-06-30 16:00:43'),
(2, 8, 'Financial Analyst | FP&A', NULL, 'Financial Modeling,Excel,Power BI,Reporting,MIS', '3.0', 'MBA Finance', 'Bengaluru', 'Bengaluru, Remote', 'skilled', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(3, 9, 'Audit Associate | Big 4 Aspirant', NULL, 'Internal Audit,Risk,MS Excel,Documentation', '2.0', 'B.Com', 'Chennai', 'Chennai, Hyderabad', 'skilled', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(4, 10, 'Investment Banking Analyst', NULL, 'Valuation,M&A,DCF,Pitch Decks,Research', '5.0', 'CFA Level II', 'Mumbai', 'Mumbai', 'skilled', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(5, 11, 'Accounts Executive', NULL, 'Bookkeeping,Accounts Payable,Receivables,Tally', '1.5', 'B.Com', 'Hyderabad', 'Hyderabad', 'skilled', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(6, 12, 'Risk & Compliance Officer', NULL, 'Risk Assessment,AML,KYC,Regulatory Reporting', '6.0', 'MBA', 'Kochi', 'Kochi, Bengaluru', 'skilled', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(7, 13, 'FinTech Product Analyst', NULL, 'SQL,Python,Payments,UPI,Product Analytics', '2.5', 'B.Tech', 'Pune', 'Pune, Remote', 'skilled', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(8, 14, 'Tax Consultant | Transfer Pricing', NULL, 'Transfer Pricing,Corporate Tax,Research,Documentation', '4.5', 'CA', 'Delhi', 'Delhi NCR', 'skilled', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(9, 15, 'Insurance Underwriter', NULL, 'Underwriting,Actuarial Basics,Policy Analysis', '3.5', 'B.Com', 'Ahmedabad', 'Ahmedabad, Mumbai', 'skilled', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17'),
(10, 16, 'Fresh Finance Graduate', NULL, 'Excel,Accounting Basics,Communication', '0.0', 'B.Com', 'Jaipur', 'Jaipur, Remote', 'basic', NULL, NULL, NULL, 'public', '2026-06-30 11:53:17', '2026-06-30 11:53:17');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`id`, `user_id`, `token_hash`, `expires_at`, `used_at`, `created_at`) VALUES
(1, 7, 'b21f586372959de6949dd5dba43d61e662d9e5a8489b83238a29aae845c7fc55', '2026-07-02 12:06:27', '2026-07-02 14:58:29', '2026-07-02 14:36:27'),
(2, 7, 'cb5c6ec1ed10cd1d8a80ae6dc9e315e2578f7e55138cc4f52114ce234fec134c', '2026-07-02 12:11:16', '2026-07-02 14:58:29', '2026-07-02 14:41:16'),
(3, 7, '77682aac372e5f6a21592dbd91d1d4f555d8d38d769f1fc2f61250152816c103', '2026-07-02 12:13:42', '2026-07-02 14:58:29', '2026-07-02 14:43:42'),
(4, 7, 'd4d062576f39a73f6a50161550e33ac2632547f2a5c012a7546161455c7197ae', '2026-07-02 12:13:45', '2026-07-02 14:58:29', '2026-07-02 14:43:45'),
(5, 7, '754dc91a8adc9f6e774fe40576b46eae7459b4dcb5ca0581ad9784b332b1958a', '2026-07-02 12:13:59', '2026-07-02 14:58:29', '2026-07-02 14:43:59'),
(6, 7, '0e97c3fa17c9108969fa71a5c4c1a861f89d8daeec4c6aef477c90a40b785501', '2026-07-02 12:18:53', '2026-07-02 14:58:29', '2026-07-02 14:48:53'),
(7, 7, '17c1ca61e617ecc29a1b746c12349971ddb5e194e1318dd7e019914954c1755b', '2026-07-02 15:51:29', '2026-07-02 14:56:26', '2026-07-02 14:51:29'),
(8, 7, 'fcccb5ac48055f706f091111a5f8c3ed5a993fc3d6c78bac9349384b7e71ffd0', '2026-07-02 15:56:26', '2026-07-02 14:58:29', '2026-07-02 14:56:26');

-- --------------------------------------------------------

--
-- Table structure for table `resume_access_logs`
--

CREATE TABLE `resume_access_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employer_id` bigint(20) UNSIGNED NOT NULL,
  `job_seeker_id` bigint(20) UNSIGNED NOT NULL,
  `application_id` bigint(20) UNSIGNED DEFAULT NULL,
  `action` enum('view_profile','view_resume','download_resume') COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_granted` tinyint(1) NOT NULL DEFAULT 0,
  `denial_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `resume_access_logs`
--

INSERT INTO `resume_access_logs` (`id`, `employer_id`, `job_seeker_id`, `application_id`, `action`, `access_granted`, `denial_reason`, `created_at`) VALUES
(1, 1, 1, 1, 'view_resume', 1, NULL, '2026-06-30 16:36:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role` enum('job_seeker','employer','admin') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','blocked','deleted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `blocked_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blocked_at` datetime DEFAULT NULL,
  `blocked_by_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `name`, `email`, `phone`, `password_hash`, `status`, `blocked_reason`, `blocked_at`, `blocked_by_user_id`, `email_verified_at`, `last_login_at`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Platform Admin', 'admin@yopmail.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, '2026-06-30 17:14:55', '2026-06-30 11:24:06', '2026-07-02 14:34:33'),
(2, 'employer', 'Deloitte Hiring', 'employer@yopmail.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, '2026-06-30 16:38:36', '2026-06-30 11:49:16', '2026-07-02 14:34:33'),
(3, 'employer', 'KPMG Talent', 'kpmg@yopmail.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(4, 'employer', 'EY Recruiting', 'ey@yopmail.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(5, 'employer', 'HDFC Careers', 'hdfc@yopmail.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(6, 'employer', 'Zerodha HR', 'zerodha@yopmail.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(7, 'job_seeker', 'Priya Sharma', 'priya.sharma@yopmail.com', '+91 98765 43210', '$2y$10$sYTpU7SR/yqiManeRAACPOwoUn6vXFM0jqF96OX8PMrp9TCa2DEf2', 'active', NULL, NULL, NULL, NULL, '2026-07-02 14:58:37', '2026-06-30 11:53:17', '2026-07-02 14:58:37'),
(8, 'job_seeker', 'Rahul Mehta', 'rahul.mehta@yopmail.com', '+91 98765 43211', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(9, 'job_seeker', 'Ananya Iyer', 'ananya.iyer@yopmail.com', '+91 98765 43212', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(10, 'job_seeker', 'Vikram Singh', 'vikram.singh@yopmail.com', '+91 98765 43213', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(11, 'job_seeker', 'Sneha Reddy', 'sneha.reddy@yopmail.com', '+91 98765 43214', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(12, 'job_seeker', 'Arjun Nair', 'arjun.nair@yopmail.com', '+91 98765 43215', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(13, 'job_seeker', 'Kavya Patel', 'kavya.patel@yopmail.com', '+91 98765 43216', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(14, 'job_seeker', 'Rohit Gupta', 'rohit.gupta@yopmail.com', '+91 98765 43217', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(15, 'job_seeker', 'Meera Joshi', 'meera.joshi@yopmail.com', '+91 98765 43218', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, '2026-06-30 12:16:56', '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(16, 'job_seeker', 'Aditya Khan', 'aditya.khan@yopmail.com', '+91 98765 43219', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 11:53:17', '2026-07-02 14:34:33'),
(17, 'job_seeker', 'Test No Profile', 'test.noprofile@yopmail.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NULL, NULL, NULL, NULL, '2026-06-30 12:23:08', '2026-07-02 14:34:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_settings`
--
ALTER TABLE `admin_settings`
  ADD PRIMARY KEY (`setting_key`),
  ADD KEY `idx_admin_settings_updated_by` (`updated_by_user_id`);

--
-- Indexes for table `contact_inquiries`
--
ALTER TABLE `contact_inquiries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_contact_inquiries_created` (`created_at`);

--
-- Indexes for table `employer_profiles`
--
ALTER TABLE `employer_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_employer_profiles_user` (`user_id`),
  ADD KEY `idx_employer_access_level` (`access_level`),
  ADD KEY `idx_employer_location` (`city`,`state`,`country`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_jobs_slug` (`slug`),
  ADD KEY `idx_jobs_public_list` (`status`,`posted_at`),
  ADD KEY `idx_jobs_location_type` (`location`,`job_type`,`workplace_type`),
  ADD KEY `idx_jobs_employer` (`employer_id`,`status`),
  ADD KEY `idx_jobs_category` (`category_id`),
  ADD KEY `idx_jobs_created_by` (`created_by_user_id`),
  ADD KEY `idx_jobs_deleted_by` (`deleted_by_user_id`);

--
-- Indexes for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_job_applications_once` (`job_id`,`job_seeker_id`),
  ADD KEY `idx_job_applications_job_status` (`job_id`,`status`),
  ADD KEY `idx_job_applications_candidate` (`job_seeker_id`,`applied_at`);

--
-- Indexes for table `job_categories`
--
ALTER TABLE `job_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_job_categories_slug` (`slug`);

--
-- Indexes for table `job_seeker_profiles`
--
ALTER TABLE `job_seeker_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_job_seeker_profiles_user` (`user_id`),
  ADD KEY `idx_job_seeker_search` (`profile_level`,`experience_years`,`current_location`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_password_reset_user` (`user_id`),
  ADD KEY `idx_password_reset_hash` (`token_hash`),
  ADD KEY `idx_password_reset_expires` (`expires_at`);

--
-- Indexes for table `resume_access_logs`
--
ALTER TABLE `resume_access_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_resume_access_employer` (`employer_id`,`created_at`),
  ADD KEY `idx_resume_access_candidate` (`job_seeker_id`,`created_at`),
  ADD KEY `idx_resume_access_application` (`application_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD KEY `idx_users_role_status` (`role`,`status`),
  ADD KEY `idx_users_blocked_by` (`blocked_by_user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_inquiries`
--
ALTER TABLE `contact_inquiries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employer_profiles`
--
ALTER TABLE `employer_profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `job_applications`
--
ALTER TABLE `job_applications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job_categories`
--
ALTER TABLE `job_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `job_seeker_profiles`
--
ALTER TABLE `job_seeker_profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `resume_access_logs`
--
ALTER TABLE `resume_access_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_settings`
--
ALTER TABLE `admin_settings`
  ADD CONSTRAINT `fk_admin_settings_updated_by` FOREIGN KEY (`updated_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `employer_profiles`
--
ALTER TABLE `employer_profiles`
  ADD CONSTRAINT `fk_employer_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `fk_jobs_category` FOREIGN KEY (`category_id`) REFERENCES `job_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_jobs_created_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_jobs_deleted_by` FOREIGN KEY (`deleted_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_jobs_employer` FOREIGN KEY (`employer_id`) REFERENCES `employer_profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD CONSTRAINT `fk_job_applications_candidate` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seeker_profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_job_applications_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job_seeker_profiles`
--
ALTER TABLE `job_seeker_profiles`
  ADD CONSTRAINT `fk_job_seeker_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD CONSTRAINT `fk_password_reset_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `resume_access_logs`
--
ALTER TABLE `resume_access_logs`
  ADD CONSTRAINT `fk_resume_access_application` FOREIGN KEY (`application_id`) REFERENCES `job_applications` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_resume_access_candidate` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seeker_profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_resume_access_employer` FOREIGN KEY (`employer_id`) REFERENCES `employer_profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_blocked_by` FOREIGN KEY (`blocked_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
