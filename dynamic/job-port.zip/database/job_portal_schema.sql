-- Finance Port / Job Portal MVP database schema
-- Stack: Core PHP + MySQL/MariaDB

CREATE DATABASE IF NOT EXISTS job_portal
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE job_portal;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    role ENUM('job_seeker', 'employer', 'admin') NOT NULL,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL,
    phone VARCHAR(30) NULL,
    password_hash VARCHAR(255) NOT NULL,
    status ENUM('active', 'blocked', 'deleted') NOT NULL DEFAULT 'active',
    blocked_reason VARCHAR(255) NULL,
    blocked_at DATETIME NULL,
    blocked_by_user_id BIGINT UNSIGNED NULL,
    email_verified_at DATETIME NULL,
    last_login_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role_status (role, status),
    KEY idx_users_blocked_by (blocked_by_user_id),
    CONSTRAINT fk_users_blocked_by
        FOREIGN KEY (blocked_by_user_id) REFERENCES users(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS job_seeker_profiles (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    headline VARCHAR(180) NULL,
    summary TEXT NULL,
    skills TEXT NULL,
    experience_years DECIMAL(4,1) UNSIGNED NOT NULL DEFAULT 0.0,
    qualification VARCHAR(180) NULL,
    current_location VARCHAR(150) NULL,
    preferred_location VARCHAR(150) NULL,
    profile_level ENUM('basic', 'skilled') NOT NULL DEFAULT 'basic',
    resume_file_path VARCHAR(255) NULL,
    resume_original_name VARCHAR(255) NULL,
    resume_uploaded_at DATETIME NULL,
    visibility ENUM('public', 'hidden') NOT NULL DEFAULT 'public',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_job_seeker_profiles_user (user_id),
    KEY idx_job_seeker_search (profile_level, experience_years, current_location),
    CONSTRAINT fk_job_seeker_profiles_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS employer_profiles (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    company_name VARCHAR(180) NOT NULL,
    company_website VARCHAR(255) NULL,
    industry VARCHAR(150) NULL,
    company_size VARCHAR(80) NULL,
    contact_person_name VARCHAR(150) NULL,
    contact_designation VARCHAR(120) NULL,
    address_line VARCHAR(255) NULL,
    city VARCHAR(120) NULL,
    state VARCHAR(120) NULL,
    country VARCHAR(120) NOT NULL DEFAULT 'India',
    access_level ENUM('free', 'paid') NOT NULL DEFAULT 'free',
    subscription_started_at DATETIME NULL,
    subscription_expires_at DATETIME NULL,
    is_verified TINYINT(1) NOT NULL DEFAULT 0,
    verification_notes VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_employer_profiles_user (user_id),
    KEY idx_employer_access_level (access_level),
    KEY idx_employer_location (city, state, country),
    CONSTRAINT fk_employer_profiles_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS job_categories (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(120) NOT NULL,
    slug VARCHAR(140) NOT NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_job_categories_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS jobs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employer_id BIGINT UNSIGNED NOT NULL,
    category_id BIGINT UNSIGNED NULL,
    created_by_user_id BIGINT UNSIGNED NULL,
    title VARCHAR(180) NOT NULL,
    slug VARCHAR(220) NOT NULL,
    short_description VARCHAR(255) NULL,
    description TEXT NOT NULL,
    responsibilities TEXT NULL,
    requirements TEXT NULL,
    skills_required TEXT NULL,
    qualification_required VARCHAR(180) NULL,
    experience_min_years DECIMAL(4,1) UNSIGNED NOT NULL DEFAULT 0.0,
    experience_max_years DECIMAL(4,1) UNSIGNED NULL,
    location VARCHAR(150) NOT NULL,
    job_type ENUM('full_time', 'part_time', 'contract', 'internship', 'temporary') NOT NULL DEFAULT 'full_time',
    workplace_type ENUM('onsite', 'remote', 'hybrid') NOT NULL DEFAULT 'onsite',
    salary_min DECIMAL(12,2) NULL,
    salary_max DECIMAL(12,2) NULL,
    salary_currency CHAR(3) NOT NULL DEFAULT 'INR',
    openings INT UNSIGNED NOT NULL DEFAULT 1,
    application_deadline DATE NULL,
    status ENUM('draft', 'open', 'closed', 'deleted') NOT NULL DEFAULT 'open',
    posted_at DATETIME NULL,
    deleted_at DATETIME NULL,
    deleted_by_user_id BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_jobs_slug (slug),
    KEY idx_jobs_public_list (status, posted_at),
    KEY idx_jobs_location_type (location, job_type, workplace_type),
    KEY idx_jobs_employer (employer_id, status),
    KEY idx_jobs_category (category_id),
    KEY idx_jobs_created_by (created_by_user_id),
    KEY idx_jobs_deleted_by (deleted_by_user_id),
    CONSTRAINT fk_jobs_employer
        FOREIGN KEY (employer_id) REFERENCES employer_profiles(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_jobs_category
        FOREIGN KEY (category_id) REFERENCES job_categories(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    CONSTRAINT fk_jobs_created_by
        FOREIGN KEY (created_by_user_id) REFERENCES users(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    CONSTRAINT fk_jobs_deleted_by
        FOREIGN KEY (deleted_by_user_id) REFERENCES users(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS job_applications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    job_id BIGINT UNSIGNED NOT NULL,
    job_seeker_id BIGINT UNSIGNED NOT NULL,
    cover_letter TEXT NULL,
    resume_file_path VARCHAR(255) NULL,
    status ENUM('applied', 'reviewed', 'shortlisted', 'rejected', 'hired', 'withdrawn') NOT NULL DEFAULT 'applied',
    employer_note TEXT NULL,
    applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_job_applications_once (job_id, job_seeker_id),
    KEY idx_job_applications_job_status (job_id, status),
    KEY idx_job_applications_candidate (job_seeker_id, applied_at),
    CONSTRAINT fk_job_applications_job
        FOREIGN KEY (job_id) REFERENCES jobs(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_job_applications_candidate
        FOREIGN KEY (job_seeker_id) REFERENCES job_seeker_profiles(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS resume_access_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employer_id BIGINT UNSIGNED NOT NULL,
    job_seeker_id BIGINT UNSIGNED NOT NULL,
    application_id BIGINT UNSIGNED NULL,
    action ENUM('view_profile', 'view_resume', 'download_resume') NOT NULL,
    access_granted TINYINT(1) NOT NULL DEFAULT 0,
    denial_reason VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_resume_access_employer (employer_id, created_at),
    KEY idx_resume_access_candidate (job_seeker_id, created_at),
    KEY idx_resume_access_application (application_id),
    CONSTRAINT fk_resume_access_employer
        FOREIGN KEY (employer_id) REFERENCES employer_profiles(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_resume_access_candidate
        FOREIGN KEY (job_seeker_id) REFERENCES job_seeker_profiles(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_resume_access_application
        FOREIGN KEY (application_id) REFERENCES job_applications(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admin_settings (
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT NULL,
    value_type ENUM('string', 'number', 'boolean', 'json') NOT NULL DEFAULT 'string',
    updated_by_user_id BIGINT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (setting_key),
    KEY idx_admin_settings_updated_by (updated_by_user_id),
    CONSTRAINT fk_admin_settings_updated_by
        FOREIGN KEY (updated_by_user_id) REFERENCES users(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_password_reset_user (user_id),
    KEY idx_password_reset_hash (token_hash),
    KEY idx_password_reset_expires (expires_at),
    CONSTRAINT fk_password_reset_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO job_categories (name, slug) VALUES
    ('Accounting', 'accounting'),
    ('Taxation', 'taxation'),
    ('Audit', 'audit'),
    ('Banking', 'banking'),
    ('Investment', 'investment'),
    ('FinTech', 'fintech'),
    ('Insurance', 'insurance'),
    ('Consulting', 'consulting');

INSERT IGNORE INTO admin_settings (setting_key, setting_value, value_type) VALUES
    ('site_name', 'Finance Port', 'string'),
    ('allow_public_signup', '1', 'boolean'),
    ('free_employer_can_view_resume', '0', 'boolean'),
    ('max_resume_upload_mb', '5', 'number');

CREATE TABLE IF NOT EXISTS contact_inquiries (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL,
    phone VARCHAR(30) NULL,
    company_name VARCHAR(180) NULL,
    profile_type VARCHAR(50) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_contact_inquiries_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
