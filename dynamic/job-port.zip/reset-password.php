<?php
require_once __DIR__ . '/includes/public_init.php';

$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$currentPage = 'reset-password';
$footerClass = '';
$user = $token !== '' ? fp_fetch_password_reset_user($token) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $token = trim($_POST['token'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $confirm = (string) ($_POST['password_confirm'] ?? '');

    if ($password === '' || $confirm === '') {
        fp_flash('danger', 'Enter and confirm your new password.');
    } elseif ($password !== $confirm) {
        fp_flash('danger', 'Password confirmation does not match.');
    } else {
        try {
            $updatedUser = fp_reset_password_with_token($token, $password);
            fp_flash('success', 'Your password has been updated. You can sign in now.');
            if ($updatedUser['role'] === 'employer') {
                fp_redirect('employer/login.php?email=' . urlencode($updatedUser['email']));
            }
            fp_redirect('jobseeker/login.php?email=' . urlencode($updatedUser['email']));
        } catch (Throwable $exception) {
            fp_flash('danger', $exception->getMessage());
        }
    }

    $user = fp_fetch_password_reset_user($token);
}

if ($token === '') {
    fp_flash('danger', 'Missing reset token.');
    fp_redirect('forgot-password.php');
}

if (!$user && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    fp_flash('danger', 'This reset link is invalid or has expired. Please request a new one.');
    fp_redirect('forgot-password.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Finance Port</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <?php include __DIR__ . '/includes/public_chrome_styles.php'; ?>
    <style>
        body { background:#F8FAFC; color:#1E293B; min-height:100vh; }
        .auth-page { padding: 120px 16px 60px; max-width: 520px; margin: 0 auto; }
        .auth-card { background:#fff; border:1px solid var(--border-light); border-radius:24px; padding:40px 32px; box-shadow:0 20px 40px -10px rgba(13,43,78,0.08); }
        .btn-brand { background:var(--primary); color:#fff; border:none; border-radius:14px; padding:14px; font-weight:700; }
        .btn-brand:hover { background:var(--accent); color:#fff; }
        .form-control { border-radius:14px; padding:14px 16px; border-color:var(--border-light); }
        .form-control:focus { border-color:var(--accent); box-shadow:0 0 0 0.12rem rgba(216,64,0,0.16); }
    </style>
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<main class="auth-page">
    <?php fp_render_flashes(); ?>
    <div class="auth-card">
        <div class="text-center mb-4">
            <div class="text-uppercase small fw-bold text-danger mb-2" style="letter-spacing:0.08em;">New password</div>
            <h1 class="h3 mb-2">Choose a new password</h1>
            <?php if ($user): ?>
                <p class="text-muted mb-0">Resetting password for <strong><?php echo e($user['email']); ?></strong></p>
            <?php endif; ?>
        </div>

        <?php if ($user): ?>
            <form method="post" action="reset-password.php" novalidate>
                <?php echo fp_csrf_field(); ?>
                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                <div class="mb-3">
                    <label class="form-label fw-semibold" for="password">New password</label>
                    <input class="form-control" type="password" id="password" name="password" minlength="8" required>
                    <div class="form-text">Minimum 8 characters.</div>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-semibold" for="password_confirm">Confirm password</label>
                    <input class="form-control" type="password" id="password_confirm" name="password_confirm" minlength="8" required>
                </div>
                <button class="btn btn-brand w-100" type="submit">
                    <i class="fa-solid fa-key me-2"></i>Update password
                </button>
            </form>
        <?php else: ?>
            <p class="text-muted text-center mb-0">
                <a class="fw-bold text-decoration-none" href="forgot-password.php">Request a new reset link</a>
            </p>
        <?php endif; ?>
    </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php include __DIR__ . '/includes/public_chrome_scripts.php'; ?>
</body>
</html>
