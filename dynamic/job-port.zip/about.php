<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | Finance Port</title>
    
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        /* =========================================
        DESIGN SYSTEM & VARIABLES (Matched from Homepage)
        ========================================= */
        :root {
            --primary: #071126;         /* Deep Navy */
            --secondary: #1E63FF;       /* Royal Blue */
            --accent: #D84000;          /* Deep Orange */
            --accent-light: #FF8C42;    /* Light Orange */
            --bg-base: #FFFFFF;         /* White */
            --bg-light: #F8FAFC;        /* Light Gray/Blue background */
            
            --text-main: #1E293B;       /* Slate 800 - Main Text */
            --text-muted: #64748B;      /* Slate 500 - Secondary Text */
            
            --border-light: #E2E8F0;    /* Soft borders */
            --border-accent: rgba(216, 64, 0, 0.3);
            
            --radius-lg: 24px;
            --radius-md: 16px;
            --radius-sm: 8px;
            
            --shadow-sm: 0 4px 6px -1px rgba(13, 43, 78, 0.05);
            --shadow-md: 0 10px 30px -5px rgba(13, 43, 78, 0.08);
            --shadow-lg: 0 20px 40px -10px rgba(13, 43, 78, 0.12);
            --shadow-glow: 0 0 20px rgba(216, 64, 0, 0.3);
            
            --transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* Strict Overflow Control */
        html, body {
            overflow-x: hidden;
            width: 100%;
            max-width: 100vw;
            position: relative;
        }

        body {
            background-color: var(--bg-base);
            color: var(--text-main);
            font-family: 'Inter', sans-serif;
            -webkit-font-smoothing: antialiased;
        }

        /* Typography */
        h1, h2, h3, h4, h5, h6 {
            font-weight: 700;
            color: var(--primary);
            letter-spacing: -0.02em;
        }
        
        h1, .hero-title {
            font-size: clamp(2.5rem, 5vw, 4.5rem) !important;
        }

        h2 {
            font-size: clamp(1.75rem, 4vw, 2.75rem) !important;
        }

        .text-gradient {
            background: linear-gradient(135deg, #D84000 0%, #FF7A4D 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .text-primary-custom { color: var(--primary) !important; }
        .text-accent { color: var(--accent) !important; }

        /* Responsive Fluid Spacing System */
        .section-py { padding-top: clamp(40px, 8vw, 100px); padding-bottom: clamp(40px, 8vw, 100px); }
        .section-mt { margin-top: clamp(30px, 5vw, 80px); }
        .section-mb { margin-bottom: clamp(30px, 5vw, 80px); }
        .bg-alternate { background-color: var(--bg-light); }

        /* Utilities */
        .premium-card {
            background: var(--bg-base);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .premium-card:hover {
            border-color: rgba(13, 43, 78, 0.2);
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
        }

        /* Buttons */
        .btn-premium {
            background: var(--accent);
            color: white;
            border: 1px solid var(--accent);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            text-align: center;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            white-space: nowrap;
        }

        .btn-premium:hover {
            background: #A83000;
            border-color: #A83000; 
            border-color: #091f3a;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(13, 43, 78, 0.2);
            color: white;
        }

        .btn-accent-glow {
            background: var(--accent);
            color: white;
            border: none;
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            box-shadow: var(--shadow-glow);
            white-space: nowrap;
        }

        .btn-accent-glow:hover {
            background: #A83000;
            transform: translateY(-2px);
            box-shadow: 0 0 25px rgba(232, 160, 32, 0.5);
            color: white;
        }

        .btn-outline-custom {
            background: transparent;
            color: var(--primary);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            white-space: nowrap;
        }

        .btn-outline-custom:hover {
            background: var(--bg-light);
            border-color: var(--primary);
            color: var(--primary);
        }

        .btn-hero-outline {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            white-space: nowrap;
        }

        .btn-hero-outline:hover {
            background: white;
            color: var(--primary);
        }

        /* =========================================
        NAVBAR
        ========================================= */
        .navbar-premium {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-light);
            padding: 16px 0;
            transition: background-color 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: var(--shadow-sm);
        }
        .navbar-brand {
            font-weight: 800;
            font-size: clamp(1.2rem, 3vw, 1.5rem);
            color: var(--primary) !important;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: color 0.3s ease;
        }
        .brand-dot {
            width: clamp(10px, 2vw, 14px);
            height: clamp(10px, 2vw, 14px);
            background: var(--accent);
            border-radius: 50%;
        }
        .nav-link {
            color: var(--text-muted) !important;
            font-weight: 600;
            font-size: 0.95rem;
            margin: 0 12px;
            transition: color 0.3s ease;
        }
        .nav-link:hover, .nav-link.active {
            color: var(--accent) !important;
        }
        
        /* SCROLLED NAVBAR STATE */
        .navbar-scrolled {
            background: rgba(13, 43, 78, 0.98) !important;
            box-shadow: 0 10px 30px rgba(13, 43, 78, 0.2) !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
        }
        .navbar-scrolled .navbar-brand { color: #FFFFFF !important; }
        .navbar-scrolled .nav-link { color: rgba(255, 255, 255, 0.8) !important; }
        .navbar-scrolled .nav-link:hover, .navbar-scrolled .nav-link.active { color: var(--accent-light) !important; }
        .navbar-scrolled .btn-outline-custom {
            color: #FFFFFF !important;
            border-color: rgba(255, 255, 255, 0.4) !important;
        }
        .navbar-scrolled .btn-outline-custom:hover {
            background: rgba(255, 255, 255, 0.1) !important;
            border-color: #FFFFFF !important;
            color: #FFFFFF !important;
        }
        .navbar-scrolled .navbar-toggler { border-color: rgba(255, 255, 255, 0.3) !important; }
        .navbar-scrolled .navbar-toggler-icon { filter: brightness(0) invert(1); }
        
        @media (max-width: 991px) {
            .navbar-collapse {
                background: var(--bg-base);
                border: 1px solid var(--border-light);
                border-radius: var(--radius-md);
                padding: 20px;
                box-shadow: var(--shadow-lg);
                position: absolute;
                top: 100%;
                left: 15px;
                right: 15px;
                margin-top: 10px;
                max-height: calc(100vh - 80px);
                overflow-y: auto;
                z-index: 1050;
            }
            .navbar-nav { margin-bottom: 20px; }
            .nav-link { margin: 8px 0; font-size: 1.1rem; }
            .navbar-scrolled .navbar-collapse {
                background: var(--primary);
                border-color: rgba(255, 255, 255, 0.1);
            }
        }

        /* =========================================
        SECTION: HERO
        ========================================= */
        .hero-section {
            background-color: var(--primary);
            min-height: 80vh;
            display: flex;
            align-items: center;
            position: relative;
            padding-top: clamp(140px, 18vh, 180px);
            padding-bottom: clamp(80px, 12vh, 120px);
            overflow: hidden;
            color: white;
        }
        
        .hero-pattern {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-image: linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            opacity: 0.5;
            pointer-events: none;
        }

        .hero-title {
            color: white;
            line-height: 1.1;
            margin-bottom: clamp(16px, 4vw, 24px);
        }
        
        .hero-subtitle {
            font-size: clamp(1.05rem, 2.5vw, 1.25rem);
            color: rgba(255, 255, 255, 0.8);
            max-width: 800px;
            margin: 0 auto clamp(30px, 6vw, 40px) auto;
            line-height: 1.7;
            font-weight: 300;
        }

        /* Floating Stat Cards for Hero */
        .float-card {
            position: absolute;
            animation: float 6s ease-in-out infinite;
            z-index: 2;
            max-width: 260px;
            background: var(--bg-base);
            color: var(--text-main);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-md);
            padding: 16px;
            border: 1px solid var(--border-light);
        }
        
        .fc-1 { top: 30%; left: 3%; animation-delay: 0s; }
        .fc-2 { top: 60%; right: 3%; animation-delay: 2s; }
        
        @media (max-width: 1400px) {
            .float-card { display: none !important; }
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-15px); }
            100% { transform: translateY(0px); }
        }

        .pulse-dot {
            width: 10px;
            height: 10px;
            background: var(--accent);
            border-radius: 50%;
            box-shadow: 0 0 10px var(--accent);
            animation: pulse 2s infinite;
            flex-shrink: 0;
        }
        @keyframes pulse {
            0% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.3); opacity: 0.7; }
            100% { transform: scale(1); opacity: 1; }
        }

        /* =========================================
        CUSTOM COMPONENTS
        ========================================= */
        .section-tag {
            display: inline-block;
            padding: 6px 16px;
            background: rgba(232, 160, 32, 0.1);
            color: var(--accent);
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            margin-bottom: 16px;
            border: 1px solid var(--border-accent);
        }

        .icon-box {
            width: clamp(50px, 8vw, 64px);
            height: clamp(50px, 8vw, 64px);
            border-radius: 16px;
            background: var(--bg-light);
            color: var(--primary);
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: clamp(1.5rem, 3vw, 2rem);
            margin-bottom: 24px;
            border: 1px solid var(--border-light);
            transition: var(--transition);
        }
        
        .premium-card:hover .icon-box {
            background: var(--primary);
            color: var(--bg-base);
            transform: scale(1.05);
        }

        .profile-placeholder {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--bg-light), #E2E8F0);
            border: 2px solid white;
            box-shadow: var(--shadow-sm);
            margin: 0 auto 20px auto;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 2rem;
            color: var(--primary);
            font-weight: 700;
        }

        .list-icon-check {
            color: var(--secondary);
            margin-right: 12px;
            font-size: 1.1rem;
        }

        .stats-section {
            background-color: var(--primary);
            color: white;
            position: relative;
        }
        .stat-number {
            font-size: clamp(2.5rem, 6vw, 4.5rem);
            font-weight: 800;
            line-height: 1;
            margin-bottom: 12px;
            color: var(--accent-light);
        }
        .stat-label {
            color: rgba(255, 255, 255, 0.8);
            font-size: clamp(0.9rem, 2vw, 1.1rem);
            font-weight: 500;
        }

        .cta-section {
            background: radial-gradient(circle at center, var(--bg-light) 0%, var(--bg-base) 100%);
            text-align: center;
            border-top: 1px solid var(--border-light);
            border-bottom: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        /* Testimonial specific */
        .quote-icon {
            font-size: 2rem;
            color: var(--border-light);
            margin-bottom: 16px;
        }

        /* Animations */
        .reveal {
            opacity: 0;
            transform: translateY(40px);
            transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .reveal.active {
            opacity: 1;
            transform: translateY(0);
        }
        
        .text-balance { text-wrap: balance; }
        
        /* Footer */
        footer { background: var(--primary); color: white; }
        .footer-heading { color: var(--accent-light); font-weight: 600; margin-bottom: 24px; font-size: clamp(1rem, 2vw, 1.1rem); }
        .footer-link { color: rgba(255,255,255,0.7); text-decoration: none; display: block; margin-bottom: 12px; transition: var(--transition); font-size: clamp(0.9rem, 2vw, 1rem); }
        .footer-link:hover { color: white; padding-left: 4px; }
        .footer-social { transition: var(--transition); }
        .footer-social:hover { color: var(--accent) !important; }
    </style>
</head>
<body>

    <?php
require_once __DIR__ . '/includes/app.php';
$basePath = fp_url_base_path();
$currentPage = 'about';
include __DIR__ . '/includes/header.php';
?>

    <!-- SECTION 1: HERO -->
    <section class="hero-section text-center">
        <div class="hero-pattern"></div>
        
        <!-- Floating UI Cards (Desktop Only) -->
        <div class="float-card fc-1 text-start d-none d-xl-block">
            <div class="d-flex align-items-center gap-3">
                <div class="pulse-dot"></div>
                <div>
                    <div style="font-size: 0.8rem; color: var(--text-muted); font-weight: 600;">Active Placements</div>
                    <div style="font-weight: 700; color: var(--primary);">Global Reach</div>
                </div>
            </div>
        </div>
        <div class="float-card fc-2 text-start d-none d-xl-block">
            <div class="d-flex align-items-center gap-3">
                <div class="pulse-dot" style="background: var(--secondary); box-shadow: 0 0 10px var(--secondary);"></div>
                <div>
                    <div style="font-size: 0.8rem; color: var(--text-muted); font-weight: 600;">Verified Talent</div>
                    <div style="font-weight: 700; color: var(--primary);">Top Tier Firms</div>
                </div>
            </div>
        </div>

        <div class="container relative z-10">
            <div class="section-tag border-0 bg-white text-primary mb-4 shadow-sm" style="font-weight: 800;">Our Purpose</div>
            <h1 class="hero-title text-balance">
                Connecting Finance Talent <br class="d-none d-md-block">
                <span class="text-gradient">With Opportunity.</span>
            </h1>
            <p class="hero-subtitle text-balance">
                Finance Port helps accounting, finance, tax, audit, banking, and consulting professionals discover meaningful careers while helping employers find exceptional talent.
            </p>

            <div class="d-flex flex-column flex-sm-row justify-content-center gap-3 mt-5">
                <button class="btn btn-accent-glow px-4 py-3">Find Jobs</button>
                <button class="btn btn-hero-outline px-4 py-3">Hire Talent</button>
                <button class="btn btn-hero-outline px-4 py-3" style="border-color: transparent;">Our Story <i class="fa-solid fa-arrow-down ms-2"></i></button>
            </div>
        </div>
    </section>

    <!-- SECTION 2: OUR STORY & EXPLANATION -->
    <section class="bg-alternate section-py reveal" id="our-story">
        <div class="container">
            <div class="row align-items-center g-5">
                <div class="col-lg-6">
                    <div class="section-tag">The Genesis</div>
                    <h2 class="mb-4">Simplifying the complex world of finance recruitment.</h2>
                    <p class="text-muted fs-5 mb-4">
                        Traditional recruitment platforms treat all jobs the same. We realized that hiring a highly qualified CA, an expert Tax Consultant, or a specialized Auditor requires a completely different approach.
                    </p>
                    <p class="text-muted fs-6 mb-4">
                        Finance Port was created to bridge the massive gap in the industry. By focusing entirely on quality over quantity, we have built a streamlined ecosystem that speaks the exact language of finance professionals and the top-tier enterprises looking to hire them.
                    </p>
                    <div class="d-flex align-items-center gap-3 mt-4">
                        <div class="brand-dot" style="width: 16px; height: 16px;"></div>
                        <h5 class="mb-0 text-primary">Precision. Quality. Growth.</h5>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4">
                        <div class="col-sm-6">
                            <div class="premium-card p-4 text-center">
                                <div class="icon-box mx-auto"><i class="fa-solid fa-triangle-exclamation"></i></div>
                                <h4>The Problem</h4>
                                <p class="text-muted fs-6 mb-0 mt-3">Fragmented platforms leading to unqualified applications and prolonged hiring cycles.</p>
                            </div>
                        </div>
                        <div class="col-sm-6" style="margin-top: clamp(20px, 4vw, 40px);">
                            <div class="premium-card p-4 text-center">
                                <div class="icon-box mx-auto"><i class="fa-solid fa-lightbulb"></i></div>
                                <h4>Our Solution</h4>
                                <p class="text-muted fs-6 mb-0 mt-3">A hyper-focused, AI-assisted marketplace exclusively for verified finance professionals.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 3: MISSION & VISION -->
    <section class="section-py reveal">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="premium-card p-5" style="border-top: 4px solid var(--secondary);">
                        <div class="section-tag mb-4">Our Mission</div>
                        <h3 class="fs-2 mb-3">Connecting Excellence</h3>
                        <p class="text-muted fs-5 mb-0 text-balance">
                            Connecting qualified, ambitious finance professionals with the right opportunities that foster their professional and personal growth.
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="premium-card p-5" style="border-top: 4px solid var(--accent);">
                        <div class="section-tag mb-4" style="background: rgba(13, 43, 78, 0.1); color: var(--primary); border-color: rgba(13, 43, 78, 0.2);">Our Vision</div>
                        <h3 class="fs-2 mb-3">Global Ecosystem</h3>
                        <p class="text-muted fs-5 mb-0 text-balance">
                            Become the most trusted, intelligent, and comprehensive finance recruitment ecosystem globally, driving the industry forward.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 4: WHAT MAKES US DIFFERENT -->
    <section class="bg-alternate section-py reveal">
        <div class="container">
            <div class="text-center section-mb">
                <div class="section-tag">The Advantage</div>
                <h2 class="text-balance">What Makes Us Different</h2>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="icon-box"><i class="fa-solid fa-bullseye"></i></div>
                        <h4 class="mb-3">Finance Industry Focus</h4>
                        <p class="text-muted fs-6 mb-0">We don't do everything. We only do finance. Our entire infrastructure is optimized for accounting, tax, and advisory roles.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="icon-box"><i class="fa-solid fa-building-circle-check"></i></div>
                        <h4 class="mb-3">Verified Employers</h4>
                        <p class="text-muted fs-6 mb-0">Every firm on our platform undergoes strict vetting to ensure they provide excellent cultures and competitive compensation.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="icon-box"><i class="fa-solid fa-user-check"></i></div>
                        <h4 class="mb-3">Quality Candidates</h4>
                        <p class="text-muted fs-6 mb-0">Our network consists of certified CA, CMA, and CPA professionals actively looking to bring value to leading organizations.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="icon-box"><i class="fa-solid fa-microchip"></i></div>
                        <h4 class="mb-3">AI-Powered Matching</h4>
                        <p class="text-muted fs-6 mb-0">Our algorithm looks beyond keywords, understanding the nuance of financial certifications and niche domain expertise.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="icon-box"><i class="fa-solid fa-chart-pie"></i></div>
                        <h4 class="mb-3">Career Intelligence</h4>
                        <p class="text-muted fs-6 mb-0">Access real-time salary benchmarks, career growth roadmaps, and interview preparation specific to top-tier firms.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="icon-box"><i class="fa-solid fa-bolt"></i></div>
                        <h4 class="mb-3">Faster Hiring Process</h4>
                        <p class="text-muted fs-6 mb-0">Reduce your time-to-hire significantly by accessing a pre-vetted, highly active pool of finance talent ready to move.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 5: PLATFORM STATISTICS -->
    <section class="stats-section section-py reveal">
        <div class="container">
            <div class="row text-center g-4 g-md-5">
                <div class="col-md-3 col-6">
                    <div class="stat-number"><span class="counter" data-target="150">0</span>k+</div>
                    <div class="stat-label">Finance Professionals</div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-number counter" data-target="250">0</div>
                    <div class="stat-label">Active Employers</div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-number"><span class="counter" data-target="45">0</span>k+</div>
                    <div class="stat-label">Jobs Posted</div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-number"><span class="counter" data-target="98">0</span>%</div>
                    <div class="stat-label">Placement Success Rate</div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 6: INDUSTRIES WE SERVE -->
    <section class="section-py reveal">
        <div class="container">
            <div class="text-center section-mb">
                <h2 class="text-balance">Industries We Serve</h2>
                <p class="text-muted mx-auto mt-3 fs-5" style="max-width: 600px;">Specialized recruitment across the entire financial spectrum.</p>
            </div>
            
            <div class="row g-3 g-md-4">
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="premium-card p-4 text-center align-items-center justify-content-center">
                        <i class="fa-solid fa-calculator fs-1 text-primary mb-3"></i>
                        <h5 class="mb-0">Accounting</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="premium-card p-4 text-center align-items-center justify-content-center">
                        <i class="fa-solid fa-file-invoice-dollar fs-1 text-primary mb-3"></i>
                        <h5 class="mb-0">Taxation</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="premium-card p-4 text-center align-items-center justify-content-center">
                        <i class="fa-solid fa-magnifying-glass-chart fs-1 text-primary mb-3"></i>
                        <h5 class="mb-0">Audit</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="premium-card p-4 text-center align-items-center justify-content-center">
                        <i class="fa-solid fa-building-columns fs-1 text-primary mb-3"></i>
                        <h5 class="mb-0">Banking</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="premium-card p-4 text-center align-items-center justify-content-center">
                        <i class="fa-solid fa-arrow-trend-up fs-1 text-primary mb-3"></i>
                        <h5 class="mb-0">Investment</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="premium-card p-4 text-center align-items-center justify-content-center">
                        <i class="fa-solid fa-mobile-screen-button fs-1 text-primary mb-3"></i>
                        <h5 class="mb-0">FinTech</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="premium-card p-4 text-center align-items-center justify-content-center">
                        <i class="fa-solid fa-shield-halved fs-1 text-primary mb-3"></i>
                        <h5 class="mb-0">Insurance</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="premium-card p-4 text-center align-items-center justify-content-center">
                        <i class="fa-solid fa-handshake-angle fs-1 text-primary mb-3"></i>
                        <h5 class="mb-0">Consulting</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 7: LEADERSHIP -->
    <section class="bg-alternate section-py reveal">
        <div class="container">
            <div class="text-center section-mb">
                <div class="section-tag">The Team</div>
                <h2 class="text-balance">Leadership</h2>
            </div>
            
            <div class="row g-4 text-center">
                <div class="col-lg-3 col-md-6">
                    <div class="premium-card p-4">
                        <div class="profile-placeholder">CEO</div>
                        <h4 class="mb-1">James Arthur</h4>
                        <p class="text-muted fs-6 mb-0">Founder & CEO</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="premium-card p-4">
                        <div class="profile-placeholder">HR</div>
                        <h4 class="mb-1">Sarah Jenkins</h4>
                        <p class="text-muted fs-6 mb-0">Head of Recruitment</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="premium-card p-4">
                        <div class="profile-placeholder">ES</div>
                        <h4 class="mb-1">Michael Chen</h4>
                        <p class="text-muted fs-6 mb-0">Head of Employer Success</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="premium-card p-4">
                        <div class="profile-placeholder">HT</div>
                        <h4 class="mb-1">Elena Rostova</h4>
                        <p class="text-muted fs-6 mb-0">Head of Technology</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 8: CORE VALUES -->
    <section class="section-py reveal">
        <div class="container">
            <div class="text-center section-mb">
                <h2 class="text-balance">Our Core Values</h2>
            </div>
            
            <div class="row g-4 text-center">
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <h4 class="text-primary mb-0">Integrity</h4>
                        <p class="text-muted fs-6 mt-3 mb-0">Honesty in every interaction and placement.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <h4 class="text-primary mb-0">Excellence</h4>
                        <p class="text-muted fs-6 mt-3 mb-0">Demanding the highest standards from ourselves.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <h4 class="text-primary mb-0">Trust</h4>
                        <p class="text-muted fs-6 mt-3 mb-0">Building secure ecosystems for careers and data.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <h4 class="text-primary mb-0">Innovation</h4>
                        <p class="text-muted fs-6 mt-3 mb-0">Leveraging technology to improve hiring.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <h4 class="text-primary mb-0">Transparency</h4>
                        <p class="text-muted fs-6 mt-3 mb-0">Clear communication on salaries and expectations.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <h4 class="text-primary mb-0">Long-Term Relationships</h4>
                        <p class="text-muted fs-6 mt-3 mb-0">We focus on career arcs, not just single jobs.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 9: WHY CHOOSE US -->
    <section class="bg-alternate section-py reveal">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6">
                    <div class="premium-card p-5" style="border-left: 4px solid var(--primary);">
                        <h3 class="mb-4">Why Employers Choose Us</h3>
                        <ul class="list-unstyled">
                            <li class="mb-3 d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Faster hiring cycles</span></li>
                            <li class="mb-3 d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Pre-vetted, qualified candidates</span></li>
                            <li class="mb-3 d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Better long-term retention rates</span></li>
                            <li class="mb-3 d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Deep industry expertise</span></li>
                            <li class="d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Reduced overall hiring costs</span></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="premium-card p-5" style="border-left: 4px solid var(--accent);">
                        <h3 class="mb-4">Why Candidates Choose Us</h3>
                        <ul class="list-unstyled">
                            <li class="mb-3 d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Access to exclusive opportunities</span></li>
                            <li class="mb-3 d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Strategic career growth mapping</span></li>
                            <li class="mb-3 d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Real-time salary insights</span></li>
                            <li class="mb-3 d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Smart resume building guidance</span></li>
                            <li class="d-flex align-items-center"><i class="fa-solid fa-check-circle list-icon-check"></i> <span class="fs-6 fw-medium">Firm-specific interview preparation</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 10: TESTIMONIALS -->
    <section class="section-py reveal">
        <div class="container">
            <div class="text-center section-mb">
                <div class="section-tag">Success Stories</div>
                <h2 class="text-balance">Trusted by the Best</h2>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <i class="fa-solid fa-quote-left quote-icon"></i>
                        <p class="text-muted fs-6 mb-4">"Finance Port completely changed how we hire. The quality of CA candidates we receive is unmatched. We cut our hiring time by 40%."</p>
                        <div class="d-flex align-items-center gap-3 mt-auto">
                            <div class="brand-dot" style="background: var(--primary);"></div>
                            <div>
                                <h6 class="mb-0">David R.</h6>
                                <small class="text-muted">VP Finance, Global Bank</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <i class="fa-solid fa-quote-left quote-icon"></i>
                        <p class="text-muted fs-6 mb-4">"As a candidate, the platform provided salary insights that helped me negotiate a 25% raise. The exclusive roles here are top-tier."</p>
                        <div class="d-flex align-items-center gap-3 mt-auto">
                            <div class="brand-dot" style="background: var(--accent);"></div>
                            <div>
                                <h6 class="mb-0">Anita S.</h6>
                                <small class="text-muted">Senior Auditor (CPA)</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <i class="fa-solid fa-quote-left quote-icon"></i>
                        <p class="text-muted fs-6 mb-4">"The AI-matching is incredibly accurate. We were looking for a specialized Tax Consultant and found the perfect fit within 3 days."</p>
                        <div class="d-flex align-items-center gap-3 mt-auto">
                            <div class="brand-dot" style="background: var(--secondary);"></div>
                            <div>
                                <h6 class="mb-0">Marcus T.</h6>
                                <small class="text-muted">Partner, Big 4 Firm</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 11: FINAL CTA -->
    <section class="cta-section section-py reveal">
        <div class="container text-center">
            <h2 class="fs-1 mb-4 text-balance">Build Your Future With Finance Port</h2>
            <p class="text-muted fs-5 mb-5 text-balance mx-auto" style="max-width: 600px;">
                Join thousands of leading firms and elite professionals in the most advanced finance recruitment ecosystem.
            </p>
            <div class="d-flex flex-column flex-sm-row justify-content-center gap-3">
                <button class="btn btn-premium px-4 py-3">Explore Opportunities</button>
                <button class="btn btn-outline-custom px-4 py-3">Partner With Us</button>
            </div>
        </div>
    </section>
    <?php include __DIR__ . '/includes/footer.php'; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom Interactions -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            
            // 1. Scroll Reveal Animation via Intersection Observer
            const revealElements = document.querySelectorAll('.reveal');
            
            const revealOptions = {
                threshold: 0.1,
                rootMargin: "0px 0px -50px 0px"
            };

            const revealObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('active');
                        observer.unobserve(entry.target);
                    }
                });
            }, revealOptions);

            revealElements.forEach(el => {
                revealObserver.observe(el);
            });

            // 2. Animated Counters
            const counters = document.querySelectorAll('.counter');
            let hasCounted = false;

            const counterObserver = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && !hasCounted) {
                    hasCounted = true;
                    counters.forEach(counter => {
                        const target = +counter.getAttribute('data-target');
                        const duration = 2000; 
                        const increment = target / (duration / 16); 
                        
                        let current = 0;
                        const updateCounter = () => {
                            current += increment;
                            if (current < target) {
                                counter.innerText = Math.ceil(current);
                                requestAnimationFrame(updateCounter);
                            } else {
                                counter.innerText = target;
                            }
                        };
                        updateCounter();
                    });
                }
            }, { threshold: 0.5 });

            const statsSection = document.querySelector('.stat-number');
            if (statsSection) {
                counterObserver.observe(statsSection.parentElement.parentElement);
            }

            // 3. Dynamic Navbar Background based on scroll
            const navbar = document.querySelector('.navbar-premium');
            const heroSection = document.querySelector('.hero-section');
            const footer = document.querySelector('footer');
            
            window.addEventListener('scroll', () => {
                const scrollThreshold = heroSection ? heroSection.offsetHeight - 80 : 50;
                
                // Check if navbar is touching or overlapping the footer
                const navbarRect = navbar.getBoundingClientRect();
                const footerRect = footer ? footer.getBoundingClientRect() : { top: Infinity };
                const isTouchingFooter = footerRect.top <= navbarRect.bottom;
                
                if (window.scrollY > scrollThreshold && !isTouchingFooter) {
                    navbar.classList.add('navbar-scrolled');
                } else {
                    navbar.classList.remove('navbar-scrolled');
                }
            });
        });
    </script>
</body>
</html>
