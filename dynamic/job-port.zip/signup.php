<?php
require_once __DIR__ . '/includes/public_init.php';

$authEmail = trim($_GET['email'] ?? '');
$authRole = ($_GET['role'] ?? '') === 'employer' ? 'employer' : 'job_seeker';
$currentPage = 'signup';
$footerClass = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | Finance Port</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <?php include __DIR__ . '/includes/public_chrome_styles.php'; ?>
    <style>
        body { background:#F8FAFC; color:#1E293B; min-height:100vh; }
        .auth-page { padding: 120px 16px 60px; max-width: 720px; margin: 0 auto; text-align: center; }
        .auth-card { background:#fff; border:1px solid var(--border-light); border-radius:24px; padding:48px 32px; box-shadow:0 20px 40px -10px rgba(13,43,78,0.08); }
    </style>
</head>
<body
    data-fp-auth-open="1"
    data-fp-auth-mode="signup"
    data-fp-auth-role="<?php echo e($authRole); ?>"
    data-fp-auth-email="<?php echo e($authEmail); ?>"
>
<?php include __DIR__ . '/includes/header.php'; ?>
<main class="auth-page">
    <?php fp_render_flashes(); ?>
    <div class="auth-card">
        <h1 class="h3 mb-3">Create your Finance Port account</h1>
        <p class="text-muted mb-4">Register as a job seeker or employer in a few steps.</p>
        <button type="button" class="btn btn-dark rounded-pill px-4 py-3 fp-open-auth" data-auth-mode="signup" data-auth-role="<?php echo e($authRole); ?>" data-auth-email="<?php echo e($authEmail); ?>">Get Started</button>
    </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php include __DIR__ . '/includes/public_chrome_scripts.php'; ?>
</body>
</html>
