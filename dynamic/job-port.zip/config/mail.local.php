<?php
return array(
    'smtp_host' => 'smtp.gmail.com',
    'smtp_port' => 587,
    'smtp_secure' => 'tls',
    'smtp_auth' => true,
    'smtp_username' => 'aryasrikanth73@gmail.com',
    'smtp_password' => 'giebuszkkqohzmlp',
    'from_email' => 'aryasrikanth73@gmail.com',
    'from_name' => 'Finance Port',
    'site_url' => 'http://localhost/job-port',
);
