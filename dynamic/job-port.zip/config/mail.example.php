<?php
/**
 * Copy to config/mail.local.php and fill in your SMTP credentials.
 * mail.local.php is gitignored — never commit real passwords.
 *
 * Gmail setup:
 * 1. Enable 2-Step Verification on the Google account.
 * 2. Create an App Password: https://myaccount.google.com/apppasswords
 * 3. Paste the 16-character app password into smtp_password (no spaces).
 * 4. smtp_username and from_email must match that Gmail address.
 */
return array(
    'smtp_host' => 'smtp.gmail.com',
    'smtp_port' => 587,
    'smtp_secure' => 'tls',
    'smtp_auth' => true,
    'smtp_username' => 'your@gmail.com',
    'smtp_password' => 'your-16-char-app-password',
    'from_email' => 'your@gmail.com',
    'from_name' => 'Finance Port',
    'site_url' => 'http://localhost/job-port',
);
