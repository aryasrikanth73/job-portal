<?php
require_once __DIR__ . '/includes/public_init.php';
$currentPage = 'privacy';
$footerClass = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy | Finance Port</title>
    
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        /* =========================================
        DESIGN SYSTEM & VARIABLES
        ========================================= */
        :root {
            --primary: #071126;         /* Deep Navy */
            --secondary: #1E63FF;       /* Royal Blue */
            --accent: #D84000;          /* Deep Orange */
            --accent-light: #FF8C42;    /* Light Orange */
            --bg-base: #FFFFFF;         /* White */
            --bg-light: #F8FAFC;        /* Light Gray/Blue background */
            
            --text-main: #1E293B;       /* Slate 800 - Main Text */
            --text-muted: #64748B;      /* Slate 500 - Secondary Text */
            
            --border-light: #E2E8F0;    /* Soft borders */
            --border-accent: rgba(216, 64, 0, 0.3);
            
            --radius-lg: 24px;
            --radius-md: 16px;
            --radius-sm: 8px;
            
            --shadow-sm: 0 4px 6px -1px rgba(13, 43, 78, 0.05);
            --shadow-md: 0 10px 30px -5px rgba(13, 43, 78, 0.08);
            --shadow-lg: 0 20px 40px -10px rgba(13, 43, 78, 0.12);
            --shadow-glow: 0 0 20px rgba(216, 64, 0, 0.3);
            
            --transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* Strict Overflow Control & Smooth Scroll */
        html, body {
            overflow-x: hidden;
            width: 100%;
            max-width: 100vw;
            position: relative;
            scroll-behavior: smooth;
        }

        body {
            background-color: var(--bg-base);
            color: var(--text-main);
            font-family: 'Inter', sans-serif;
            -webkit-font-smoothing: antialiased;
        }

        /* Typography */
        h1, h2, h3, h4, h5, h6 {
            font-weight: 700;
            color: var(--primary);
            letter-spacing: -0.02em;
        }
        
        h1, .hero-title { font-size: clamp(2.5rem, 5vw, 4.5rem) !important; }
        .hero-title { color: white !important; }
        h2 { font-size: clamp(1.75rem, 4vw, 2.75rem) !important; }
        h3 { font-size: clamp(1.3rem, 3vw, 1.75rem); margin-bottom: 1rem; }

        .text-gradient {
            background: linear-gradient(135deg, #D84000 0%, #FF7A4D 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Responsive Fluid Spacing System */
        .section-py { padding-top: clamp(40px, 8vw, 100px); padding-bottom: clamp(40px, 8vw, 100px); }
        .bg-alternate { background-color: var(--bg-light); }

        /* Utilities */
        .premium-card {
            background: var(--bg-base);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
        }

        .premium-card:hover {
            border-color: rgba(13, 43, 78, 0.2);
            box-shadow: var(--shadow-md);
        }

        /* Buttons */
        .btn-premium {
            background: var(--accent);
            color: white;
            border: 1px solid var(--accent);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            text-align: center;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            white-space: nowrap;
        }
        .btn-premium:hover { background: #A83000; border-color: #A83000; transform: translateY(-2px); box-shadow: 0 10px 20px rgba(13, 43, 78, 0.2); color: white; }

        .btn-outline-custom {
            background: transparent;
            color: var(--primary);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            white-space: nowrap;
        }
        .btn-outline-custom:hover { background: var(--bg-light); border-color: var(--primary); color: var(--primary); }

        /* =========================================
        NAVBAR
        ========================================= */
        .navbar-premium {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-light);
            padding: 16px 0;
            transition: background-color 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: var(--shadow-sm);
        }
        .navbar-brand { font-weight: 800; font-size: clamp(1.2rem, 3vw, 1.5rem); color: var(--primary) !important; display: flex; align-items: center; gap: 8px; }
        .brand-dot { width: clamp(10px, 2vw, 14px); height: clamp(10px, 2vw, 14px); background: var(--accent); border-radius: 50%; }
        .nav-link { color: var(--text-muted) !important; font-weight: 600; font-size: 0.95rem; margin: 0 12px; transition: color 0.3s ease; }
        .nav-link:hover, .nav-link.active { color: var(--accent) !important; }
        
        .navbar-scrolled { background: rgba(13, 43, 78, 0.98) !important; box-shadow: 0 10px 30px rgba(13, 43, 78, 0.2) !important; border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important; }
        .navbar-scrolled .navbar-brand { color: #FFFFFF !important; }
        .navbar-scrolled .nav-link { color: rgba(255, 255, 255, 0.8) !important; }
        .navbar-scrolled .nav-link:hover, .navbar-scrolled .nav-link.active { color: var(--accent-light) !important; }
        .navbar-scrolled .btn-outline-custom { color: #FFFFFF !important; border-color: rgba(255, 255, 255, 0.4) !important; }
        .navbar-scrolled .btn-outline-custom:hover { background: rgba(255, 255, 255, 0.1) !important; border-color: #FFFFFF !important; color: #FFFFFF !important; }
        .navbar-scrolled .navbar-toggler { border-color: rgba(255, 255, 255, 0.3) !important; }
        .navbar-scrolled .navbar-toggler-icon { filter: brightness(0) invert(1); }
        
        @media (max-width: 991px) {
            .navbar-collapse {
                background: var(--bg-base); border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 20px; box-shadow: var(--shadow-lg);
                position: absolute; top: 100%; left: 15px; right: 15px; margin-top: 10px; max-height: calc(100vh - 80px); overflow-y: auto; z-index: 1050;
            }
            .navbar-nav { margin-bottom: 20px; }
            .nav-link { margin: 8px 0; font-size: 1.1rem; }
            .navbar-scrolled .navbar-collapse { background: var(--primary); border-color: rgba(255, 255, 255, 0.1); }
        }

        /* =========================================
        HERO SECTION
        ========================================= */
        .hero-section {
            background-color: var(--primary);
            display: flex;
            align-items: center;
            position: relative;
            padding-top: clamp(140px, 18vh, 180px);
            padding-bottom: clamp(60px, 8vh, 80px);
            overflow: hidden;
            color: white;
        }
        
        .hero-pattern {
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background-image: linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
            background-size: 40px 40px; opacity: 0.5; pointer-events: none;
        }

        .hero-subtitle {
            font-size: clamp(1.05rem, 2vw, 1.15rem);
            color: rgba(255, 255, 255, 0.8);
            max-width: 800px;
            margin: 0 auto;
            line-height: 1.7; font-weight: 300;
        }

        /* =========================================
        PRIVACY POLICY CONTENT & TOC
        ========================================= */
        .toc-wrapper {
            position: sticky;
            top: 120px;
            padding: 24px;
        }

        .toc-link {
            display: block;
            color: var(--text-muted);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.95rem;
            padding: 8px 12px;
            border-left: 2px solid var(--border-light);
            transition: var(--transition);
            margin-bottom: 4px;
        }

        .toc-link:hover, .toc-link.active {
            color: var(--secondary);
            border-left-color: var(--secondary);
            background: rgba(30, 99, 255, 0.05);
            border-radius: 0 6px 6px 0;
        }

        .policy-section {
            padding: 32px;
            margin-bottom: 24px;
            scroll-margin-top: 100px; /* Adjust for fixed header offset */
        }

        .policy-section p, .policy-section li {
            color: var(--text-muted);
            line-height: 1.7;
            font-size: 1.05rem;
            margin-bottom: 1rem;
        }

        .policy-section ul {
            padding-left: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .policy-section li::marker {
            color: var(--secondary);
        }

        /* Animations */
        .reveal { opacity: 0; transform: translateY(30px); transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1); }
        .reveal.active { opacity: 1; transform: translateY(0); }
        .text-balance { text-wrap: balance; }
        
        /* Footer */
        footer { background: var(--primary); color: white; }
        .footer-heading { color: var(--accent-light); font-weight: 600; margin-bottom: 24px; font-size: clamp(1rem, 2vw, 1.1rem); }
        .footer-link { color: rgba(255,255,255,0.7); text-decoration: none; display: block; margin-bottom: 12px; transition: var(--transition); font-size: clamp(0.9rem, 2vw, 1rem); }
        .footer-link:hover { color: white; padding-left: 4px; }
        .footer-social { transition: var(--transition); }
        .footer-social:hover { color: var(--accent) !important; }
    </style>
</head>
<body>

    <?php include __DIR__ . '/includes/header.php'; ?>

    <!-- SECTION 1: HERO -->
    <section class="hero-section text-center">
        <div class="hero-pattern"></div>
        <div class="container relative z-10">
            <h1 class="hero-title text-balance mb-4 text-white">
                Privacy <span class="text-gradient">Policy</span>
            </h1>
            <p class="hero-subtitle text-balance mb-4">
                Your privacy and data security are important to us. This Privacy Policy explains how Finance Port collects, uses, stores, and protects your information.
            </p>
            <div class="badge border border-light text-white-50 fw-normal px-3 py-2 rounded-pill" style="font-size: 0.85rem;">
                Last Updated: October 15, 2026
            </div>
        </div>
    </section>

    <!-- SECTION 2: CONTENT & TOC -->
    <section class="bg-alternate section-py">
        <div class="container">
            <div class="row g-5">
                
                <!-- STICKY TABLE OF CONTENTS (Desktop Only) -->
                <div class="col-lg-4 d-none d-lg-block">
                    <div class="premium-card toc-wrapper">
                        <h4 class="fs-5 mb-4 text-primary">Table of Contents</h4>
                        <nav id="toc-nav">
                            <a href="#introduction" class="toc-link active">1. Introduction</a>
                            <a href="#information-we-collect" class="toc-link">2. Information We Collect</a>
                            <a href="#how-we-use-information" class="toc-link">3. How We Use Information</a>
                            <a href="#information-sharing" class="toc-link">4. Information Sharing</a>
                            <a href="#data-security" class="toc-link">5. Data Security</a>
                            <a href="#cookies-policy" class="toc-link">6. Cookies Policy</a>
                            <a href="#user-rights" class="toc-link">7. User Rights</a>
                            <a href="#third-party-services" class="toc-link">8. Third-Party Services</a>
                            <a href="#data-retention" class="toc-link">9. Data Retention</a>
                            <a href="#childrens-privacy" class="toc-link">10. Children's Privacy</a>
                            <a href="#changes-to-policy" class="toc-link">11. Changes to this Policy</a>
                            <a href="#contact-us" class="toc-link">12. Contact Us</a>
                        </nav>
                    </div>
                </div>

                <!-- PRIVACY POLICY CONTENT -->
                <div class="col-lg-8">
                    
                    <div id="introduction" class="premium-card policy-section reveal">
                        <h3>1. Introduction</h3>
                        <p>Finance Port respects user privacy and is unequivocally committed to protecting your personal and professional information. This Privacy Policy details our protocols regarding the collection, handling, and safeguarding of the data you entrust to us when utilizing our specialized finance and accounting recruitment platform.</p>
                        <p>By accessing or using Finance Port, you agree to the practices described in this policy. If you do not agree with this policy, please do not access or use our services.</p>
                    </div>

                    <div id="information-we-collect" class="premium-card policy-section reveal">
                        <h3>2. Information We Collect</h3>
                        <p>To provide a highly effective recruitment ecosystem, we collect specific information tailored to your role on our platform:</p>
                        
                        <h5 class="mt-4 text-primary fs-6 fw-bold">For Job Seekers:</h5>
                        <ul>
                            <li><strong>Identity Data:</strong> Full name, email address, and phone number.</li>
                            <li><strong>Professional Data:</strong> Resumes, CVs, specialized skills (e.g., Taxation, Audit), employment history, and educational background.</li>
                            <li><strong>Profile Data:</strong> Certifications (CA, CMA, CPA, CS), salary expectations, and location preferences.</li>
                        </ul>

                        <h5 class="mt-4 text-primary fs-6 fw-bold">For Employers:</h5>
                        <ul>
                            <li><strong>Corporate Data:</strong> Company name, registration details, and industry sector.</li>
                            <li><strong>Contact Details:</strong> Authorized representative names, business email addresses, and phone numbers.</li>
                            <li><strong>Platform Data:</strong> Job listings, company profile information, and recruitment activity.</li>
                        </ul>

                        <h5 class="mt-4 text-primary fs-6 fw-bold">Automatically Collected Data:</h5>
                        <ul>
                            <li><strong>Technical Data:</strong> IP address, browser type, operating system, and device information.</li>
                            <li><strong>Usage Data:</strong> Pages visited, time spent on pages, clickstream data, and navigation paths.</li>
                            <li><strong>Tracking Technologies:</strong> Cookies and similar tracking analytics.</li>
                        </ul>
                    </div>

                    <div id="how-we-use-information" class="premium-card policy-section reveal">
                        <h3>3. How We Use Information</h3>
                        <p>We utilize the collected data strictly for operational, improvement, and security purposes, including:</p>
                        <ul>
                            <li><strong>Account Management:</strong> Creating and authenticating user accounts securely.</li>
                            <li><strong>Recruitment Operations:</strong> Processing job applications and securely transferring candidate profiles to potential employers.</li>
                            <li><strong>AI Matching:</strong> Leveraging algorithms to match candidate skills with precise employer requirements.</li>
                            <li><strong>Communication:</strong> Sending application updates, interview schedules, relevant job alerts, and platform notifications.</li>
                            <li><strong>Optimization:</strong> Analyzing usage data to improve platform experience, features, and overall performance.</li>
                            <li><strong>Security:</strong> Monitoring activities to prevent fraud, unauthorized access, and ensure platform integrity.</li>
                            <li><strong>Customer Support:</strong> Responding to inquiries and providing technical assistance.</li>
                        </ul>
                    </div>

                    <div id="information-sharing" class="premium-card policy-section reveal">
                        <h3>4. Information Sharing</h3>
                        <p><strong>Finance Port does not sell, rent, or monetize your personal information to third parties.</strong> We only share your data under the following circumstances:</p>
                        <ul>
                            <li><strong>With Verified Employers:</strong> Job seeker profiles and resumes are shared exclusively with verified enterprises when a candidate actively applies or opts into our global talent pool.</li>
                            <li><strong>With Service Providers:</strong> Trusted third-party vendors who assist us in operating our platform (e.g., cloud hosting, email delivery, SMS gateways). These providers are bound by strict confidentiality agreements.</li>
                            <li><strong>For Legal Compliance:</strong> We may disclose information to legal authorities or regulatory bodies if required by law, subpoena, or legal process, to protect our rights or the safety of our users.</li>
                        </ul>
                    </div>

                    <div id="data-security" class="premium-card policy-section reveal">
                        <h3>5. Data Security</h3>
                        <p>We implement enterprise-grade security measures to maintain the safety of your personal information:</p>
                        <ul>
                            <li><strong>Encryption:</strong> Data is encrypted both in transit (using SSL/TLS) and at rest to prevent unauthorized interception.</li>
                            <li><strong>Secure Servers:</strong> Our infrastructure is hosted on highly secure, compliant cloud environments.</li>
                            <li><strong>Access Controls:</strong> Strict role-based access controls limit data access only to authorized Finance Port personnel.</li>
                            <li><strong>Regular Reviews:</strong> We conduct periodic vulnerability assessments, penetration testing, and security audits to ensure sustained protection.</li>
                        </ul>
                    </div>

                    <div id="cookies-policy" class="premium-card policy-section reveal">
                        <h3>6. Cookies Policy</h3>
                        <p>Finance Port uses cookies to enhance user experience and analyze platform traffic. The types of cookies we use include:</p>
                        <ul>
                            <li><strong>Essential Cookies:</strong> Strictly necessary for the platform to function, such as maintaining active user sessions and secure logins.</li>
                            <li><strong>Performance Cookies:</strong> Used to track page load speeds, error rates, and overall platform performance to ensure a smooth experience.</li>
                            <li><strong>Analytics Cookies:</strong> Help us understand how users interact with our platform, enabling us to optimize features and layout based on aggregate data.</li>
                        </ul>
                    </div>

                    <div id="user-rights" class="premium-card policy-section reveal">
                        <h3>7. User Rights</h3>
                        <p>Depending on your jurisdiction, you retain full control over your personal data. You have the right to:</p>
                        <ul>
                            <li><strong>Access:</strong> Request a copy of the personal data we hold about you.</li>
                            <li><strong>Correction:</strong> Update or correct any inaccurate or incomplete information in your profile.</li>
                            <li><strong>Deletion:</strong> Permanently delete your account and associated personal data from our active databases.</li>
                            <li><strong>Withdraw Consent:</strong> Opt-out of marketing communications, job alerts, or specific data processing activities at any time.</li>
                        </ul>
                    </div>

                    <div id="third-party-services" class="premium-card policy-section reveal">
                        <h3>8. Third-Party Services</h3>
                        <p>Our platform integrates with specific third-party services to enhance functionality. These include:</p>
                        <ul>
                            <li><strong>Analytics:</strong> Tools like Google Analytics to monitor platform traffic and usability.</li>
                            <li><strong>Communication:</strong> Email service providers to deliver transactional emails and job alerts.</li>
                            <li><strong>Payments:</strong> Secure payment gateways (e.g., Stripe) for processing employer subscription plans. We do not store full credit card information on our servers.</li>
                        </ul>
                    </div>

                    <div id="data-retention" class="premium-card policy-section reveal">
                        <h3>9. Data Retention</h3>
                        <p>Your personal data is retained only for as long as necessary to fulfill the purposes outlined in this Privacy Policy, or as required to comply with legal, tax, or accounting regulations. When you delete your account, your profile is immediately removed from public visibility, and data is systematically purged from our servers within a standard 30-day deletion cycle.</p>
                    </div>

                    <div id="childrens-privacy" class="premium-card policy-section reveal">
                        <h3>10. Children's Privacy</h3>
                        <p>Finance Port is a professional recruitment platform. Our services are strictly intended for individuals who are 18 years of age or older. We do not knowingly collect personal information from children under 18. If we become aware that we have inadvertently collected such data, we will take immediate steps to delete it.</p>
                    </div>

                    <div id="changes-to-policy" class="premium-card policy-section reveal">
                        <h3>11. Changes to this Policy</h3>
                        <p>Finance Port reserves the right to update or modify this Privacy Policy periodically to reflect changes in legal requirements or platform operations. We will notify active users of significant material changes via email or prominent platform notices prior to the changes taking effect. The "Last Updated" date at the top of this page will always reflect the current version.</p>
                    </div>

                    <div id="contact-us" class="premium-card policy-section reveal">
                        <h3>12. Contact Us</h3>
                        <p>If you have any questions, concerns, or requests regarding this Privacy Policy or your personal data, please contact our dedicated support team:</p>
                        <ul class="list-unstyled mt-3">
                            <li class="mb-2"><i class="fa-solid fa-envelope text-secondary me-2"></i> <strong>Privacy Questions:</strong> <a href="mailto:privacy@financeport.com" class="text-primary fw-medium text-decoration-none">privacy@financeport.com</a></li>
                            <li><i class="fa-solid fa-headset text-secondary me-2"></i> <strong>General Support:</strong> <a href="mailto:support@financeport.com" class="text-primary fw-medium text-decoration-none">support@financeport.com</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <?php include __DIR__ . '/includes/footer.php'; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom Interactions -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            
            // 1. Scroll Reveal Animation via Intersection Observer
            const revealElements = document.querySelectorAll('.reveal');
            
            const revealOptions = {
                threshold: 0.1,
                rootMargin: "0px 0px -50px 0px"
            };

            const revealObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('active');
                        observer.unobserve(entry.target);
                    }
                });
            }, revealOptions);

            revealElements.forEach(el => {
                revealObserver.observe(el);
            });

            // 2. Dynamic Navbar Background based on scroll
            const navbar = document.querySelector('.navbar-premium');
            const heroSection = document.querySelector('.hero-section');
            const footer = document.querySelector('footer');
            
            window.addEventListener('scroll', () => {
                const scrollThreshold = heroSection ? heroSection.offsetHeight - 80 : 50;
                
                // Check if navbar is touching or overlapping the footer
                const navbarRect = navbar.getBoundingClientRect();
                const footerRect = footer ? footer.getBoundingClientRect() : { top: Infinity };
                const isTouchingFooter = footerRect.top <= navbarRect.bottom;
                
                if (window.scrollY > scrollThreshold && !isTouchingFooter) {
                    navbar.classList.add('navbar-scrolled');
                } else {
                    navbar.classList.remove('navbar-scrolled');
                }
            });

            // 3. Table of Contents Scroll Spy
            const tocLinks = document.querySelectorAll('.toc-link');
            const policySections = document.querySelectorAll('.policy-section');
            
            // Highlight TOC links on scroll
            window.addEventListener('scroll', () => {
                let current = '';
                // Add a small offset (150px) to make sure active state changes appropriately 
                const scrollPosition = window.scrollY + 150; 
                
                policySections.forEach(section => {
                    const sectionTop = section.offsetTop;
                    const sectionHeight = section.offsetHeight;
                    
                    if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                        current = section.getAttribute('id');
                    }
                });
                
                // If scrolled to the very bottom, set the last item as active
                if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 100) {
                    current = policySections[policySections.length - 1].getAttribute('id');
                }

                tocLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${current}`) {
                        link.classList.add('active');
                    }
                });
            });
        });
    </script>
</body>
</html>
