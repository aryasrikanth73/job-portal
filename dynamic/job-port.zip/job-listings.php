﻿<?php
require_once __DIR__ . '/includes/public_init.php';

$filters = fp_build_job_filters($_GET);
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;
$totalJobs = fp_count_open_jobs($filters);
$totalPages = max(1, (int) ceil($totalJobs / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
}
$jobs = fp_fetch_open_jobs($filters, $perPage, ($page - 1) * $perPage);
$showingFrom = $totalJobs > 0 ? (($page - 1) * $perPage) + 1 : 0;
$showingTo = min($totalJobs, $page * $perPage);
$activeFilterCount = fp_job_active_filter_count($filters);
$quickFilters = fp_job_quick_filters();
$salaryStep = fp_job_salary_slider_value($filters);
$currentPage = 'opportunities';
$footerClass = '';

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: text/html; charset=utf-8');
    include __DIR__ . '/includes/partials/job_listings_ajax.php';
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opportunities | Finance Port</title>
    
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        /* =========================================
        DESIGN SYSTEM & VARIABLES
        ========================================= */
        :root {
            --primary: #071126;         /* Deep Navy */
            --secondary: #1E63FF;       /* Royal Blue */
            --accent: #D84000;          /* Deep Orange */
            --accent-light: #FF8C42;    /* Light Orange */
            --bg-base: #FFFFFF;         /* White */
            --bg-light: #F8FAFC;        /* Light Gray/Blue background */
            
            --text-main: #1E293B;       /* Slate 800 - Main Text */
            --text-muted: #64748B;      /* Slate 500 - Secondary Text */
            
            --border-light: #E2E8F0;    /* Soft borders */
            --border-accent: rgba(216, 64, 0, 0.3);
            
            --radius-lg: 24px;
            --radius-md: 16px;
            --radius-sm: 8px;
            
            --shadow-sm: 0 4px 6px -1px rgba(13, 43, 78, 0.05);
            --shadow-md: 0 10px 30px -5px rgba(13, 43, 78, 0.08);
            --shadow-lg: 0 20px 40px -10px rgba(13, 43, 78, 0.12);
            --shadow-glow: 0 0 20px rgba(216, 64, 0, 0.3);
            
            --transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* Strict Overflow Control */
        html, body {
            overflow-x: hidden;
            width: 100%;
            max-width: 100vw;
            position: relative;
        }

        body {
            background-color: var(--bg-base);
            color: var(--text-main);
            font-family: 'Inter', sans-serif;
            -webkit-font-smoothing: antialiased;
        }

        /* Typography */
        h1, h2, h3, h4, h5, h6 {
            font-weight: 700;
            color: var(--primary);
            letter-spacing: -0.02em;
        }
        
        h1, .hero-title { font-size: clamp(2.5rem, 5vw, 4.5rem) !important; }
        h2 { font-size: clamp(1.75rem, 4vw, 2.75rem) !important; }

        .text-gradient {
            background: linear-gradient(135deg, #D84000 0%, #FF7A4D 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .text-primary-custom { color: var(--primary) !important; }
        .text-accent { color: var(--accent) !important; }

        /* Responsive Fluid Spacing System */
        .section-py { padding-top: clamp(40px, 8vw, 100px); padding-bottom: clamp(40px, 8vw, 100px); }
        .section-mt { margin-top: clamp(30px, 5vw, 80px); }
        .section-mb { margin-bottom: clamp(30px, 5vw, 80px); }
        .bg-alternate { background-color: var(--bg-light); }

        /* Utilities */
        .premium-card {
            background: var(--bg-base);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .premium-card:hover {
            border-color: rgba(13, 43, 78, 0.2);
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
        }

        /* Buttons */
        .btn-premium {
            background: var(--accent);
            color: white;
            border: 1px solid var(--accent);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            text-align: center;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            white-space: nowrap;
        }
        .btn-premium:hover { background: #A83000; border-color: #A83000; transform: translateY(-2px); box-shadow: 0 10px 20px rgba(13, 43, 78, 0.2); color: white; }

        .btn-accent-glow {
            background: var(--accent);
            color: white;
            border: none;
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            box-shadow: var(--shadow-glow);
            white-space: nowrap;
        }
        .btn-accent-glow:hover { background: #A83000; transform: translateY(-2px); box-shadow: 0 0 25px rgba(216, 64, 0, 0.5); color: white; }

        .btn-outline-custom {
            background: transparent;
            color: var(--primary);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
            font-weight: 600;
            transition: var(--transition);
            white-space: nowrap;
        }
        .btn-outline-custom:hover { background: var(--bg-light); border-color: var(--primary); color: var(--primary); }

        /* =========================================
        NAVBAR
        ========================================= */
        .navbar-premium {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-light);
            padding: 16px 0;
            transition: background-color 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: var(--shadow-sm);
        }
        .navbar-brand { font-weight: 800; font-size: clamp(1.2rem, 3vw, 1.5rem); color: var(--primary) !important; display: flex; align-items: center; gap: 8px; }
        .brand-dot { width: clamp(10px, 2vw, 14px); height: clamp(10px, 2vw, 14px); background: var(--accent); border-radius: 50%; }
        .nav-link { color: var(--text-muted) !important; font-weight: 600; font-size: 0.95rem; margin: 0 12px; transition: color 0.3s ease; }
        .nav-link:hover, .nav-link.active { color: var(--accent) !important; }
        
        .navbar-scrolled { background: rgba(13, 43, 78, 0.98) !important; box-shadow: 0 10px 30px rgba(13, 43, 78, 0.2) !important; border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important; }
        .navbar-scrolled .navbar-brand { color: #FFFFFF !important; }
        .navbar-scrolled .nav-link { color: rgba(255, 255, 255, 0.8) !important; }
        .navbar-scrolled .nav-link:hover, .navbar-scrolled .nav-link.active { color: var(--accent-light) !important; }
        .navbar-scrolled .btn-outline-custom { color: #FFFFFF !important; border-color: rgba(255, 255, 255, 0.4) !important; }
        .navbar-scrolled .btn-outline-custom:hover { background: rgba(255, 255, 255, 0.1) !important; border-color: #FFFFFF !important; color: #FFFFFF !important; }
        .navbar-scrolled .navbar-toggler { border-color: rgba(255, 255, 255, 0.3) !important; }
        .navbar-scrolled .navbar-toggler-icon { filter: brightness(0) invert(1); }
        
        @media (max-width: 991px) {
            .navbar-collapse {
                background: var(--bg-base); border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 20px; box-shadow: var(--shadow-lg);
                position: absolute; top: 100%; left: 15px; right: 15px; margin-top: 10px; max-height: calc(100vh - 80px); overflow-y: auto; z-index: 1050;
            }
            .navbar-nav { margin-bottom: 20px; }
            .nav-link { margin: 8px 0; font-size: 1.1rem; }
            .navbar-scrolled .navbar-collapse { background: var(--primary); border-color: rgba(255, 255, 255, 0.1); }
        }

        /* =========================================
        HERO & SEARCH
        ========================================= */
        .hero-section {
            background-color: var(--primary);
            display: flex;
            align-items: center;
            position: relative;
            padding-top: clamp(140px, 18vh, 180px);
            padding-bottom: clamp(60px, 10vh, 80px);
            overflow: hidden;
            color: white;
        }
        
        .hero-pattern {
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background-image: linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
            background-size: 40px 40px; opacity: 0.5; pointer-events: none;
        }

        .hero-subtitle {
            font-size: clamp(1.05rem, 2.5vw, 1.25rem);
            color: rgba(255, 255, 255, 0.8);
            max-width: 800px;
            margin: 0 auto clamp(30px, 6vw, 40px) auto;
            line-height: 1.7; font-weight: 300;
        }

        /* Hero Job Search Box */
        .hero-search-box {
            max-width: 1000px;
            margin: 0 auto;
            background: var(--bg-base);
            border-radius: var(--radius-lg);
            padding: clamp(8px, 1vw, 12px);
            display: flex;
            flex-direction: column;
            box-shadow: var(--shadow-lg);
        }

        .hero-title {
            color: white;
            line-height: 1.1;
            margin-bottom: clamp(16px, 4vw, 24px);
        }
        
        @media (min-width: 992px) {
            .hero-search-box { flex-direction: row; align-items: center; }
            .hero-search-box form { display: contents; }
        }

        .search-field {
            display: flex; align-items: center; flex: 1;
            padding: clamp(12px, 2vw, 16px);
        }
        
        .search-field i { color: var(--text-muted); font-size: 1.1rem; width: 24px; }
        
        .search-field input {
            border: none; background: transparent; width: 100%;
            color: var(--text-main); font-weight: 500; font-size: 1rem;
            outline: none; padding-left: 8px;
        }
        
        .search-field input::placeholder { color: var(--text-muted); font-weight: 400; }

        .search-divider { width: 1px; height: 40px; background: var(--border-light); margin: 0 8px; display: none; }
        .search-divider-mobile { height: 1px; width: 100%; background: var(--border-light); margin: 0; display: block; }
        
        @media (min-width: 992px) {
            .search-divider { display: block; }
            .search-divider-mobile { display: none; }
        }

        .search-btn {
            width: 100%;
        }
        @media (min-width: 992px) {
            .search-btn {
                width: auto;
                flex-shrink: 0;
            }
        }

        /* Quick Filters / Sticky Bar */
        .quick-filters-container {
            background: var(--bg-base);
            border-bottom: 1px solid var(--border-light);
            padding: 16px 0;
            position: sticky;
            top: 70px; /* Accounts for navbar */
            z-index: 900;
            box-shadow: 0 4px 10px rgba(0,0,0,0.02);
        }

        .quick-filters-scroll {
            display: flex;
            gap: 12px;
            overflow-x: auto;
            white-space: nowrap;
            -webkit-overflow-scrolling: touch;
            padding-bottom: 4px;
            scrollbar-width: none; /* Firefox */
        }
        .quick-filters-scroll::-webkit-scrollbar { display: none; }

        .filter-pill {
            padding: 8px 16px;
            background: var(--bg-light);
            border: 1px solid var(--border-light);
            border-radius: 30px;
            color: var(--text-muted);
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .filter-pill:hover, .filter-pill.active {
            background: rgba(13, 43, 78, 0.05);
            color: var(--primary);
            border-color: var(--primary);
        }

        #ajax-job-results.is-loading {
            opacity: 0.55;
            pointer-events: none;
            transition: opacity 0.2s ease;
        }

        @media (min-width: 992px) {
            #mobileFilterCanvas.offcanvas-lg {
                visibility: visible !important;
                transform: none !important;
                position: static !important;
                background: transparent;
                border: 0;
            }
        }

        /* =========================================
        JOB LISTINGS & SIDEBAR
        ========================================= */
        .filter-sidebar {
            background: var(--bg-base);
            border-radius: var(--radius-md);
            border: 1px solid var(--border-light);
            padding: 24px;
            position: sticky;
            top: 150px;
        }

        .filter-group { margin-bottom: 24px; }
        .filter-group-title { font-weight: 700; font-size: 1rem; color: var(--primary); margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; }
        
        .form-check-label { color: var(--text-muted); font-size: 0.95rem; font-weight: 500; cursor: pointer; }
        .form-check-input:checked { background-color: var(--secondary); border-color: var(--secondary); }
        .filter-count { font-size: 0.8rem; color: var(--text-muted); background: var(--bg-light); padding: 2px 8px; border-radius: 12px; }

        /* Job Cards */
        .job-card {
            padding: clamp(20px, 4vw, 28px);
            border-radius: var(--radius-md);
            border: 1px solid var(--border-light);
            background: var(--bg-base);
            transition: var(--transition);
            position: relative;
        }

        .job-card:hover {
            border-color: rgba(13, 43, 78, 0.2);
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
        }

        .job-logo {
            width: clamp(50px, 8vw, 64px);
            height: clamp(50px, 8vw, 64px);
            border-radius: 14px;
            background: var(--bg-light);
            border: 1px solid var(--border-light);
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 700;
            font-size: 1.5rem;
            color: var(--primary);
            flex-shrink: 0;
        }

        .job-match-badge {
            background: rgba(30, 99, 255, 0.1);
            color: var(--secondary);
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 700;
        }
        
        .job-tag {
            background: var(--bg-light);
            color: var(--text-muted);
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            border: 1px solid var(--border-light);
        }

        .btn-save-job {
            width: 40px; height: 40px;
            border-radius: 50%;
            background: var(--bg-light);
            border: 1px solid var(--border-light);
            color: var(--text-muted);
            display: flex; align-items: center; justify-content: center;
            transition: var(--transition);
        }
        
        .btn-save-job:hover { color: var(--accent); border-color: var(--accent); background: rgba(216, 64, 0, 0.1); }

        /* =========================================
        OTHER SECTIONS (Matched components)
        ========================================= */
        .section-tag {
            display: inline-block; padding: 6px 16px;
            background: rgba(216, 64, 0, 0.1); color: var(--accent);
            border-radius: 20px; font-size: 0.8rem; font-weight: 700;
            letter-spacing: 0.05em; text-transform: uppercase;
            margin-bottom: 16px; border: 1px solid var(--border-accent);
        }

        .emp-logo-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }
        @media (min-width: 768px) { .emp-logo-grid { grid-template-columns: repeat(4, 1fr); } }

        .emp-logo-item {
            background: var(--bg-base); border: 1px solid var(--border-light); border-radius: 16px;
            padding: 24px; text-align: center; font-weight: 800; font-size: 1.2rem;
            color: var(--primary); font-family: serif; box-shadow: var(--shadow-sm); transition: var(--transition);
        }
        .emp-logo-item:hover { transform: translateY(-3px); box-shadow: var(--shadow-md); border-color: var(--primary); }

        .cta-section {
            background: radial-gradient(circle at center, var(--bg-light) 0%, var(--bg-base) 100%);
            text-align: center; border-top: 1px solid var(--border-light); border-bottom: 1px solid var(--border-light);
            position: relative; overflow: hidden;
        }
        
        .job-alert-section {
            background-color: var(--primary); color: white; border-radius: var(--radius-lg); position: relative; overflow: hidden;
        }

        /* Animations */
        .reveal { opacity: 0; transform: translateY(40px); transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1); }
        .reveal.active { opacity: 1; transform: translateY(0); }

        /* Job results are primary content — never hide them behind scroll-reveal */
        #ajax-job-results .reveal {
            opacity: 1;
            transform: none;
        }
        .text-balance { text-wrap: balance; }
        
        /* Footer */
        footer { background: var(--primary); color: white; }
        .footer-heading { color: var(--accent-light); font-weight: 600; margin-bottom: 24px; font-size: clamp(1rem, 2vw, 1.1rem); }
        .footer-link { color: rgba(255,255,255,0.7); text-decoration: none; display: block; margin-bottom: 12px; transition: var(--transition); font-size: clamp(0.9rem, 2vw, 1rem); }
        .footer-link:hover { color: white; padding-left: 4px; }
        .footer-social { transition: var(--transition); }
        .footer-social:hover { color: var(--accent) !important; }
    </style>
</head>
<body>

    <?php include __DIR__ . '/includes/header.php'; ?>

    <!-- SECTION 1: HERO SEARCH -->
    <section class="hero-section text-center">
        <div class="hero-pattern"></div>
        <div class="container relative z-10">
            <h1 class="hero-title text-balance">
                Discover Your Next Finance <br class="d-none d-md-block">
                <span class="text-gradient">Career Opportunity.</span>
            </h1>
            <p class="hero-subtitle text-balance">
                Explore premium opportunities from top finance, taxation, audit, banking and consulting employers actively hiring today.
            </p>

            <!-- Advanced Search Box -->
            <div class="hero-search-box mt-5">
                <form method="get" action="<?php echo fp_url('job-listings.php'); ?>" class="d-contents">
                <?php if ($filters['sort'] !== 'relevance'): ?>
                    <input type="hidden" name="sort" value="<?php echo e($filters['sort']); ?>">
                <?php endif; ?>
                <?php if ($filters['job_type'] !== ''): ?>
                    <?php foreach (explode(',', $filters['job_type']) as $jobType): ?>
                        <?php if (trim($jobType) !== ''): ?>
                            <input type="hidden" name="job_type[]" value="<?php echo e(trim($jobType)); ?>">
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php if ($filters['qualification'] !== ''): ?>
                    <?php foreach (explode(',', $filters['qualification']) as $qualification): ?>
                        <?php if (trim($qualification) !== ''): ?>
                            <input type="hidden" name="qualification[]" value="<?php echo e(trim($qualification)); ?>">
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php if ($filters['category'] !== ''): ?>
                    <input type="hidden" name="category" value="<?php echo e($filters['category']); ?>">
                <?php endif; ?>
                <?php if ($filters['workplace_type'] !== ''): ?>
                    <input type="hidden" name="workplace_type" value="<?php echo e($filters['workplace_type']); ?>">
                <?php endif; ?>
                <?php if ($filters['experience'] !== ''): ?>
                    <input type="hidden" name="experience" value="<?php echo e($filters['experience']); ?>">
                <?php endif; ?>
                <?php if ($filters['salary_min'] > 0): ?>
                    <input type="hidden" name="salary_min" value="<?php echo e($filters['salary_min']); ?>">
                <?php endif; ?>
                <div class="search-field">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Job Title or Keyword (e.g., CA, Tax)">
                </div>
                <div class="search-divider-mobile"></div>
                <div class="search-divider"></div>
                
                <div class="search-field">
                    <i class="fa-solid fa-briefcase"></i>
                    <input type="text" name="skills" value="<?php echo e($filters['skills']); ?>" placeholder="Skills (e.g., Auditing, GST)">
                </div>
                <div class="search-divider-mobile"></div>
                <div class="search-divider"></div>

                <div class="search-field">
                    <i class="fa-solid fa-location-dot"></i>
                    <input type="text" name="location" value="<?php echo e($filters['location']); ?>" placeholder="City or Remote">
                </div>
                
                <button class="btn btn-accent-glow py-3 px-5 mt-3 mt-lg-0 ms-lg-2 fs-6 search-btn" style="border-radius: 12px;" type="submit">Find Jobs</button>
                </form>
            </div>

            <!-- Stats -->
            <div class="d-flex flex-wrap justify-content-center gap-4 gap-md-5 mt-5">
                <div>
                    <h4 class="text-white mb-0"><span class="counter" data-target="<?php echo max(1, min(9999, $totalJobs)); ?>">0</span><?php echo $totalJobs >= 1000 ? '+' : ''; ?></h4>
                    <span class="text-white-50 small fw-medium">Active Jobs</span>
                </div>
                <div>
                    <h4 class="text-white mb-0"><span class="counter" data-target="250">0</span>+</h4>
                    <span class="text-white-50 small fw-medium">Hiring Companies</span>
                </div>
                <div>
                    <h4 class="text-white mb-0"><span class="counter" data-target="150">0</span>,000+</h4>
                    <span class="text-white-50 small fw-medium">Candidates</span>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 2: QUICK FILTERS (Sticky) -->
    <div class="quick-filters-container">
        <div class="container">
            <div id="ajax-quick-filters">
            <div class="quick-filters-scroll">
                <?php foreach ($quickFilters as $quickFilter): ?>
                    <?php
                    $quickParams = array_merge(
                        array(
                            'q' => $filters['q'],
                            'skills' => $filters['skills'],
                            'location' => $filters['location'],
                            'sort' => $filters['sort'],
                        ),
                        $quickFilter['params']
                    );
                    if ($quickFilter['params'] === array()) {
                        $quickParams = array_merge($quickParams, array(
                            'job_type' => '',
                            'qualification' => '',
                            'category' => '',
                            'workplace_type' => '',
                            'experience' => '',
                            'salary_min' => 0,
                        ));
                    }
                    $isActive = fp_job_quick_filter_is_active($quickFilter, $filters);
                    ?>
                    <a
                        class="filter-pill text-decoration-none fp-job-filter-link<?php echo $isActive ? ' active' : ''; ?>"
                        href="<?php echo e(fp_job_listings_url($quickParams)); ?>"
                    ><?php echo e($quickFilter['label']); ?></a>
                <?php endforeach; ?>
            </div>
            </div>
        </div>
    </div>

    <!-- SECTION 3: JOB LISTINGS LAYOUT -->
    <section class="bg-alternate section-py">
        <div class="container">
            <div class="row g-4">
                
                <!-- MOBILE FILTER TOGGLE -->
                <div class="col-12 d-lg-none">
                    <button class="btn btn-outline-custom w-100 d-flex justify-content-between align-items-center" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileFilterCanvas">
                        <span><i class="fa-solid fa-sliders me-2"></i> Filters</span>
                        <span id="ajax-mobile-filter-badge">
                        <?php if ($activeFilterCount > 0): ?>
                            <span class="badge bg-primary rounded-pill"><?php echo e($activeFilterCount); ?></span>
                        <?php endif; ?>
                        </span>
                    </button>
                </div>

                <!-- LEFT SIDEBAR: Desktop Filters (and Mobile Offcanvas content) -->
                <div class="col-lg-3">
                    <div class="offcanvas-lg offcanvas-start" tabindex="-1" id="mobileFilterCanvas">
                        <div class="offcanvas-header d-lg-none border-bottom">
                            <h5 class="offcanvas-title fw-bold text-primary">Filters</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#mobileFilterCanvas" aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body p-0 p-lg-0">
                            <div id="ajax-filter-sidebar">
                            <form method="get" action="<?php echo fp_url('job-listings.php'); ?>" id="jobFiltersForm" class="filter-sidebar w-100">
                                <input type="hidden" name="q" value="<?php echo e($filters['q']); ?>">
                                <input type="hidden" name="skills" value="<?php echo e($filters['skills']); ?>">
                                <input type="hidden" name="location" value="<?php echo e($filters['location']); ?>">
                                <input type="hidden" name="sort" id="filterSortInput" value="<?php echo e($filters['sort']); ?>">

                                <div class="d-flex justify-content-between align-items-center mb-4 d-none d-lg-flex">
                                    <h4 class="mb-0 fs-5">Filters</h4>
                                    <a href="<?php echo e(fp_job_listings_url(array(
                                        'q' => $filters['q'],
                                        'skills' => $filters['skills'],
                                        'location' => $filters['location'],
                                        'sort' => $filters['sort'],
                                    ))); ?>" class="text-muted small text-decoration-none fw-medium fp-job-filter-link">Clear All</a>
                                </div>

                                <div class="filter-group">
                                    <h6 class="filter-group-title">Qualification</h6>
                                    <?php
                                    $qualificationOptions = array(
                                        'CA' => 'Chartered Accountant (CA)',
                                        'CMA' => 'CMA',
                                        'CPA' => 'CPA',
                                        'CS' => 'Company Secretary (CS)',
                                        'MBA' => 'MBA Finance',
                                    );
                                    foreach ($qualificationOptions as $qualValue => $qualLabel):
                                    ?>
                                    <div class="form-check mb-2">
                                        <input
                                            class="form-check-input"
                                            type="checkbox"
                                            name="qualification[]"
                                            id="q-<?php echo e(strtolower($qualValue)); ?>"
                                            value="<?php echo e($qualValue); ?>"
                                            <?php echo fp_job_filter_value_in_list($qualValue, $filters['qualification']) ? 'checked' : ''; ?>
                                        >
                                        <label class="form-check-label" for="q-<?php echo e(strtolower($qualValue)); ?>"><?php echo e($qualLabel); ?></label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>

                                <div class="filter-group">
                                    <h6 class="filter-group-title">Job Type</h6>
                                    <?php
                                    $jobTypeOptions = array(
                                        'full_time' => 'Full Time',
                                        'contract' => 'Contract',
                                        'internship' => 'Internship',
                                    );
                                    foreach ($jobTypeOptions as $typeValue => $typeLabel):
                                    ?>
                                    <div class="form-check mb-2">
                                        <input
                                            class="form-check-input"
                                            type="checkbox"
                                            name="job_type[]"
                                            id="jt-<?php echo e(str_replace('_', '-', $typeValue)); ?>"
                                            value="<?php echo e($typeValue); ?>"
                                            <?php echo fp_job_filter_value_in_list($typeValue, $filters['job_type']) ? 'checked' : ''; ?>
                                        >
                                        <label class="form-check-label" for="jt-<?php echo e(str_replace('_', '-', $typeValue)); ?>"><?php echo e($typeLabel); ?></label>
                                    </div>
                                    <?php endforeach; ?>
                                    <div class="form-check mb-2">
                                        <input
                                            class="form-check-input"
                                            type="checkbox"
                                            name="workplace_type"
                                            id="jt-remote"
                                            value="remote"
                                            <?php echo $filters['workplace_type'] === 'remote' ? 'checked' : ''; ?>
                                        >
                                        <label class="form-check-label" for="jt-remote">Remote</label>
                                    </div>
                                </div>

                                <div class="filter-group">
                                    <h6 class="filter-group-title">Experience</h6>
                                    <select class="form-select text-muted fs-6" name="experience">
                                        <option value="" <?php echo $filters['experience'] === '' ? 'selected' : ''; ?>>Any Experience</option>
                                        <option value="fresher" <?php echo $filters['experience'] === 'fresher' ? 'selected' : ''; ?>>Fresher (0-1 yrs)</option>
                                        <option value="mid" <?php echo $filters['experience'] === 'mid' ? 'selected' : ''; ?>>Mid-Level (2-5 yrs)</option>
                                        <option value="senior" <?php echo $filters['experience'] === 'senior' ? 'selected' : ''; ?>>Senior (5-10 yrs)</option>
                                        <option value="executive" <?php echo $filters['experience'] === 'executive' ? 'selected' : ''; ?>>Executive (10+ yrs)</option>
                                    </select>
                                </div>

                                <div class="filter-group">
                                    <h6 class="filter-group-title">Minimum Salary (INR)</h6>
                                    <input
                                        type="range"
                                        class="form-range"
                                        min="0"
                                        max="5"
                                        step="1"
                                        id="salaryRange"
                                        value="<?php echo e($salaryStep); ?>"
                                    >
                                    <input type="hidden" name="salary_min" id="salaryMinInput" value="<?php echo e($filters['salary_min']); ?>">
                                    <div class="d-flex justify-content-between text-muted small fw-medium mt-1">
                                        <span>Any</span>
                                        <span id="salaryRangeLabel"><?php echo $filters['salary_min'] > 0 ? e(number_format($filters['salary_min'])) . '+' : 'Any'; ?></span>
                                        <span>20L+</span>
                                    </div>
                                </div>

                                <button class="btn btn-premium w-100" type="submit">Apply Filters</button>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- RIGHT CONTENT: Job Listings -->
                <div class="col-lg-9">
                    <div id="ajax-job-results">
                    
                    <!-- Top Bar -->
                    <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center mb-4">
                        <div>
                            <h3 class="mb-1 fs-4">Finance & Accounting Jobs</h3>
                            <p class="text-muted mb-0 fs-6">Showing <?php echo e($showingFrom); ?>–<?php echo e($showingTo); ?> of <?php echo e($totalJobs); ?> jobs</p>
                        </div>
                        <div class="d-flex align-items-center gap-2 mt-3 mt-sm-0">
                            <span class="text-muted fw-medium small text-nowrap">Sort By:</span>
                            <select class="form-select form-select-sm border-light bg-white text-primary fw-medium" id="jobSortSelect" style="width: auto; padding-right: 30px;">
                                <option value="relevance" <?php echo $filters['sort'] === 'relevance' ? 'selected' : ''; ?>>Relevance</option>
                                <option value="latest" <?php echo $filters['sort'] === 'latest' ? 'selected' : ''; ?>>Latest</option>
                                <option value="salary_desc" <?php echo $filters['sort'] === 'salary_desc' ? 'selected' : ''; ?>>Highest Salary</option>
                                <option value="salary_asc" <?php echo $filters['sort'] === 'salary_asc' ? 'selected' : ''; ?>>Lowest Salary</option>
                            </select>
                        </div>
                    </div>

                    <!-- Job List -->
                    <div class="d-flex flex-column gap-3">
                        <?php if (empty($jobs)): ?>
                            <div class="premium-card p-5 text-center">
                                <h4 class="mb-2">No jobs matched your search</h4>
                                <p class="text-muted mb-4">Try different keywords or clear your filters.</p>
                                <a href="<?php echo fp_url('job-listings.php'); ?>" class="btn btn-outline-custom fp-job-filter-link">Clear Search</a>
                            </div>
                        <?php else: ?>
                            <?php foreach ($jobs as $job): ?>
                                <?php include __DIR__ . '/includes/partials/job_card.php'; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <?php if ($totalPages > 1): ?>
                    <div class="d-flex justify-content-center gap-2 mt-5 flex-wrap">
                        <?php if ($page > 1): ?>
                            <a class="btn btn-outline-custom fp-job-filter-link" href="<?php echo e(fp_job_listings_url($filters, array('page' => $page - 1))); ?>">Previous</a>
                        <?php endif; ?>
                        <?php if ($page < $totalPages): ?>
                            <a class="btn btn-outline-custom fp-job-filter-link" href="<?php echo e(fp_job_listings_url($filters, array('page' => $page + 1))); ?>">Next Page</a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 4: FEATURED EMPLOYERS -->
    <section class="section-py reveal">
        <div class="container">
            <div class="text-center section-mb">
                <div class="section-tag">Top Hiring Companies</div>
                <h2 class="text-balance">Featured Employers</h2>
            </div>
            
            <div class="emp-logo-grid">
                <div class="emp-logo-item">Deloitte.</div>
                <div class="emp-logo-item">EY</div>
                <div class="emp-logo-item">KPMG</div>
                <div class="emp-logo-item">PwC</div>
                <div class="emp-logo-item" style="font-family: sans-serif;">HDFC BANK</div>
                <div class="emp-logo-item" style="font-family: sans-serif;">ICICI Bank</div>
                <div class="emp-logo-item" style="font-family: sans-serif; color:#0b66c2;">Infosys</div>
                <div class="emp-logo-item" style="font-family: sans-serif;">TATA</div>
            </div>
        </div>
    </section>

    <!-- SECTION 5: SALARY INSIGHTS -->
    <section class="bg-alternate section-py reveal">
        <div class="container">
            <div class="text-center section-mb">
                <h2 class="text-balance">Finance Salary Insights</h2>
                <p class="text-muted mx-auto mt-3 fs-5" style="max-width: 600px;">Average compensation data based on recent platform hires.</p>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Chartered Accountant</h5>
                            <i class="fa-solid fa-arrow-trend-up text-success"></i>
                        </div>
                        <h3 class="text-primary mb-1">$90k - $150k</h3>
                        <p class="text-muted small mb-0">Average Base ? USA</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Finance Manager</h5>
                            <i class="fa-solid fa-arrow-trend-up text-success"></i>
                        </div>
                        <h3 class="text-primary mb-1">$110k - $170k</h3>
                        <p class="text-muted small mb-0">Average Base ? USA</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="premium-card p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Financial Analyst</h5>
                            <i class="fa-solid fa-arrow-trend-up text-success"></i>
                        </div>
                        <h3 class="text-primary mb-1">$75k - $115k</h3>
                        <p class="text-muted small mb-0">Average Base ? USA</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 6: CAREER RESOURCES -->
    <section class="section-py reveal">
        <div class="container">
            <div class="text-center section-mb">
                <h2 class="text-balance">Career Resources</h2>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <div class="premium-card p-4 text-center">
                        <div class="icon-box mx-auto"><i class="fa-solid fa-file-invoice"></i></div>
                        <h5 class="mb-2">Resume Builder</h5>
                        <p class="text-muted fs-6 small">ATS-optimized templates.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="premium-card p-4 text-center">
                        <div class="icon-box mx-auto"><i class="fa-solid fa-user-tie"></i></div>
                        <h5 class="mb-2">Interview Prep</h5>
                        <p class="text-muted fs-6 small">Big 4 question banks.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="premium-card p-4 text-center">
                        <div class="icon-box mx-auto"><i class="fa-solid fa-certificate"></i></div>
                        <h5 class="mb-2">Certifications</h5>
                        <p class="text-muted fs-6 small">CA, CPA, CMA guidance.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="premium-card p-4 text-center">
                        <div class="icon-box mx-auto"><i class="fa-solid fa-route"></i></div>
                        <h5 class="mb-2">Career Roadmaps</h5>
                        <p class="text-muted fs-6 small">Growth trajectory planning.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 7: JOB ALERT CTA -->
    <section class="container pb-5 mb-5 reveal">
        <div class="job-alert-section p-4 p-md-5">
            <div class="hero-pattern"></div>
            <div class="row align-items-center position-relative z-10">
                <div class="col-lg-7 text-center text-lg-start mb-4 mb-lg-0">
                    <h2 class="text-white mb-2">Never Miss A Finance Opportunity</h2>
                    <p class="text-white-50 fs-5 mb-0">Get tailored jobs delivered straight to your inbox.</p>
                </div>
                <div class="col-lg-5">
                    <div class="d-flex flex-column flex-sm-row gap-2">
                        <input type="email" class="form-control form-control-lg border-0" placeholder="Enter your email address" style="border-radius: 12px;">
                        <button class="btn btn-accent-glow px-4 py-3" style="border-radius: 12px;">Create Free Job Alert</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 8: FINAL CTA -->
    <section class="cta-section section-py reveal mt-5">
        <div class="container text-center">
            <h2 class="fs-1 mb-4 text-balance">Find The Right Opportunity Faster</h2>
            <div class="d-flex flex-column flex-sm-row justify-content-center gap-3">
                <a href="<?php echo fp_url('job-listings.php'); ?>" class="btn btn-premium px-4 py-3">Browse Jobs</a>
                <button type="button" class="btn btn-outline-custom px-4 py-3 fp-open-auth" data-auth-mode="signup">Create Profile</button>
            </div>
        </div>
    </section>
    <?php include __DIR__ . '/includes/footer.php'; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom Interactions -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            
            // 1. Scroll Reveal Animation via Intersection Observer
            const revealElements = document.querySelectorAll('.reveal');
            
            const revealOptions = {
                threshold: 0.1,
                rootMargin: "0px 0px -50px 0px"
            };

            const revealObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('active');
                        observer.unobserve(entry.target);
                    }
                });
            }, revealOptions);

            revealElements.forEach(el => {
                revealObserver.observe(el);
            });

            function refreshRevealElements(root) {
                if (!root) {
                    return;
                }

                root.querySelectorAll('.reveal:not(.active)').forEach(function (el) {
                    const rect = el.getBoundingClientRect();
                    if (rect.top < window.innerHeight && rect.bottom > 0) {
                        el.classList.add('active');
                        return;
                    }

                    revealObserver.observe(el);
                });
            }

            // 2. Animated Counters
            const counters = document.querySelectorAll('.counter');
            let hasCounted = false;

            const counterObserver = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && !hasCounted) {
                    hasCounted = true;
                    counters.forEach(counter => {
                        const target = +counter.getAttribute('data-target');
                        const duration = 2000; 
                        const increment = target / (duration / 16); 
                        
                        let current = 0;
                        const updateCounter = () => {
                            current += increment;
                            if (current < target) {
                                counter.innerText = Math.ceil(current);
                                requestAnimationFrame(updateCounter);
                            } else {
                                counter.innerText = target;
                            }
                        };
                        updateCounter();
                    });
                }
            }, { threshold: 0.5 });

            const statsSection = document.querySelector('.hero-section');
            if (statsSection) {
                counterObserver.observe(statsSection);
            }

            // 3. Dynamic Navbar Background based on scroll
            const navbar = document.querySelector('.navbar-premium');
            const heroSection = document.querySelector('.hero-section');
            const footer = document.querySelector('footer');
            
            window.addEventListener('scroll', () => {
                const scrollThreshold = heroSection ? heroSection.offsetHeight - 80 : 50;
                
                // Check if navbar is touching or overlapping the footer
                const navbarRect = navbar.getBoundingClientRect();
                const footerRect = footer ? footer.getBoundingClientRect() : { top: Infinity };
                const isTouchingFooter = footerRect.top <= navbarRect.bottom;
                
                if (window.scrollY > scrollThreshold && !isTouchingFooter) {
                    navbar.classList.add('navbar-scrolled');
                } else {
                    navbar.classList.remove('navbar-scrolled');
                }
            });

            // Job listings: AJAX filters (no page jump / scroll to top)
            const salarySteps = <?php echo json_encode(fp_job_salary_slider_steps()); ?>;

            function updateSalaryHiddenField(form) {
                if (!form) {
                    return;
                }

                const salaryRange = form.querySelector('#salaryRange');
                const salaryMinInput = form.querySelector('#salaryMinInput');
                const salaryRangeLabel = form.querySelector('#salaryRangeLabel');
                if (!salaryRange || !salaryMinInput || !salaryRangeLabel) {
                    return;
                }

                const step = salaryRange.value;
                const amount = salarySteps[step] || 0;
                salaryMinInput.value = amount > 0 ? amount : '';
                salaryRangeLabel.textContent = amount > 0
                    ? new Intl.NumberFormat('en-IN').format(amount) + '+'
                    : 'Any';
            }

            function prepareFilterForm(form) {
                updateSalaryHiddenField(form);
                const remoteCheckbox = form.querySelector('#jt-remote');
                if (remoteCheckbox && !remoteCheckbox.checked) {
                    remoteCheckbox.disabled = true;
                }
            }

            function closeMobileFilters() {
                if (window.innerWidth >= 992) {
                    return;
                }

                const offcanvasEl = document.getElementById('mobileFilterCanvas');
                if (offcanvasEl && typeof bootstrap !== 'undefined') {
                    const instance = bootstrap.Offcanvas.getInstance(offcanvasEl);
                    if (instance) {
                        instance.hide();
                    }
                }
            }

            function resetDesktopSidebar() {
                const offcanvasEl = document.getElementById('mobileFilterCanvas');
                if (!offcanvasEl || window.innerWidth < 992) {
                    return;
                }

                offcanvasEl.classList.remove('hiding', 'show');
                offcanvasEl.removeAttribute('aria-hidden');
                offcanvasEl.style.visibility = '';
                offcanvasEl.style.transform = '';

                document.querySelectorAll('.offcanvas-backdrop').forEach(function (backdrop) {
                    backdrop.remove();
                });
                document.body.classList.remove('offcanvas-backdrop', 'modal-open');
                document.body.style.overflow = '';
                document.body.style.paddingRight = '';
            }

            function swapFragment(id, doc) {
                const next = doc.getElementById(id);
                const current = document.getElementById(id);
                if (!next || !current) {
                    return;
                }

                current.innerHTML = next.innerHTML;
            }

            function buildAjaxUrl(target) {
                const url = new URL(target, window.location.href);
                url.searchParams.set('ajax', '1');
                return url;
            }

            async function loadJobListings(target) {
                const url = buildAjaxUrl(target);
                const results = document.getElementById('ajax-job-results');
                if (results) {
                    results.classList.add('is-loading');
                }

                try {
                    const response = await fetch(url.toString(), {
                        headers: { 'X-Requested-With': 'XMLHttpRequest' },
                    });

                    if (!response.ok) {
                        throw new Error('Filter request failed');
                    }

                    const html = await response.text();
                    const doc = new DOMParser().parseFromString(html, 'text/html');

                    swapFragment('ajax-quick-filters', doc);
                    swapFragment('ajax-mobile-filter-badge', doc);
                    swapFragment('ajax-filter-sidebar', doc);
                    swapFragment('ajax-job-results', doc);

                    refreshRevealElements(document.getElementById('ajax-job-results'));

                    const cleanUrl = new URL(url.toString());
                    cleanUrl.searchParams.delete('ajax');
                    const nextPath = cleanUrl.pathname + cleanUrl.search;
                    history.replaceState(null, '', nextPath);

                    closeMobileFilters();
                    resetDesktopSidebar();
                } catch (error) {
                    const fallback = new URL(url.toString());
                    fallback.searchParams.delete('ajax');
                    window.location.href = fallback.pathname + fallback.search;
                } finally {
                    document.getElementById('ajax-job-results')?.classList.remove('is-loading');
                }
            }

            document.addEventListener('submit', function (event) {
                const form = event.target.closest('#jobFiltersForm');
                if (!form) {
                    return;
                }

                event.preventDefault();
                prepareFilterForm(form);
                const params = new URLSearchParams(new FormData(form));
                loadJobListings('job-listings.php?' + params.toString());
            });

            document.addEventListener('click', function (event) {
                const link = event.target.closest('.fp-job-filter-link');
                if (!link || !link.href) {
                    return;
                }

                event.preventDefault();
                loadJobListings(link.href);
            });

            document.addEventListener('change', function (event) {
                if (event.target.id !== 'jobSortSelect') {
                    return;
                }

                const form = document.getElementById('jobFiltersForm');
                const sortInput = document.getElementById('filterSortInput');
                if (!form || !sortInput) {
                    return;
                }

                sortInput.value = event.target.value;
                prepareFilterForm(form);
                const params = new URLSearchParams(new FormData(form));
                loadJobListings('job-listings.php?' + params.toString());
            });

            document.addEventListener('input', function (event) {
                if (event.target.id !== 'salaryRange') {
                    return;
                }

                updateSalaryHiddenField(event.target.closest('form'));
            });

            updateSalaryHiddenField(document.getElementById('jobFiltersForm'));
            resetDesktopSidebar();
        });
    </script>
</body>
</html>
