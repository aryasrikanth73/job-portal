<?php
require_once __DIR__ . '/includes/public_init.php';

$jobId = (int) ($_GET['id'] ?? 0);
$job = $jobId > 0 ? fp_fetch_job_by_id($jobId) : null;

if (!$job) {
    http_response_code(404);
    $pageTitle = 'Job Not Found';
} else {
    $pageTitle = $job['title'];
}

$currentPage = 'opportunities';
$footerClass = '';
$companyName = $job['company_name'] ?? '';
$initials = $job ? fp_company_initials($companyName) : 'FP';
$returnUrl = 'job-details.php?id=' . $jobId;
$seekerUser = ($job && $fpCurrentUser && $fpCurrentUser['role'] === 'job_seeker') ? $fpCurrentUser : null;
$seekerProfile = $seekerUser ? fp_jobseeker_profile($seekerUser['id']) : null;
$seekerProfileId = $seekerUser ? fp_jobseeker_profile_id($seekerUser['id']) : 0;
$seekerApplied = ($job && $seekerProfileId) ? fp_seeker_has_applied($seekerProfileId, $jobId) : false;
$seekerHasResume = $seekerProfile && !empty($seekerProfile['resume_file_path']);
if ($seekerApplied) {
    fp_sweetalert_notice('success', 'You have already applied for this job.');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle); ?> | Finance Port</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <style>
        :root {
            --primary:#071126; --secondary:#1E63FF; --accent:#D84000; --bg-light:#F8FAFC;
            --text-main:#1E293B; --text-muted:#64748B; --border-light:#E2E8F0; --radius-md:16px;
            --shadow-md:0 10px 30px -5px rgba(13,43,78,0.08);
        }
        body { font-family:'Inter',sans-serif; color:var(--text-main); background:#fff; }
        .section-py { padding:120px 0 80px; }
        .premium-card { background:#fff; border:1px solid var(--border-light); border-radius:var(--radius-md); box-shadow:var(--shadow-md); }
        .btn-premium { background:var(--accent); color:#fff; border:none; border-radius:var(--radius-md); padding:12px 24px; font-weight:600; }
        .btn-premium:hover { background:#A83000; color:#fff; }
        .btn-outline-custom { border:1px solid var(--border-light); border-radius:var(--radius-md); padding:12px 24px; font-weight:600; color:var(--primary); text-decoration:none; }
        .job-logo { width:72px; height:72px; border-radius:14px; background:var(--bg-light); border:1px solid var(--border-light); display:flex; align-items:center; justify-content:center; font-weight:800; font-size:1.5rem; color:var(--primary); }
        .job-tag { background:var(--bg-light); color:var(--text-muted); padding:4px 10px; border-radius:6px; font-size:.8rem; font-weight:600; border:1px solid var(--border-light); margin:0 6px 6px 0; display:inline-block; }
        .detail-meta { color:var(--text-muted); font-weight:600; }
        .detail-body h2, .detail-body h3 { margin-top:1.5rem; font-size:1.15rem; }
        .detail-body p, .detail-body li { color:var(--text-muted); line-height:1.7; }
    </style>
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php fp_render_flashes(); ?>

<section class="section-py">
    <div class="container">
        <?php if (!$job): ?>
            <div class="premium-card p-5 text-center">
                <h1 class="h3 mb-3">Job not found</h1>
                <p class="text-muted mb-4">This role may have been closed or removed.</p>
                <a href="<?php echo fp_url('job-listings.php'); ?>" class="btn btn-premium">Browse Jobs</a>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="premium-card p-4 p-md-5 mb-4">
                        <div class="d-flex gap-3 align-items-start mb-4">
                            <div class="job-logo"><?php echo e($initials); ?></div>
                            <div>
                                <h1 class="h2 mb-2"><?php echo e($job['title']); ?></h1>
                                <div class="detail-meta mb-2"><?php echo e($companyName); ?> &bull; <?php echo e($job['location']); ?></div>
                                <div class="d-flex flex-wrap gap-3 detail-meta small">
                                    <span><i class="fa-solid fa-briefcase"></i> <?php echo e(fp_format_job_type($job['job_type'])); ?></span>
                                    <span><i class="fa-solid fa-building"></i> <?php echo e(ucfirst(str_replace('_', ' ', $job['workplace_type']))); ?></span>
                                    <span><i class="fa-solid fa-money-bill-wave"></i> <?php echo e(fp_money_range($job['salary_currency'], $job['salary_min'], $job['salary_max'])); ?></span>
                                    <span><i class="fa-regular fa-clock"></i> <?php echo e(fp_time_ago($job['posted_at'] ?? $job['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>

                        <?php if (!empty($job['short_description'])): ?>
                            <p class="lead text-muted"><?php echo e($job['short_description']); ?></p>
                        <?php endif; ?>

                        <div class="detail-body">
                            <h2>Job Description</h2>
                            <?php echo nl2br(e($job['description'])); ?>

                            <?php if (!empty($job['requirements'])): ?>
                                <h3>Requirements</h3>
                                <?php echo nl2br(e($job['requirements'])); ?>
                            <?php endif; ?>

                            <?php if (!empty($job['responsibilities'])): ?>
                                <h3>Responsibilities</h3>
                                <?php echo nl2br(e($job['responsibilities'])); ?>
                            <?php endif; ?>
                        </div>

                        <?php
                        $tags = array_filter(array_map('trim', explode(',', (string) ($job['skills_required'] ?? ''))));
                        if (!empty($tags)):
                        ?>
                            <div class="mt-4">
                                <h3 class="h6 text-uppercase text-muted">Skills</h3>
                                <?php foreach ($tags as $tag): ?>
                                    <span class="job-tag"><?php echo e($tag); ?></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="premium-card p-4 sticky-top" style="top:100px;">
                        <h2 class="h5 mb-3">Apply for this role</h2>
                        <?php if ($seekerUser): ?>
                            <?php if ($seekerApplied): ?>
                                <span class="badge rounded-pill text-bg-success mb-3">Already applied</span>
                                <a href="<?php echo fp_url('jobseeker/applications.php'); ?>" class="btn btn-outline-custom w-100 text-center mb-3">View My Applications</a>
                            <?php elseif (!$seekerHasResume): ?>
                                <p class="text-muted small">Upload your resume in your profile before applying.</p>
                                <a href="<?php echo fp_url('jobseeker/profile.php'); ?>" class="btn btn-premium w-100 py-3 mb-3">Upload Resume</a>
                            <?php else: ?>
                                <p class="text-muted small mb-3">Your profile and resume will be shared with the employer.</p>
                                <a href="<?php echo fp_url('jobseeker/job.php?id=' . $jobId . '#apply'); ?>" class="btn btn-premium w-100 py-3 mb-3">
                                    <i class="fa-solid fa-paper-plane me-2"></i>Apply Now
                                </a>
                            <?php endif; ?>
                            <a href="<?php echo fp_url('jobseeker/dashboard.php'); ?>" class="btn btn-outline-custom w-100 text-center mb-3">Go to Dashboard</a>
                        <?php else: ?>
                            <p class="text-muted">Sign in or create a free account to submit your application.</p>
                            <button type="button" class="btn btn-premium w-100 py-3 mb-3 fp-open-auth" data-auth-mode="login" data-return-url="<?php echo e($returnUrl); ?>">Apply Now</button>
                        <?php endif; ?>
                        <a href="<?php echo fp_url('job-listings.php'); ?>" class="btn btn-outline-custom w-100 text-center">Back to Jobs</a>

                        <hr class="my-4">
                        <div class="small detail-meta">
                            <?php if (!empty($job['qualification_required'])): ?>
                                <div class="mb-2"><strong>Qualification:</strong> <?php echo e($job['qualification_required']); ?></div>
                            <?php endif; ?>
                            <div class="mb-2"><strong>Experience:</strong> <?php echo e((float) $job['experience_min_years']); ?><?php echo $job['experience_max_years'] ? ' - ' . (float) $job['experience_max_years'] : '+'; ?> years</div>
                            <?php if (!empty($job['application_deadline'])): ?>
                                <div><strong>Apply before:</strong> <?php echo e(date('M j, Y', strtotime($job['application_deadline']))); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
