<?php
/**
 * Local SMTP test — run: php scripts/test_smtp.php
 * Update config/mail.local.php first, then run this to verify Gmail auth.
 */
require_once __DIR__ . '/../includes/app.php';
require_once __DIR__ . '/../vendor/autoload.php';

try {
    fp_send_mail(
        fp_mail_config()['smtp_username'],
        'SMTP Test',
        'Finance Port SMTP test',
        '<p>If you received this, SMTP is working.</p>'
    );
    echo "SUCCESS — check your inbox.\n";
} catch (Throwable $exception) {
    echo "FAIL — " . $exception->getMessage() . "\n";
    exit(1);
}
