<?php

function fp_sweetalert_icon($type) {
    $map = array(
        'success' => 'success',
        'danger' => 'error',
        'error' => 'error',
        'warning' => 'warning',
        'info' => 'info',
    );

    return $map[$type] ?? 'info';
}

function fp_sweetalert_title($type) {
    $map = array(
        'success' => 'Success',
        'danger' => 'Error',
        'error' => 'Error',
        'warning' => 'Notice',
        'info' => 'Info',
    );

    return $map[$type] ?? 'Notice';
}

function fp_sweetalert_notice($type, $message, $title = '') {
    if (trim((string) $message) === '') {
        return;
    }

    if (!isset($GLOBALS['fp_sweetalert_notices'])) {
        $GLOBALS['fp_sweetalert_notices'] = array();
    }

    $GLOBALS['fp_sweetalert_notices'][] = array(
        'type' => $type,
        'message' => $message,
        'title' => $title !== '' ? $title : fp_sweetalert_title($type),
    );
}

function fp_render_flashes() {
    $messages = fp_flashes();
    $notices = $GLOBALS['fp_sweetalert_notices'] ?? array();

    foreach ($notices as $notice) {
        $messages[] = array(
            'type' => $notice['type'],
            'message' => $notice['message'],
            'title' => $notice['title'] ?? fp_sweetalert_title($notice['type']),
        );
    }

    if (empty($messages)) {
        return;
    }

    $payload = array();
    foreach ($messages as $flash) {
        $type = $flash['type'] ?? 'info';
        $payload[] = array(
            'type' => $type,
            'icon' => fp_sweetalert_icon($type),
            'title' => $flash['title'] ?? fp_sweetalert_title($type),
            'message' => (string) ($flash['message'] ?? ''),
        );
    }

    echo '<script type="application/json" id="fp-flash-data">';
    echo json_encode($payload, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
    echo '</script>';
}

function fp_sweetalert_head() {
    static $printed = false;
    if ($printed) {
        return;
    }
    $printed = true;
    echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">';
}

function fp_sweetalert_foot() {
    static $printed = false;
    if ($printed) {
        return;
    }
    $printed = true;
    fp_sweetalert_head();
    ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
(function () {
    if (window.fpSweetAlertInitialized) {
        return;
    }
    window.fpSweetAlertInitialized = true;

    var accentColor = '#D84000';
    var cancelColor = '#64748B';

    window.fpSwalToast = function (message, type) {
        type = type || 'info';
        var iconMap = { success: 'success', danger: 'error', error: 'error', warning: 'warning', info: 'info' };
        return Swal.fire({
            icon: iconMap[type] || 'info',
            title: message,
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3500,
            timerProgressBar: true
        });
    };

    window.fpSwalAlert = function (message, type, title) {
        type = type || 'info';
        var iconMap = { success: 'success', danger: 'error', error: 'error', warning: 'warning', info: 'info' };
        var titleMap = { success: 'Success', danger: 'Error', error: 'Error', warning: 'Notice', info: 'Info' };
        return Swal.fire({
            icon: iconMap[type] || 'info',
            title: title || titleMap[type] || 'Notice',
            text: message,
            confirmButtonColor: accentColor
        });
    };

    window.fpSwalConfirm = function (message, title) {
        return Swal.fire({
            title: title || 'Please confirm',
            text: message || 'Are you sure?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: accentColor,
            cancelButtonColor: cancelColor,
            confirmButtonText: 'Yes, continue',
            cancelButtonText: 'Cancel'
        });
    };

    function bootstrapTypeFromAlertClass(el) {
        if (el.classList.contains('alert-success')) return 'success';
        if (el.classList.contains('alert-danger')) return 'danger';
        if (el.classList.contains('alert-warning')) return 'warning';
        return 'info';
    }

    function showQueuedFlashes(flashes) {
        if (!flashes || !flashes.length) return;

        var index = 0;
        function showNext() {
            if (index >= flashes.length) return;
            var item = flashes[index++];
            Swal.fire({
                icon: item.icon || 'info',
                title: item.title || 'Notice',
                text: item.message || '',
                confirmButtonColor: accentColor
            }).then(showNext);
        }
        showNext();
    }

    function initFpSweetAlert() {
        var flashEl = document.getElementById('fp-flash-data');
        if (flashEl) {
            try {
                showQueuedFlashes(JSON.parse(flashEl.textContent || '[]'));
            } catch (e) {}
            flashEl.remove();
        }

        document.querySelectorAll('[data-fp-swal-auto]').forEach(function (el) {
            var type = el.getAttribute('data-fp-swal-type') || bootstrapTypeFromAlertClass(el);
            var title = el.getAttribute('data-fp-swal-title') || '';
            var text = el.getAttribute('data-fp-swal-text') || el.textContent.replace(/\s+/g, ' ').trim();
            Swal.fire({
                icon: ({ success: 'success', danger: 'error', warning: 'warning', info: 'info' })[type] || 'info',
                title: title || ({ success: 'Success', danger: 'Error', warning: 'Notice', info: 'Info' })[type] || 'Notice',
                html: el.innerHTML.trim(),
                confirmButtonColor: accentColor
            });
            el.remove();
        });

        document.querySelectorAll('form[data-fp-confirm]').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (form.dataset.fpConfirmed === '1') {
                    form.dataset.fpConfirmed = '0';
                    return;
                }
                event.preventDefault();
                fpSwalConfirm(form.getAttribute('data-fp-confirm')).then(function (result) {
                    if (result.isConfirmed) {
                        form.dataset.fpConfirmed = '1';
                        if (typeof form.requestSubmit === 'function') {
                            form.requestSubmit();
                        } else {
                            form.submit();
                        }
                    }
                });
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initFpSweetAlert);
    } else {
        initFpSweetAlert();
    }
})();
</script>
<?php
}
