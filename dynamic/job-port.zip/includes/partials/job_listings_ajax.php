<?php
/**
 * AJAX fragment for job-listings.php — quick filters, sidebar form, and results.
 * Expects: $filters, $quickFilters, $jobs, $totalJobs, $showingFrom, $showingTo,
 *          $totalPages, $page, $activeFilterCount, $salaryStep
 */
?>
<div id="ajax-quick-filters">
    <div class="quick-filters-scroll">
        <?php foreach ($quickFilters as $quickFilter): ?>
            <?php
            $quickParams = array_merge(
                array(
                    'q' => $filters['q'],
                    'skills' => $filters['skills'],
                    'location' => $filters['location'],
                    'sort' => $filters['sort'],
                ),
                $quickFilter['params']
            );
            if ($quickFilter['params'] === array()) {
                $quickParams = array_merge($quickParams, array(
                    'job_type' => '',
                    'qualification' => '',
                    'category' => '',
                    'workplace_type' => '',
                    'experience' => '',
                    'salary_min' => 0,
                ));
            }
            $isActive = fp_job_quick_filter_is_active($quickFilter, $filters);
            ?>
            <a
                class="filter-pill text-decoration-none fp-job-filter-link<?php echo $isActive ? ' active' : ''; ?>"
                href="<?php echo e(fp_job_listings_url($quickParams)); ?>"
            ><?php echo e($quickFilter['label']); ?></a>
        <?php endforeach; ?>
    </div>
</div>

<div id="ajax-mobile-filter-badge">
    <?php if ($activeFilterCount > 0): ?>
        <span class="badge bg-primary rounded-pill"><?php echo e($activeFilterCount); ?></span>
    <?php endif; ?>
</div>

<div id="ajax-filter-sidebar">
    <form method="get" action="<?php echo fp_url('job-listings.php'); ?>" id="jobFiltersForm" class="filter-sidebar w-100">
        <input type="hidden" name="q" value="<?php echo e($filters['q']); ?>">
        <input type="hidden" name="skills" value="<?php echo e($filters['skills']); ?>">
        <input type="hidden" name="location" value="<?php echo e($filters['location']); ?>">
        <input type="hidden" name="sort" id="filterSortInput" value="<?php echo e($filters['sort']); ?>">

        <div class="d-flex justify-content-between align-items-center mb-4 d-none d-lg-flex">
            <h4 class="mb-0 fs-5">Filters</h4>
            <a href="<?php echo e(fp_job_listings_url(array(
                'q' => $filters['q'],
                'skills' => $filters['skills'],
                'location' => $filters['location'],
                'sort' => $filters['sort'],
            ))); ?>" class="text-muted small text-decoration-none fw-medium fp-job-filter-link">Clear All</a>
        </div>

        <div class="filter-group">
            <h6 class="filter-group-title">Qualification</h6>
            <?php
            $qualificationOptions = array(
                'CA' => 'Chartered Accountant (CA)',
                'CMA' => 'CMA',
                'CPA' => 'CPA',
                'CS' => 'Company Secretary (CS)',
                'MBA' => 'MBA Finance',
            );
            foreach ($qualificationOptions as $qualValue => $qualLabel):
            ?>
            <div class="form-check mb-2">
                <input
                    class="form-check-input"
                    type="checkbox"
                    name="qualification[]"
                    id="q-<?php echo e(strtolower($qualValue)); ?>"
                    value="<?php echo e($qualValue); ?>"
                    <?php echo fp_job_filter_value_in_list($qualValue, $filters['qualification']) ? 'checked' : ''; ?>
                >
                <label class="form-check-label" for="q-<?php echo e(strtolower($qualValue)); ?>"><?php echo e($qualLabel); ?></label>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="filter-group">
            <h6 class="filter-group-title">Job Type</h6>
            <?php
            $jobTypeOptions = array(
                'full_time' => 'Full Time',
                'contract' => 'Contract',
                'internship' => 'Internship',
            );
            foreach ($jobTypeOptions as $typeValue => $typeLabel):
            ?>
            <div class="form-check mb-2">
                <input
                    class="form-check-input"
                    type="checkbox"
                    name="job_type[]"
                    id="jt-<?php echo e(str_replace('_', '-', $typeValue)); ?>"
                    value="<?php echo e($typeValue); ?>"
                    <?php echo fp_job_filter_value_in_list($typeValue, $filters['job_type']) ? 'checked' : ''; ?>
                >
                <label class="form-check-label" for="jt-<?php echo e(str_replace('_', '-', $typeValue)); ?>"><?php echo e($typeLabel); ?></label>
            </div>
            <?php endforeach; ?>
            <div class="form-check mb-2">
                <input
                    class="form-check-input"
                    type="checkbox"
                    name="workplace_type"
                    id="jt-remote"
                    value="remote"
                    <?php echo $filters['workplace_type'] === 'remote' ? 'checked' : ''; ?>
                >
                <label class="form-check-label" for="jt-remote">Remote</label>
            </div>
        </div>

        <div class="filter-group">
            <h6 class="filter-group-title">Experience</h6>
            <select class="form-select text-muted fs-6" name="experience">
                <option value="" <?php echo $filters['experience'] === '' ? 'selected' : ''; ?>>Any Experience</option>
                <option value="fresher" <?php echo $filters['experience'] === 'fresher' ? 'selected' : ''; ?>>Fresher (0-1 yrs)</option>
                <option value="mid" <?php echo $filters['experience'] === 'mid' ? 'selected' : ''; ?>>Mid-Level (2-5 yrs)</option>
                <option value="senior" <?php echo $filters['experience'] === 'senior' ? 'selected' : ''; ?>>Senior (5-10 yrs)</option>
                <option value="executive" <?php echo $filters['experience'] === 'executive' ? 'selected' : ''; ?>>Executive (10+ yrs)</option>
            </select>
        </div>

        <div class="filter-group">
            <h6 class="filter-group-title">Minimum Salary (INR)</h6>
            <input
                type="range"
                class="form-range"
                min="0"
                max="5"
                step="1"
                id="salaryRange"
                value="<?php echo e($salaryStep); ?>"
            >
            <input type="hidden" name="salary_min" id="salaryMinInput" value="<?php echo e($filters['salary_min']); ?>">
            <div class="d-flex justify-content-between text-muted small fw-medium mt-1">
                <span>Any</span>
                <span id="salaryRangeLabel"><?php echo $filters['salary_min'] > 0 ? e(number_format($filters['salary_min'])) . '+' : 'Any'; ?></span>
                <span>20L+</span>
            </div>
        </div>

        <button class="btn btn-premium w-100" type="submit">Apply Filters</button>
    </form>
</div>

<div id="ajax-job-results">
    <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center mb-4">
        <div>
            <h3 class="mb-1 fs-4">Finance &amp; Accounting Jobs</h3>
            <p class="text-muted mb-0 fs-6">Showing <?php echo e($showingFrom); ?>–<?php echo e($showingTo); ?> of <?php echo e($totalJobs); ?> jobs</p>
        </div>
        <div class="d-flex align-items-center gap-2 mt-3 mt-sm-0">
            <span class="text-muted fw-medium small text-nowrap">Sort By:</span>
            <select class="form-select form-select-sm border-light bg-white text-primary fw-medium" id="jobSortSelect" style="width: auto; padding-right: 30px;">
                <option value="relevance" <?php echo $filters['sort'] === 'relevance' ? 'selected' : ''; ?>>Relevance</option>
                <option value="latest" <?php echo $filters['sort'] === 'latest' ? 'selected' : ''; ?>>Latest</option>
                <option value="salary_desc" <?php echo $filters['sort'] === 'salary_desc' ? 'selected' : ''; ?>>Highest Salary</option>
                <option value="salary_asc" <?php echo $filters['sort'] === 'salary_asc' ? 'selected' : ''; ?>>Lowest Salary</option>
            </select>
        </div>
    </div>

    <div class="d-flex flex-column gap-3">
        <?php if (empty($jobs)): ?>
            <div class="premium-card p-5 text-center">
                <h4 class="mb-2">No jobs matched your search</h4>
                <p class="text-muted mb-4">Try different keywords or clear your filters.</p>
                <a href="<?php echo fp_url('job-listings.php'); ?>" class="btn btn-outline-custom fp-job-filter-link">Clear Search</a>
            </div>
        <?php else: ?>
            <?php foreach ($jobs as $job): ?>
                <?php include __DIR__ . '/job_card.php'; ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="d-flex justify-content-center gap-2 mt-5 flex-wrap">
        <?php if ($page > 1): ?>
            <a class="btn btn-outline-custom fp-job-filter-link" href="<?php echo e(fp_job_listings_url($filters, array('page' => $page - 1))); ?>">Previous</a>
        <?php endif; ?>
        <?php if ($page < $totalPages): ?>
            <a class="btn btn-outline-custom fp-job-filter-link" href="<?php echo e(fp_job_listings_url($filters, array('page' => $page + 1))); ?>">Next Page</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
