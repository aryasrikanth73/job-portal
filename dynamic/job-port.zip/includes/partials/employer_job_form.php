<?php
$form = $jobForm ?? array();
$categories = fp_fetch_job_categories();
?>
<div class="row g-3">
    <div class="col-md-8">
        <label class="form-label" for="title">Job title</label>
        <input class="form-control" type="text" id="title" name="title" value="<?php echo e($form['title'] ?? ''); ?>" required>
    </div>
    <div class="col-md-4">
        <label class="form-label" for="status">Status</label>
        <select class="form-select" id="status" name="status">
            <?php foreach (array('draft' => 'Draft', 'open' => 'Open', 'closed' => 'Closed') as $value => $label): ?>
                <option value="<?php echo e($value); ?>" <?php echo ($form['status'] ?? 'open') === $value ? 'selected' : ''; ?>><?php echo e($label); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-12">
        <label class="form-label" for="short_description">Short summary</label>
        <input class="form-control" type="text" id="short_description" name="short_description" maxlength="255" value="<?php echo e($form['short_description'] ?? ''); ?>" placeholder="One-line pitch for job cards">
    </div>
    <div class="col-12">
        <label class="form-label" for="description">Job description</label>
        <textarea class="form-control" id="description" name="description" rows="5" required><?php echo e($form['description'] ?? ''); ?></textarea>
    </div>
    <div class="col-md-6">
        <label class="form-label" for="responsibilities">Responsibilities</label>
        <textarea class="form-control" id="responsibilities" name="responsibilities" rows="4"><?php echo e($form['responsibilities'] ?? ''); ?></textarea>
    </div>
    <div class="col-md-6">
        <label class="form-label" for="requirements">Requirements</label>
        <textarea class="form-control" id="requirements" name="requirements" rows="4"><?php echo e($form['requirements'] ?? ''); ?></textarea>
    </div>
    <div class="col-md-6">
        <label class="form-label" for="skills_required">Skills (comma-separated)</label>
        <input class="form-control" type="text" id="skills_required" name="skills_required" value="<?php echo e($form['skills_required'] ?? ''); ?>">
    </div>
    <div class="col-md-6">
        <label class="form-label" for="qualification_required">Qualification</label>
        <input class="form-control" type="text" id="qualification_required" name="qualification_required" value="<?php echo e($form['qualification_required'] ?? ''); ?>" placeholder="CA, MBA, B.Com">
    </div>
    <div class="col-md-4">
        <label class="form-label" for="category_id">Category</label>
        <select class="form-select" id="category_id" name="category_id">
            <option value="">Select category</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?php echo (int) $category['id']; ?>" <?php echo (int) ($form['category_id'] ?? 0) === (int) $category['id'] ? 'selected' : ''; ?>>
                    <?php echo e($category['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-4">
        <label class="form-label" for="location">Location</label>
        <input class="form-control" type="text" id="location" name="location" value="<?php echo e($form['location'] ?? ''); ?>" required>
    </div>
    <div class="col-md-4">
        <label class="form-label" for="openings">Openings</label>
        <input class="form-control" type="number" min="1" id="openings" name="openings" value="<?php echo e((string) ($form['openings'] ?? '1')); ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label" for="job_type">Job type</label>
        <select class="form-select" id="job_type" name="job_type">
            <?php foreach (array('full_time' => 'Full time', 'part_time' => 'Part time', 'contract' => 'Contract', 'internship' => 'Internship', 'temporary' => 'Temporary') as $value => $label): ?>
                <option value="<?php echo e($value); ?>" <?php echo ($form['job_type'] ?? 'full_time') === $value ? 'selected' : ''; ?>><?php echo e($label); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-4">
        <label class="form-label" for="workplace_type">Workplace</label>
        <select class="form-select" id="workplace_type" name="workplace_type">
            <?php foreach (array('onsite' => 'On-site', 'remote' => 'Remote', 'hybrid' => 'Hybrid') as $value => $label): ?>
                <option value="<?php echo e($value); ?>" <?php echo ($form['workplace_type'] ?? 'onsite') === $value ? 'selected' : ''; ?>><?php echo e($label); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-4">
        <label class="form-label" for="application_deadline">Application deadline</label>
        <input class="form-control" type="date" id="application_deadline" name="application_deadline" value="<?php echo e($form['application_deadline'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
        <label class="form-label" for="experience_min_years">Min experience (yrs)</label>
        <input class="form-control" type="number" min="0" step="0.5" id="experience_min_years" name="experience_min_years" value="<?php echo e((string) ($form['experience_min_years'] ?? '0')); ?>">
    </div>
    <div class="col-md-3">
        <label class="form-label" for="experience_max_years">Max experience (yrs)</label>
        <input class="form-control" type="number" min="0" step="0.5" id="experience_max_years" name="experience_max_years" value="<?php echo e((string) ($form['experience_max_years'] ?? '')); ?>">
    </div>
    <div class="col-md-3">
        <label class="form-label" for="salary_min">Salary min (INR)</label>
        <input class="form-control" type="number" min="0" id="salary_min" name="salary_min" value="<?php echo e((string) ($form['salary_min'] ?? '')); ?>">
    </div>
    <div class="col-md-3">
        <label class="form-label" for="salary_max">Salary max (INR)</label>
        <input class="form-control" type="number" min="0" id="salary_max" name="salary_max" value="<?php echo e((string) ($form['salary_max'] ?? '')); ?>">
    </div>
</div>
