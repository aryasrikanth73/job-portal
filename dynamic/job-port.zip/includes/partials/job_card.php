<?php
if (empty($job) || !is_array($job)) {
    return;
}

$companyName = $job['company_name'] ?? 'Employer';
$initials = fp_company_initials($companyName);
$postedLabel = fp_time_ago($job['posted_at'] ?? $job['created_at'] ?? null);
$salaryLabel = fp_money_range($job['salary_currency'] ?? 'INR', $job['salary_min'], $job['salary_max']);
$experienceMin = isset($job['experience_min_years']) ? (float) $job['experience_min_years'] : 0;
$experienceMax = isset($job['experience_max_years']) ? (float) $job['experience_max_years'] : null;
$experienceLabel = $experienceMax !== null && $experienceMax > $experienceMin
    ? $experienceMin . '-' . $experienceMax . ' Yrs'
    : ($experienceMin > 0 ? $experienceMin . '+ Yrs' : 'Fresher');
$jobTypeLabel = fp_format_job_type($job['job_type'] ?? 'full_time');
$workplace = ucfirst(str_replace('_', ' ', (string) ($job['workplace_type'] ?? 'onsite')));
$detailUrl = fp_url('job-details.php?id=' . (int) $job['id']);
$tags = array_filter(array_map('trim', explode(',', (string) ($job['skills_required'] ?? ''))));
if (empty($tags) && !empty($job['qualification_required'])) {
    $tags = array($job['qualification_required']);
}
$tags = array_slice($tags, 0, 3);
?>
<div class="job-card reveal">
    <div class="d-flex flex-column flex-md-row gap-4">
        <div class="d-flex flex-grow-1 gap-3">
            <div class="job-logo"><?php echo e($initials); ?></div>
            <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                    <h4 class="mb-0 fs-5 text-primary">
                        <a href="<?php echo e($detailUrl); ?>" class="text-decoration-none text-primary"><?php echo e($job['title']); ?></a>
                    </h4>
                </div>
                <div class="text-muted fs-6 fw-medium mb-2">
                    <?php echo e($companyName); ?> &bull; <?php echo e($job['location']); ?> (<?php echo e($workplace); ?>)
                </div>
                <div class="d-flex flex-wrap gap-3 text-muted small fw-medium mb-3">
                    <span class="d-flex align-items-center gap-1"><i class="fa-solid fa-briefcase"></i> <?php echo e($experienceLabel); ?></span>
                    <span class="d-flex align-items-center gap-1"><i class="fa-solid fa-money-bill-wave"></i> <?php echo e($salaryLabel); ?></span>
                    <span class="d-flex align-items-center gap-1"><i class="fa-regular fa-clock"></i> <?php echo e($postedLabel); ?></span>
                    <span class="d-flex align-items-center gap-1"><i class="fa-solid fa-clock"></i> <?php echo e($jobTypeLabel); ?></span>
                </div>
                <?php if (!empty($tags)): ?>
                <div class="d-flex flex-wrap gap-2">
                    <?php foreach ($tags as $tag): ?>
                        <span class="job-tag"><?php echo e($tag); ?></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="d-flex flex-row flex-md-column justify-content-between align-items-md-end border-top border-md-0 pt-3 pt-md-0 mt-3 mt-md-0" style="min-width: 140px;">
            <div class="d-flex flex-column gap-2 w-100 mt-auto">
                <a href="<?php echo e($detailUrl); ?>" class="btn btn-outline-custom w-100 py-2 fs-6">View Details</a>
                <button type="button" class="btn btn-premium w-100 py-2 fs-6 fp-open-auth" data-auth-mode="login" data-return-url="<?php echo e($detailUrl); ?>">Apply Now</button>
            </div>
        </div>
    </div>
</div>
