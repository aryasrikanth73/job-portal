<?php
require_once __DIR__ . '/app.php';

if (!isset($basePath)) {
    $basePath = fp_url_base_path();
}

$fpCurrentUser = fp_current_user();