<?php
define('FP_DB_HOST', getenv('FP_DB_HOST') ?: 'localhost');
define('FP_DB_NAME', getenv('FP_DB_NAME') ?: 'job_portal');
define('FP_DB_USER', getenv('FP_DB_USER') ?: 'root');
define('FP_DB_PASS', getenv('FP_DB_PASS') ?: '');
define('FP_BASE_DIR', dirname(__DIR__));

function fp_app_base_path() {
    static $base = null;

    if ($base !== null) {
        return $base;
    }

    $projectRoot = str_replace('\\', '/', realpath(FP_BASE_DIR) ?: FP_BASE_DIR);
    $documentRoot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '');

    if ($documentRoot !== '' && strpos($projectRoot, $documentRoot) === 0) {
        $base = '/' . trim(substr($projectRoot, strlen($documentRoot)), '/');
    } else {
        $base = '';
    }

    return $base;
}

function fp_session_cookie_path() {
    $base = fp_app_base_path();

    if ($base === '' || $base === '/') {
        return '/';
    }

    return rtrim($base, '/') . '/';
}

function fp_url_base_path() {
    $base = fp_app_base_path();

    if ($base === '' || $base === '/') {
        return '';
    }

    return rtrim($base, '/') . '/';
}

function fp_session_start() {
    if (session_status() !== PHP_SESSION_NONE) {
        return;
    }

    $path = fp_session_cookie_path();

    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params(array(
            'lifetime' => 0,
            'path' => $path,
            'httponly' => true,
            'samesite' => 'Lax',
        ));
    } else {
        session_set_cookie_params(0, $path, '', false, true);
    }

    session_start();
}

fp_session_start();

require_once __DIR__ . '/sweetalert.php';

function fp_db() {
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = 'mysql:host=' . FP_DB_HOST . ';dbname=' . FP_DB_NAME . ';charset=utf8mb4';

    try {
        $pdo = new PDO($dsn, FP_DB_USER, FP_DB_PASS, array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ));
    } catch (PDOException $exception) {
        http_response_code(500);
        exit('Database connection failed. Please check the database configuration.');
    }

    return $pdo;
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function fp_redirect($path) {
    header('Location: ' . $path);
    exit;
}

function fp_site_path($path = '') {
    return fp_url_base_path() . ltrim((string) $path, '/');
}

function fp_redirect_site($path) {
    fp_redirect(fp_site_path($path));
}

function fp_flash($type, $message) {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = array();
    }

    $_SESSION['flash_messages'][] = array(
        'type' => $type,
        'message' => $message,
    );
}

function fp_flashes() {
    $messages = $_SESSION['flash_messages'] ?? array();
    unset($_SESSION['flash_messages']);
    return $messages;
}

function fp_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function fp_csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . e(fp_csrf_token()) . '">';
}

function fp_verify_csrf() {
    $postedToken = $_POST['csrf_token'] ?? '';
    return is_string($postedToken) && hash_equals(fp_csrf_token(), $postedToken);
}

function fp_require_csrf() {
    if (!fp_verify_csrf()) {
        fp_flash('danger', 'Your session expired. Please try again.');
        fp_redirect($_SERVER['HTTP_REFERER'] ?? 'login.php');
    }
}

function fp_current_user() {
    static $user = null;

    if ($user !== null) {
        return $user;
    }

    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $statement = fp_db()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $statement->execute(array((int) $_SESSION['user_id']));
    $user = $statement->fetch() ?: null;

    return $user;
}

function fp_login_user(array $user) {
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['user_role'] = $user['role'];
}

function fp_logout_user() {
    $_SESSION = array();

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }

    session_destroy();
    fp_session_start();
}

function fp_require_login($role = null, $loginPath = 'login.php') {
    $user = fp_current_user();

    if (!$user) {
        fp_flash('warning', 'Please sign in to continue.');
        $safeReturn = '';
        $requestUri = (string) ($_SERVER['REQUEST_URI'] ?? '');
        if (preg_match('#/(jobseeker|employer)/([a-z0-9_-]+\.php)#i', $requestUri, $matches)) {
            $safeReturn = fp_sanitize_return_url($matches[2]);
        }
        if ($safeReturn !== '') {
            fp_redirect($loginPath . '?return=' . urlencode($safeReturn));
        }
        fp_redirect($loginPath);
    }

    if ($user['status'] !== 'active') {
        fp_logout_user();
        fp_flash('danger', 'Your account is not active. Please contact support.');
        fp_redirect($loginPath);
    }

    if ($role !== null && $user['role'] !== $role) {
        fp_flash('danger', 'You do not have permission to access that page.');
        fp_redirect($loginPath);
    }

    return $user;
}

function fp_jobseeker_profile($userId) {
    $statement = fp_db()->prepare('SELECT * FROM job_seeker_profiles WHERE user_id = ? LIMIT 1');
    $statement->execute(array((int) $userId));
    return $statement->fetch() ?: null;
}

function fp_ensure_jobseeker_profile($userId) {
    $profile = fp_jobseeker_profile($userId);
    if ($profile) {
        return $profile;
    }

    fp_db()->prepare(
        'INSERT INTO job_seeker_profiles (user_id, profile_level) VALUES (?, ?)'
    )->execute(array((int) $userId, 'basic'));

    return fp_jobseeker_profile($userId);
}

function fp_profile_completion($profile = null) {
    if (!$profile) {
        return 0;
    }

    $fields = array('headline', 'skills', 'experience_years', 'qualification', 'current_location', 'resume_file_path');
    $filled = 0;

    foreach ($fields as $field) {
        if (isset($profile[$field]) && trim((string) $profile[$field]) !== '') {
            $filled++;
        }
    }

    return (int) round(($filled / count($fields)) * 100);
}

function fp_allowed_resume_extensions() {
    return array('pdf', 'doc', 'docx');
}

function fp_upload_resume($fieldName, $userId) {
    if (empty($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    $file = $_FILES[$fieldName];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Resume upload failed. Please choose the file again.');
    }

    $maxBytes = 5 * 1024 * 1024;
    if ($file['size'] > $maxBytes) {
        throw new RuntimeException('Resume must be 5 MB or smaller.');
    }

    $originalName = $file['name'];
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    if (!in_array($extension, fp_allowed_resume_extensions(), true)) {
        throw new RuntimeException('Resume must be a PDF, DOC, or DOCX file.');
    }

    $uploadDir = FP_BASE_DIR . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'resumes';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true)) {
        throw new RuntimeException('Unable to create resume upload directory.');
    }

    $filename = 'resume_' . (int) $userId . '_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
    $absolutePath = $uploadDir . DIRECTORY_SEPARATOR . $filename;

    if (!move_uploaded_file($file['tmp_name'], $absolutePath)) {
        throw new RuntimeException('Unable to save uploaded resume.');
    }

    return array(
        'path' => 'uploads/resumes/' . $filename,
        'original_name' => $originalName,
    );
}

function fp_resume_mime_type($extension) {
    $map = array(
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    );

    return $map[strtolower((string) $extension)] ?? 'application/octet-stream';
}

function fp_resume_absolute_path($storedPath) {
    $storedPath = str_replace('\\', '/', trim((string) $storedPath));
    if ($storedPath === '' || strpos($storedPath, '..') !== false) {
        return null;
    }

    if (!preg_match('#^uploads/resumes/resume_\d+_[0-9]+_[a-f0-9]+\.(pdf|doc|docx)$#i', $storedPath)) {
        return null;
    }

    $absolutePath = FP_BASE_DIR . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $storedPath);
    if (!is_file($absolutePath)) {
        return null;
    }

    return $absolutePath;
}

function fp_jobseeker_resume_for_user($userId) {
    $profile = fp_jobseeker_profile($userId);
    if (!$profile || empty($profile['resume_file_path'])) {
        return null;
    }

    $absolutePath = fp_resume_absolute_path($profile['resume_file_path']);
    if ($absolutePath === null) {
        return null;
    }

    $extension = strtolower(pathinfo($absolutePath, PATHINFO_EXTENSION));

    return array(
        'path' => $profile['resume_file_path'],
        'absolute_path' => $absolutePath,
        'original_name' => $profile['resume_original_name'] ?? 'Resume.' . $extension,
        'uploaded_at' => $profile['resume_uploaded_at'] ?? null,
        'extension' => $extension,
        'mime_type' => fp_resume_mime_type($extension),
        'is_previewable' => $extension === 'pdf',
    );
}

function fp_format_job_type($jobType) {
    return ucwords(str_replace('_', ' ', (string) $jobType));
}

function fp_money_range($currency, $min, $max) {
    if ($min === null && $max === null) {
        return 'Salary not disclosed';
    }

    $prefix = strtoupper((string) $currency) . ' ';
    if ($min !== null && $max !== null) {
        return $prefix . number_format((float) $min) . ' - ' . number_format((float) $max);
    }

    if ($min !== null) {
        return $prefix . number_format((float) $min) . '+';
    }

    return 'Up to ' . $prefix . number_format((float) $max);
}

function fp_time_ago($datetime) {
    if (!$datetime) {
        return 'Recently';
    }

    $timestamp = strtotime((string) $datetime);
    if ($timestamp === false) {
        return 'Recently';
    }

    $diff = time() - $timestamp;
    if ($diff < 60) {
        return 'Just now';
    }
    if ($diff < 3600) {
        $mins = (int) floor($diff / 60);
        return $mins . 'm ago';
    }
    if ($diff < 86400) {
        $hours = (int) floor($diff / 3600);
        return $hours . 'h ago';
    }
    if ($diff < 604800) {
        $days = (int) floor($diff / 86400);
        return $days . 'd ago';
    }

    return date('M j, Y', $timestamp);
}

function fp_company_initials($companyName) {
    $parts = preg_split('/\s+/', trim((string) $companyName));
    $initials = '';

    foreach ($parts as $part) {
        if ($part !== '') {
            $initials .= strtoupper($part[0]);
        }
        if (strlen($initials) >= 2) {
            break;
        }
    }

    return $initials !== '' ? $initials : 'FP';
}

function fp_build_job_filters(array $input) {
    return array(
        'q' => trim((string) ($input['q'] ?? '')),
        'skills' => trim((string) ($input['skills'] ?? '')),
        'location' => trim((string) ($input['location'] ?? '')),
        'job_type' => trim((string) ($input['job_type'] ?? '')),
        'qualification' => trim((string) ($input['qualification'] ?? '')),
        'category' => trim((string) ($input['category'] ?? '')),
    );
}

function fp_count_open_jobs(array $filters = array()) {
    $filters = fp_build_job_filters($filters);
    $query = fp_job_list_query($filters, true);
    $statement = fp_db()->prepare($query['sql']);
    $statement->execute($query['params']);
    return (int) $statement->fetchColumn();
}

function fp_fetch_open_jobs(array $filters = array(), $limit = 10, $offset = 0) {
    $filters = fp_build_job_filters($filters);
    $query = fp_job_list_query($filters, false, $limit, $offset);
    $statement = fp_db()->prepare($query['sql']);
    $statement->execute($query['params']);
    return $statement->fetchAll();
}

function fp_fetch_job_by_id($jobId) {
    $statement = fp_db()->prepare(
        "SELECT j.*, ep.company_name, ep.company_website, ep.city AS company_city, ep.industry
         FROM jobs j
         INNER JOIN employer_profiles ep ON ep.id = j.employer_id
         WHERE j.id = ? AND j.status = 'open'
         LIMIT 1"
    );
    $statement->execute(array((int) $jobId));
    return $statement->fetch() ?: null;
}

function fp_job_list_query(array $filters, $countOnly = false, $limit = 10, $offset = 0) {
    $filters = fp_build_job_filters($filters);
    $where = array("j.status = 'open'");
    $params = array();

    if ($filters['q'] !== '') {
        $where[] = '(j.title LIKE ? OR j.description LIKE ? OR j.short_description LIKE ? OR ep.company_name LIKE ?)';
        $like = '%' . $filters['q'] . '%';
        $params = array_merge($params, array($like, $like, $like, $like));
    }

    if ($filters['skills'] !== '') {
        $where[] = '(j.skills_required LIKE ? OR j.title LIKE ?)';
        $like = '%' . $filters['skills'] . '%';
        $params[] = $like;
        $params[] = $like;
    }

    if ($filters['location'] !== '') {
        $where[] = 'j.location LIKE ?';
        $params[] = '%' . $filters['location'] . '%';
    }

    if ($filters['job_type'] !== '') {
        $where[] = 'j.job_type = ?';
        $params[] = $filters['job_type'];
    }

    if ($filters['qualification'] !== '') {
        $where[] = 'j.qualification_required LIKE ?';
        $params[] = '%' . $filters['qualification'] . '%';
    }

    if ($filters['category'] !== '') {
        $where[] = 'jc.slug = ?';
        $params[] = $filters['category'];
    }

    $joinCategory = $filters['category'] !== '' ? ' LEFT JOIN job_categories jc ON jc.id = j.category_id ' : '';
    $whereSql = implode(' AND ', $where);

    if ($countOnly) {
        return array(
            'sql' => "SELECT COUNT(*)
                      FROM jobs j
                      INNER JOIN employer_profiles ep ON ep.id = j.employer_id
                      {$joinCategory}
                      WHERE {$whereSql}",
            'params' => $params,
        );
    }

    $params[] = (int) $limit;
    $params[] = (int) $offset;

    return array(
        'sql' => "SELECT j.*, ep.company_name
                  FROM jobs j
                  INNER JOIN employer_profiles ep ON ep.id = j.employer_id
                  {$joinCategory}
                  WHERE {$whereSql}
                  ORDER BY COALESCE(j.posted_at, j.created_at) DESC
                  LIMIT ? OFFSET ?",
        'params' => $params,
    );
}

function fp_auth_redirect_for_role($role) {
    if ($role === 'admin') {
        return 'admin/dashboard.php';
    }
    if ($role === 'job_seeker') {
        return 'jobseeker/dashboard.php';
    }
    if ($role === 'employer') {
        return 'employer/dashboard.php';
    }

    return 'job-listings.php';
}

function fp_jobseeker_profile_id($userId) {
    $profile = fp_jobseeker_profile($userId);
    return $profile ? (int) $profile['id'] : 0;
}

function fp_format_application_status($status) {
    return ucwords(str_replace('_', ' ', (string) $status));
}

function fp_application_status_class($status) {
    $map = array(
        'applied' => 'status-applied',
        'reviewed' => 'status-reviewed',
        'shortlisted' => 'status-shortlisted',
        'hired' => 'status-hired',
        'rejected' => 'status-rejected',
        'withdrawn' => 'status-withdrawn',
    );
    return $map[$status] ?? 'status-applied';
}

function fp_count_seeker_applications($seekerProfileId) {
    if ($seekerProfileId <= 0) {
        return 0;
    }
    $statement = fp_db()->prepare('SELECT COUNT(*) FROM job_applications WHERE job_seeker_id = ?');
    $statement->execute(array((int) $seekerProfileId));
    return (int) $statement->fetchColumn();
}

function fp_fetch_seeker_applications($seekerProfileId, $limit = 20, $offset = 0) {
    if ($seekerProfileId <= 0) {
        return array();
    }
    $statement = fp_db()->prepare(
        "SELECT ja.*, j.title, j.location, j.job_type, ep.company_name
         FROM job_applications ja
         INNER JOIN jobs j ON j.id = ja.job_id
         INNER JOIN employer_profiles ep ON ep.id = j.employer_id
         WHERE ja.job_seeker_id = ?
         ORDER BY ja.applied_at DESC
         LIMIT ? OFFSET ?"
    );
    $statement->execute(array((int) $seekerProfileId, (int) $limit, (int) $offset));
    return $statement->fetchAll();
}

function fp_seeker_has_applied($seekerProfileId, $jobId) {
    if ($seekerProfileId <= 0 || $jobId <= 0) {
        return false;
    }
    $statement = fp_db()->prepare(
        'SELECT id FROM job_applications WHERE job_seeker_id = ? AND job_id = ? LIMIT 1'
    );
    $statement->execute(array((int) $seekerProfileId, (int) $jobId));
    return (bool) $statement->fetch();
}

function fp_apply_to_job($seekerProfileId, $jobId, $resumePath = null) {
    if ($seekerProfileId <= 0 || $jobId <= 0) {
        throw new RuntimeException('Invalid application request.');
    }

    $job = fp_fetch_job_by_id($jobId);
    if (!$job) {
        throw new RuntimeException('This job is no longer available.');
    }

    if (fp_seeker_has_applied($seekerProfileId, $jobId)) {
        throw new RuntimeException('You have already applied for this job.');
    }

    $statement = fp_db()->prepare(
        'INSERT INTO job_applications (job_id, job_seeker_id, resume_file_path, status)
         VALUES (?, ?, ?, ?)'
    );
    $statement->execute(array(
        (int) $jobId,
        (int) $seekerProfileId,
        $resumePath,
        'applied',
    ));

    return (int) fp_db()->lastInsertId();
}

function fp_update_jobseeker_profile($userId, array $data) {
    $experienceYears = max(0, (float) ($data['experience_years'] ?? 0));
    $profileLevel = (
        trim((string) ($data['skills'] ?? '')) !== ''
        || $experienceYears > 0
        || trim((string) ($data['qualification'] ?? '')) !== ''
    ) ? 'skilled' : 'basic';

    $statement = fp_db()->prepare(
        "UPDATE job_seeker_profiles
         SET headline = ?, skills = ?, experience_years = ?, qualification = ?,
             current_location = ?, preferred_location = ?, profile_level = ?
         WHERE user_id = ?"
    );
    $statement->execute(array(
        $data['headline'] !== '' ? $data['headline'] : null,
        $data['skills'] !== '' ? $data['skills'] : null,
        $experienceYears,
        $data['qualification'] !== '' ? $data['qualification'] : null,
        $data['current_location'] !== '' ? $data['current_location'] : null,
        $data['preferred_location'] !== '' ? $data['preferred_location'] : null,
        $profileLevel,
        (int) $userId,
    ));
}

function fp_update_jobseeker_user($userId, array $data) {
    $statement = fp_db()->prepare(
        'UPDATE users SET name = ?, phone = ? WHERE id = ? AND role = ?'
    );
    $statement->execute(array(
        $data['name'],
        $data['phone'] !== '' ? $data['phone'] : null,
        (int) $userId,
        'job_seeker',
    ));
}

function fp_lookup_user_by_email($email) {
    $statement = fp_db()->prepare('SELECT id, role, name, email, status FROM users WHERE email = ? LIMIT 1');
    $statement->execute(array($email));
    return $statement->fetch() ?: null;
}

function fp_save_contact_inquiry(array $data) {
    $statement = fp_db()->prepare(
        'INSERT INTO contact_inquiries
            (full_name, email, phone, company_name, profile_type, subject, message)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $statement->execute(array(
        $data['full_name'],
        $data['email'],
        $data['phone'] !== '' ? $data['phone'] : null,
        $data['company_name'] !== '' ? $data['company_name'] : null,
        $data['profile_type'],
        $data['subject'],
        $data['message'],
    ));
}

function fp_employer_profile($userId) {
    $statement = fp_db()->prepare('SELECT * FROM employer_profiles WHERE user_id = ? LIMIT 1');
    $statement->execute(array((int) $userId));
    return $statement->fetch() ?: null;
}

function fp_ensure_employer_profile($userId) {
    $profile = fp_employer_profile($userId);
    if ($profile) {
        return $profile;
    }

    $user = fp_current_user();
    fp_db()->prepare(
        'INSERT INTO employer_profiles (user_id, company_name, contact_person_name, access_level)
         VALUES (?, ?, ?, ?)'
    )->execute(array(
        (int) $userId,
        $user['name'] ?? 'Company',
        $user['name'] ?? 'Contact',
        'free',
    ));

    return fp_employer_profile($userId);
}

function fp_employer_profile_id($userId) {
    $profile = fp_employer_profile($userId);
    return $profile ? (int) $profile['id'] : 0;
}

function fp_get_admin_setting($key, $default = null) {
    static $cache = array();

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    $statement = fp_db()->prepare('SELECT setting_value FROM admin_settings WHERE setting_key = ? LIMIT 1');
    $statement->execute(array($key));
    $row = $statement->fetch();
    $cache[$key] = $row ? $row['setting_value'] : $default;

    return $cache[$key];
}

function fp_can_employer_view_resume(array $employerProfile) {
    if (($employerProfile['access_level'] ?? 'free') === 'paid') {
        return true;
    }

    return fp_get_admin_setting('free_employer_can_view_resume', '0') === '1';
}

function fp_log_resume_access($employerId, $seekerId, $action, $granted, $applicationId = null, $reason = null) {
    fp_db()->prepare(
        'INSERT INTO resume_access_logs
            (employer_id, job_seeker_id, application_id, action, access_granted, denial_reason)
         VALUES (?, ?, ?, ?, ?, ?)'
    )->execute(array(
        (int) $employerId,
        (int) $seekerId,
        $applicationId ? (int) $applicationId : null,
        $action,
        $granted ? 1 : 0,
        $reason,
    ));
}

function fp_slugify($text) {
    $text = strtolower(trim((string) $text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');

    return $text !== '' ? $text : 'job';
}

function fp_unique_job_slug($title, $excludeJobId = null) {
    $base = fp_slugify($title);
    $slug = $base;
    $suffix = 0;

    while (true) {
        $params = array($slug);
        $sql = 'SELECT id FROM jobs WHERE slug = ?';
        if ($excludeJobId) {
            $sql .= ' AND id != ?';
            $params[] = (int) $excludeJobId;
        }
        $sql .= ' LIMIT 1';

        $statement = fp_db()->prepare($sql);
        $statement->execute($params);
        if (!$statement->fetch()) {
            return $slug;
        }

        $suffix++;
        $slug = $base . '-' . $suffix;
    }
}

function fp_fetch_job_categories() {
    return fp_db()->query(
        "SELECT id, name, slug FROM job_categories WHERE status = 'active' ORDER BY name ASC"
    )->fetchAll();
}

function fp_count_employer_jobs($employerId, $status = null) {
    if ($employerId <= 0) {
        return 0;
    }

    $sql = "SELECT COUNT(*) FROM jobs WHERE employer_id = ? AND status != 'deleted'";
    $params = array((int) $employerId);

    if ($status !== null) {
        $sql .= ' AND status = ?';
        $params[] = $status;
    }

    $statement = fp_db()->prepare($sql);
    $statement->execute($params);

    return (int) $statement->fetchColumn();
}

function fp_fetch_employer_jobs($employerId, $status = null, $limit = 50, $offset = 0) {
    if ($employerId <= 0) {
        return array();
    }

    $sql = "SELECT j.*, jc.name AS category_name,
                   (SELECT COUNT(*) FROM job_applications ja WHERE ja.job_id = j.id) AS application_count
            FROM jobs j
            LEFT JOIN job_categories jc ON jc.id = j.category_id
            WHERE j.employer_id = ? AND j.status != 'deleted'";
    $params = array((int) $employerId);

    if ($status !== null) {
        $sql .= ' AND j.status = ?';
        $params[] = $status;
    }

    $sql .= ' ORDER BY COALESCE(j.posted_at, j.created_at) DESC LIMIT ? OFFSET ?';
    $params[] = (int) $limit;
    $params[] = (int) $offset;

    $statement = fp_db()->prepare($sql);
    $statement->execute($params);

    return $statement->fetchAll();
}

function fp_fetch_employer_job($jobId, $employerId) {
    $statement = fp_db()->prepare(
        "SELECT j.*, jc.name AS category_name
         FROM jobs j
         LEFT JOIN job_categories jc ON jc.id = j.category_id
         WHERE j.id = ? AND j.employer_id = ? AND j.status != 'deleted'
         LIMIT 1"
    );
    $statement->execute(array((int) $jobId, (int) $employerId));

    return $statement->fetch() ?: null;
}

function fp_validate_job_form(array $data) {
    $errors = array();

    if (trim((string) ($data['title'] ?? '')) === '') {
        $errors[] = 'Job title is required.';
    }
    if (trim((string) ($data['description'] ?? '')) === '') {
        $errors[] = 'Job description is required.';
    }
    if (trim((string) ($data['location'] ?? '')) === '') {
        $errors[] = 'Location is required.';
    }

    $allowedTypes = array('full_time', 'part_time', 'contract', 'internship', 'temporary');
    if (!in_array($data['job_type'] ?? '', $allowedTypes, true)) {
        $errors[] = 'Choose a valid job type.';
    }

    $allowedWorkplace = array('onsite', 'remote', 'hybrid');
    if (!in_array($data['workplace_type'] ?? '', $allowedWorkplace, true)) {
        $errors[] = 'Choose a valid workplace type.';
    }

    $allowedStatus = array('draft', 'open', 'closed');
    if (!in_array($data['status'] ?? '', $allowedStatus, true)) {
        $errors[] = 'Choose a valid job status.';
    }

    return $errors;
}

function fp_save_job($employerId, $userId, array $data, $jobId = null) {
    $errors = fp_validate_job_form($data);
    if (!empty($errors)) {
        throw new RuntimeException(implode(' ', $errors));
    }

    $title = trim((string) $data['title']);
    $slug = fp_unique_job_slug($title, $jobId);
    $status = $data['status'];
    $categoryId = (int) ($data['category_id'] ?? 0);
    $categoryId = $categoryId > 0 ? $categoryId : null;
    $experienceMin = max(0, (float) ($data['experience_min_years'] ?? 0));
    $experienceMax = ($data['experience_max_years'] ?? '') !== ''
        ? max($experienceMin, (float) $data['experience_max_years'])
        : null;
    $salaryMin = ($data['salary_min'] ?? '') !== '' ? (float) $data['salary_min'] : null;
    $salaryMax = ($data['salary_max'] ?? '') !== '' ? (float) $data['salary_max'] : null;
    $openings = max(1, (int) ($data['openings'] ?? 1));
    $deadline = trim((string) ($data['application_deadline'] ?? ''));
    $deadline = $deadline !== '' ? $deadline : null;

    $fields = array(
        'category_id' => $categoryId,
        'title' => $title,
        'slug' => $slug,
        'short_description' => trim((string) ($data['short_description'] ?? '')) ?: null,
        'description' => trim((string) $data['description']),
        'responsibilities' => trim((string) ($data['responsibilities'] ?? '')) ?: null,
        'requirements' => trim((string) ($data['requirements'] ?? '')) ?: null,
        'skills_required' => trim((string) ($data['skills_required'] ?? '')) ?: null,
        'qualification_required' => trim((string) ($data['qualification_required'] ?? '')) ?: null,
        'experience_min_years' => $experienceMin,
        'experience_max_years' => $experienceMax,
        'location' => trim((string) $data['location']),
        'job_type' => $data['job_type'],
        'workplace_type' => $data['workplace_type'],
        'salary_min' => $salaryMin,
        'salary_max' => $salaryMax,
        'salary_currency' => 'INR',
        'openings' => $openings,
        'application_deadline' => $deadline,
        'status' => $status,
    );

    if ($jobId) {
        $existing = fp_fetch_employer_job($jobId, $employerId);
        if (!$existing) {
            throw new RuntimeException('Job not found.');
        }

        if ($status === 'open' && empty($existing['posted_at'])) {
            $fields['posted_at'] = date('Y-m-d H:i:s');
        }

        $statement = fp_db()->prepare(
            "UPDATE jobs SET
                category_id = ?, title = ?, slug = ?, short_description = ?, description = ?,
                responsibilities = ?, requirements = ?, skills_required = ?, qualification_required = ?,
                experience_min_years = ?, experience_max_years = ?, location = ?, job_type = ?,
                workplace_type = ?, salary_min = ?, salary_max = ?, salary_currency = ?,
                openings = ?, application_deadline = ?, status = ?" .
                (isset($fields['posted_at']) ? ', posted_at = ?' : '') . "
             WHERE id = ? AND employer_id = ?"
        );

        $params = array_values($fields);
        if (isset($fields['posted_at'])) {
            $params[] = $fields['posted_at'];
        }
        $params[] = (int) $jobId;
        $params[] = (int) $employerId;
        $statement->execute($params);

        return (int) $jobId;
    }

    $postedAt = $status === 'open' ? date('Y-m-d H:i:s') : null;
    $statement = fp_db()->prepare(
        "INSERT INTO jobs (
            employer_id, category_id, created_by_user_id, title, slug, short_description, description,
            responsibilities, requirements, skills_required, qualification_required,
            experience_min_years, experience_max_years, location, job_type, workplace_type,
            salary_min, salary_max, salary_currency, openings, application_deadline, status, posted_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $statement->execute(array(
        (int) $employerId,
        $categoryId,
        (int) $userId,
        $fields['title'],
        $fields['slug'],
        $fields['short_description'],
        $fields['description'],
        $fields['responsibilities'],
        $fields['requirements'],
        $fields['skills_required'],
        $fields['qualification_required'],
        $fields['experience_min_years'],
        $fields['experience_max_years'],
        $fields['location'],
        $fields['job_type'],
        $fields['workplace_type'],
        $fields['salary_min'],
        $fields['salary_max'],
        $fields['salary_currency'],
        $fields['openings'],
        $fields['application_deadline'],
        $fields['status'],
        $postedAt,
    ));

    return (int) fp_db()->lastInsertId();
}

function fp_close_employer_job($jobId, $employerId) {
    $statement = fp_db()->prepare(
        "UPDATE jobs SET status = 'closed' WHERE id = ? AND employer_id = ? AND status != 'deleted'"
    );
    $statement->execute(array((int) $jobId, (int) $employerId));

    return $statement->rowCount() > 0;
}

function fp_delete_employer_job($jobId, $employerId, $userId) {
    $statement = fp_db()->prepare(
        "UPDATE jobs SET status = 'deleted', deleted_at = NOW(), deleted_by_user_id = ?
         WHERE id = ? AND employer_id = ? AND status != 'deleted'"
    );
    $statement->execute(array((int) $userId, (int) $jobId, (int) $employerId));

    return $statement->rowCount() > 0;
}

function fp_reopen_employer_job($jobId, $employerId) {
    $statement = fp_db()->prepare(
        "UPDATE jobs SET status = 'open', posted_at = COALESCE(posted_at, NOW())
         WHERE id = ? AND employer_id = ? AND status = 'closed'"
    );
    $statement->execute(array((int) $jobId, (int) $employerId));

    return $statement->rowCount() > 0;
}

function fp_count_employer_applications($employerId, $status = null) {
    if ($employerId <= 0) {
        return 0;
    }

    $sql = "SELECT COUNT(*)
            FROM job_applications ja
            INNER JOIN jobs j ON j.id = ja.job_id
            WHERE j.employer_id = ? AND j.status != 'deleted'";
    $params = array((int) $employerId);

    if ($status !== null) {
        $sql .= ' AND ja.status = ?';
        $params[] = $status;
    }

    $statement = fp_db()->prepare($sql);
    $statement->execute($params);

    return (int) $statement->fetchColumn();
}

function fp_fetch_employer_applications($employerId, $jobId = null, $status = null, $limit = 50, $offset = 0) {
    if ($employerId <= 0) {
        return array();
    }

    $sql = "SELECT ja.*, j.title AS job_title, j.location AS job_location,
                   u.name AS seeker_name, u.email AS seeker_email, u.phone AS seeker_phone,
                   jsp.headline, jsp.skills, jsp.experience_years, jsp.qualification,
                   jsp.current_location, jsp.profile_level
            FROM job_applications ja
            INNER JOIN jobs j ON j.id = ja.job_id
            INNER JOIN job_seeker_profiles jsp ON jsp.id = ja.job_seeker_id
            INNER JOIN users u ON u.id = jsp.user_id
            WHERE j.employer_id = ? AND j.status != 'deleted'";
    $params = array((int) $employerId);

    if ($jobId) {
        $sql .= ' AND ja.job_id = ?';
        $params[] = (int) $jobId;
    }
    if ($status !== null && $status !== '') {
        $sql .= ' AND ja.status = ?';
        $params[] = $status;
    }

    $sql .= ' ORDER BY ja.applied_at DESC LIMIT ? OFFSET ?';
    $params[] = (int) $limit;
    $params[] = (int) $offset;

    $statement = fp_db()->prepare($sql);
    $statement->execute($params);

    return $statement->fetchAll();
}

function fp_fetch_employer_application($applicationId, $employerId) {
    $statement = fp_db()->prepare(
        "SELECT ja.*, j.title AS job_title, j.location AS job_location, j.id AS job_id,
                u.name AS seeker_name, u.email AS seeker_email, u.phone AS seeker_phone,
                jsp.headline, jsp.skills, jsp.experience_years, jsp.qualification,
                jsp.current_location, jsp.preferred_location, jsp.profile_level,
                jsp.resume_file_path AS seeker_resume_path, jsp.resume_original_name
         FROM job_applications ja
         INNER JOIN jobs j ON j.id = ja.job_id
         INNER JOIN job_seeker_profiles jsp ON jsp.id = ja.job_seeker_id
         INNER JOIN users u ON u.id = jsp.user_id
         WHERE ja.id = ? AND j.employer_id = ?
         LIMIT 1"
    );
    $statement->execute(array((int) $applicationId, (int) $employerId));

    return $statement->fetch() ?: null;
}

function fp_update_application_status($applicationId, $employerId, $status, $note = null) {
    $allowed = array('applied', 'reviewed', 'shortlisted', 'rejected', 'hired', 'withdrawn');
    if (!in_array($status, $allowed, true)) {
        throw new RuntimeException('Invalid application status.');
    }

    $application = fp_fetch_employer_application($applicationId, $employerId);
    if (!$application) {
        throw new RuntimeException('Application not found.');
    }

    $statement = fp_db()->prepare(
        'UPDATE job_applications SET status = ?, employer_note = ? WHERE id = ?'
    );
    $statement->execute(array(
        $status,
        $note !== null ? $note : ($application['employer_note'] ?? null),
        (int) $applicationId,
    ));
}

function fp_update_employer_profile($userId, array $data) {
    $statement = fp_db()->prepare(
        "UPDATE employer_profiles SET
            company_name = ?, company_website = ?, industry = ?, company_size = ?,
            contact_person_name = ?, contact_designation = ?,
            address_line = ?, city = ?, state = ?, country = ?
         WHERE user_id = ?"
    );
    $statement->execute(array(
        $data['company_name'],
        $data['company_website'] !== '' ? $data['company_website'] : null,
        $data['industry'] !== '' ? $data['industry'] : null,
        $data['company_size'] !== '' ? $data['company_size'] : null,
        $data['contact_person_name'] !== '' ? $data['contact_person_name'] : null,
        $data['contact_designation'] !== '' ? $data['contact_designation'] : null,
        $data['address_line'] !== '' ? $data['address_line'] : null,
        $data['city'] !== '' ? $data['city'] : null,
        $data['state'] !== '' ? $data['state'] : null,
        $data['country'] !== '' ? $data['country'] : 'India',
        (int) $userId,
    ));
}

function fp_update_employer_user($userId, array $data) {
    $statement = fp_db()->prepare(
        'UPDATE users SET name = ?, phone = ? WHERE id = ? AND role = ?'
    );
    $statement->execute(array(
        $data['name'],
        $data['phone'] !== '' ? $data['phone'] : null,
        (int) $userId,
        'employer',
    ));
}

function fp_fetch_candidate_profile($seekerProfileId) {
    $statement = fp_db()->prepare(
        "SELECT jsp.*, u.name, u.email, u.phone
         FROM job_seeker_profiles jsp
         INNER JOIN users u ON u.id = jsp.user_id
         WHERE jsp.id = ? AND u.status = 'active'
         LIMIT 1"
    );
    $statement->execute(array((int) $seekerProfileId));

    return $statement->fetch() ?: null;
}

function fp_build_candidate_filters(array $input) {
    return array(
        'skills' => trim((string) ($input['skills'] ?? '')),
        'location' => trim((string) ($input['location'] ?? '')),
        'qualification' => trim((string) ($input['qualification'] ?? '')),
        'experience_min' => ($input['experience_min'] ?? '') !== '' ? (float) $input['experience_min'] : null,
    );
}

function fp_candidate_search_query(array $filters, $countOnly = false, $limit = 20, $offset = 0) {
    $where = array("u.status = 'active'", "u.role = 'job_seeker'");
    $params = array();

    if ($filters['skills'] !== '') {
        $where[] = 'jsp.skills LIKE ?';
        $params[] = '%' . $filters['skills'] . '%';
    }
    if ($filters['location'] !== '') {
        $where[] = '(jsp.current_location LIKE ? OR jsp.preferred_location LIKE ?)';
        $params[] = '%' . $filters['location'] . '%';
        $params[] = '%' . $filters['location'] . '%';
    }
    if ($filters['qualification'] !== '') {
        $where[] = 'jsp.qualification LIKE ?';
        $params[] = '%' . $filters['qualification'] . '%';
    }
    if ($filters['experience_min'] !== null) {
        $where[] = 'jsp.experience_years >= ?';
        $params[] = $filters['experience_min'];
    }

    $whereSql = implode(' AND ', $where);

    if ($countOnly) {
        return array(
            'sql' => "SELECT COUNT(*)
                      FROM job_seeker_profiles jsp
                      INNER JOIN users u ON u.id = jsp.user_id
                      WHERE {$whereSql}",
            'params' => $params,
        );
    }

    $params[] = (int) $limit;
    $params[] = (int) $offset;

    return array(
        'sql' => "SELECT jsp.*, u.name, u.email, u.phone
                  FROM job_seeker_profiles jsp
                  INNER JOIN users u ON u.id = jsp.user_id
                  WHERE {$whereSql}
                  ORDER BY jsp.experience_years DESC, u.name ASC
                  LIMIT ? OFFSET ?",
        'params' => $params,
    );
}

function fp_count_candidates(array $filters) {
    $query = fp_candidate_search_query($filters, true);
    $statement = fp_db()->prepare($query['sql']);
    $statement->execute($query['params']);

    return (int) $statement->fetchColumn();
}

function fp_search_candidates(array $filters, $limit = 20, $offset = 0) {
    $query = fp_candidate_search_query($filters, false, $limit, $offset);
    $statement = fp_db()->prepare($query['sql']);
    $statement->execute($query['params']);

    return $statement->fetchAll();
}

function fp_job_status_badge_class($status) {
    $map = array(
        'draft' => 'status-reviewed',
        'open' => 'status-shortlisted',
        'closed' => 'status-rejected',
    );

    return $map[$status] ?? 'status-applied';
}

function fp_format_job_status($status) {
    return ucwords(str_replace('_', ' ', (string) $status));
}

function fp_sanitize_return_url($url) {
    $url = trim((string) $url);
    if ($url === '') {
        return '';
    }

    if (preg_match('#^https?://#i', $url)) {
        return '';
    }

    $query = '';
    if (strpos($url, '?') !== false) {
        list($pathPart, $queryPart) = explode('?', $url, 2);
        $url = $pathPart;
        $query = $queryPart;
    }

    $path = $url;
    if ($path !== '' && $path[0] !== '/') {
        $path = '/' . ltrim($path, '/');
    }

    $base = fp_app_base_path();
    if ($base !== '' && $base !== '/' && strpos($path, $base) === 0) {
        $path = substr($path, strlen($base));
        if ($path === '') {
            $path = '/';
        }
    }

    $path = '/' . trim($path, '/');
    if ($path === '/' || $path === '/index.php') {
        return '';
    }

    $safePath = ltrim($path, '/');
    if (strpos($safePath, '..') !== false) {
        return '';
    }

    return $query !== '' ? $safePath . '?' . $query : $safePath;
}

function fp_admin_dashboard_stats() {
    $pdo = fp_db();

    return array(
        'users' => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role IN ('job_seeker', 'employer') AND status != 'deleted'")->fetchColumn(),
        'job_seekers' => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'job_seeker' AND status != 'deleted'")->fetchColumn(),
        'employers' => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'employer' AND status != 'deleted'")->fetchColumn(),
        'blocked_users' => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role IN ('job_seeker', 'employer') AND status = 'blocked'")->fetchColumn(),
        'open_jobs' => (int) $pdo->query("SELECT COUNT(*) FROM jobs WHERE status = 'open'")->fetchColumn(),
        'total_jobs' => (int) $pdo->query("SELECT COUNT(*) FROM jobs WHERE status != 'deleted'")->fetchColumn(),
        'applications' => (int) $pdo->query('SELECT COUNT(*) FROM job_applications')->fetchColumn(),
    );
}

function fp_admin_build_user_filters(array $input) {
    $role = trim((string) ($input['role'] ?? ''));
    $status = trim((string) ($input['status'] ?? ''));
    $q = trim((string) ($input['q'] ?? ''));

    if (!in_array($role, array('job_seeker', 'employer'), true)) {
        $role = '';
    }

    if (!in_array($status, array('active', 'blocked'), true)) {
        $status = '';
    }

    return array(
        'role' => $role,
        'status' => $status,
        'q' => $q,
    );
}

function fp_admin_user_query(array $filters, $countOnly = false, $limit = 25, $offset = 0) {
    $where = array("u.role IN ('job_seeker', 'employer')", "u.status != 'deleted'");
    $params = array();

    if ($filters['role'] !== '') {
        $where[] = 'u.role = ?';
        $params[] = $filters['role'];
    }

    if ($filters['status'] !== '') {
        $where[] = 'u.status = ?';
        $params[] = $filters['status'];
    }

    if ($filters['q'] !== '') {
        $where[] = '(u.name LIKE ? OR u.email LIKE ?)';
        $like = '%' . $filters['q'] . '%';
        $params[] = $like;
        $params[] = $like;
    }

    $whereSql = implode(' AND ', $where);

    if ($countOnly) {
        $statement = fp_db()->prepare("SELECT COUNT(*) FROM users u WHERE {$whereSql}");
        $statement->execute($params);

        return (int) $statement->fetchColumn();
    }

    $params[] = (int) $limit;
    $params[] = (int) $offset;

    $statement = fp_db()->prepare(
        "SELECT u.*, ep.company_name, ep.access_level, jsp.profile_level, jsp.current_location
         FROM users u
         LEFT JOIN employer_profiles ep ON ep.user_id = u.id AND u.role = 'employer'
         LEFT JOIN job_seeker_profiles jsp ON jsp.user_id = u.id AND u.role = 'job_seeker'
         WHERE {$whereSql}
         ORDER BY u.created_at DESC
         LIMIT ? OFFSET ?"
    );
    $statement->execute($params);

    return $statement->fetchAll();
}

function fp_admin_count_users(array $filters) {
    return fp_admin_user_query($filters, true);
}

function fp_admin_fetch_users(array $filters, $limit = 25, $offset = 0) {
    return fp_admin_user_query($filters, false, $limit, $offset);
}

function fp_admin_fetch_user($userId) {
    $statement = fp_db()->prepare(
        "SELECT u.*, ep.company_name, ep.access_level, ep.id AS employer_profile_id,
                jsp.profile_level, jsp.current_location, jsp.id AS seeker_profile_id
         FROM users u
         LEFT JOIN employer_profiles ep ON ep.user_id = u.id AND u.role = 'employer'
         LEFT JOIN job_seeker_profiles jsp ON jsp.user_id = u.id AND u.role = 'job_seeker'
         WHERE u.id = ? AND u.role IN ('job_seeker', 'employer')
         LIMIT 1"
    );
    $statement->execute(array((int) $userId));

    return $statement->fetch() ?: null;
}

function fp_admin_block_user($userId, $adminId, $reason = null) {
    $user = fp_admin_fetch_user($userId);
    if (!$user) {
        throw new RuntimeException('User not found.');
    }

    if ((int) $userId === (int) $adminId) {
        throw new RuntimeException('You cannot block your own account.');
    }

    if ($user['status'] === 'blocked') {
        return false;
    }

    $statement = fp_db()->prepare(
        "UPDATE users
         SET status = 'blocked', blocked_reason = ?, blocked_at = NOW(), blocked_by_user_id = ?
         WHERE id = ? AND role IN ('job_seeker', 'employer')"
    );
    $statement->execute(array(
        $reason !== null && trim($reason) !== '' ? trim($reason) : null,
        (int) $adminId,
        (int) $userId,
    ));

    return $statement->rowCount() > 0;
}

function fp_admin_unblock_user($userId) {
    $user = fp_admin_fetch_user($userId);
    if (!$user) {
        throw new RuntimeException('User not found.');
    }

    if ($user['status'] !== 'blocked') {
        return false;
    }

    $statement = fp_db()->prepare(
        "UPDATE users
         SET status = 'active', blocked_reason = NULL, blocked_at = NULL, blocked_by_user_id = NULL
         WHERE id = ? AND role IN ('job_seeker', 'employer')"
    );
    $statement->execute(array((int) $userId));

    return $statement->rowCount() > 0;
}

function fp_admin_create_employer(array $data) {
    $name = trim((string) ($data['name'] ?? ''));
    $email = trim((string) ($data['email'] ?? ''));
    $password = (string) ($data['password'] ?? '');
    $companyName = trim((string) ($data['company_name'] ?? ''));
    $phone = trim((string) ($data['phone'] ?? ''));
    $accessLevel = trim((string) ($data['access_level'] ?? 'free'));

    if ($name === '') {
        throw new RuntimeException('Contact name is required.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('A valid email address is required.');
    }

    if (strlen($password) < 8) {
        throw new RuntimeException('Password must be at least 8 characters.');
    }

    if ($companyName === '') {
        throw new RuntimeException('Company name is required.');
    }

    if (!in_array($accessLevel, array('free', 'paid'), true)) {
        $accessLevel = 'free';
    }

    if (fp_lookup_user_by_email($email)) {
        throw new RuntimeException('An account already exists with this email.');
    }

    $pdo = fp_db();
    $pdo->beginTransaction();

    try {
        $pdo->prepare(
            "INSERT INTO users (role, name, email, phone, password_hash, status)
             VALUES ('employer', ?, ?, ?, ?, 'active')"
        )->execute(array(
            $name,
            $email,
            $phone !== '' ? $phone : null,
            password_hash($password, PASSWORD_DEFAULT),
        ));

        $userId = (int) $pdo->lastInsertId();

        $pdo->prepare(
            'INSERT INTO employer_profiles (user_id, company_name, contact_person_name, access_level)
             VALUES (?, ?, ?, ?)'
        )->execute(array($userId, $companyName, $name, $accessLevel));

        $pdo->commit();

        return $userId;
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $exception;
    }
}

function fp_admin_update_employer_access($userId, $accessLevel) {
    if (!in_array($accessLevel, array('free', 'paid'), true)) {
        throw new RuntimeException('Invalid access level.');
    }

    $user = fp_admin_fetch_user($userId);
    if (!$user || $user['role'] !== 'employer') {
        throw new RuntimeException('Employer not found.');
    }

    $statement = fp_db()->prepare(
        'UPDATE employer_profiles SET access_level = ? WHERE user_id = ?'
    );
    $statement->execute(array($accessLevel, (int) $userId));

    return $statement->rowCount() > 0;
}

function fp_admin_email_taken($email, $excludeUserId = 0) {
    $statement = fp_db()->prepare('SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1');
    $statement->execute(array(trim($email), (int) $excludeUserId));

    return (bool) $statement->fetch();
}

function fp_admin_fetch_jobseeker($userId) {
    $statement = fp_db()->prepare(
        "SELECT u.*, jsp.*
         FROM users u
         INNER JOIN job_seeker_profiles jsp ON jsp.user_id = u.id
         WHERE u.id = ? AND u.role = 'job_seeker' AND u.status != 'deleted'
         LIMIT 1"
    );
    $statement->execute(array((int) $userId));

    return $statement->fetch() ?: null;
}

function fp_admin_fetch_employer($userId) {
    $statement = fp_db()->prepare(
        "SELECT u.*, ep.*
         FROM users u
         INNER JOIN employer_profiles ep ON ep.user_id = u.id
         WHERE u.id = ? AND u.role = 'employer' AND u.status != 'deleted'
         LIMIT 1"
    );
    $statement->execute(array((int) $userId));

    return $statement->fetch() ?: null;
}

function fp_admin_validate_account_status($status) {
    if (!in_array($status, array('active', 'blocked'), true)) {
        throw new RuntimeException('Invalid account status.');
    }

    return $status;
}

function fp_admin_update_user_password($userId, $password) {
    if (strlen($password) < 8) {
        throw new RuntimeException('Password must be at least 8 characters.');
    }

    $statement = fp_db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
    $statement->execute(array(password_hash($password, PASSWORD_DEFAULT), (int) $userId));

    return $statement->rowCount() > 0;
}

function fp_admin_update_user_account($userId, array $data, $role) {
    $name = trim((string) ($data['name'] ?? ''));
    $email = trim((string) ($data['email'] ?? ''));
    $phone = trim((string) ($data['phone'] ?? ''));
    $status = fp_admin_validate_account_status(trim((string) ($data['status'] ?? 'active')));

    if ($name === '') {
        throw new RuntimeException('Name is required.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('A valid email address is required.');
    }

    if (fp_admin_email_taken($email, $userId)) {
        throw new RuntimeException('Another account already uses this email.');
    }

    $blockedReason = null;
    $blockedAt = null;
    $blockedBy = null;

    if ($status === 'blocked') {
        $blockedReason = trim((string) ($data['blocked_reason'] ?? ''));
        $blockedReason = $blockedReason !== '' ? $blockedReason : null;
        $blockedAt = date('Y-m-d H:i:s');
        $blockedBy = isset($data['blocked_by_user_id']) ? (int) $data['blocked_by_user_id'] : null;
    }

    $statement = fp_db()->prepare(
        "UPDATE users
         SET name = ?, email = ?, phone = ?, status = ?,
             blocked_reason = ?, blocked_at = ?, blocked_by_user_id = ?
         WHERE id = ? AND role = ?"
    );
    $statement->execute(array(
        $name,
        $email,
        $phone !== '' ? $phone : null,
        $status,
        $blockedReason,
        $blockedAt,
        $blockedBy,
        (int) $userId,
        $role,
    ));

    if (!$statement->rowCount()) {
        $check = fp_db()->prepare('SELECT id FROM users WHERE id = ? AND role = ? LIMIT 1');
        $check->execute(array((int) $userId, $role));
        if (!$check->fetch()) {
            throw new RuntimeException('Unable to update account.');
        }
    }
}

function fp_admin_create_jobseeker(array $data) {
    $name = trim((string) ($data['name'] ?? ''));
    $email = trim((string) ($data['email'] ?? ''));
    $password = (string) ($data['password'] ?? '');
    $phone = trim((string) ($data['phone'] ?? ''));

    if ($name === '') {
        throw new RuntimeException('Name is required.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('A valid email address is required.');
    }

    if (strlen($password) < 8) {
        throw new RuntimeException('Password must be at least 8 characters.');
    }

    if (fp_admin_email_taken($email)) {
        throw new RuntimeException('An account already exists with this email.');
    }

    $experienceYears = max(0, (float) ($data['experience_years'] ?? 0));
    $profileLevel = trim((string) ($data['profile_level'] ?? ''));
    if (!in_array($profileLevel, array('basic', 'skilled'), true)) {
        $profileLevel = (
            trim((string) ($data['skills'] ?? '')) !== ''
            || $experienceYears > 0
            || trim((string) ($data['qualification'] ?? '')) !== ''
        ) ? 'skilled' : 'basic';
    }

    $pdo = fp_db();
    $pdo->beginTransaction();

    try {
        $pdo->prepare(
            "INSERT INTO users (role, name, email, phone, password_hash, status)
             VALUES ('job_seeker', ?, ?, ?, ?, 'active')"
        )->execute(array(
            $name,
            $email,
            $phone !== '' ? $phone : null,
            password_hash($password, PASSWORD_DEFAULT),
        ));

        $userId = (int) $pdo->lastInsertId();

        $pdo->prepare(
            "INSERT INTO job_seeker_profiles
                (user_id, headline, skills, experience_years, qualification, current_location, preferred_location, profile_level)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute(array(
            $userId,
            trim((string) ($data['headline'] ?? '')) ?: null,
            trim((string) ($data['skills'] ?? '')) ?: null,
            $experienceYears,
            trim((string) ($data['qualification'] ?? '')) ?: null,
            trim((string) ($data['current_location'] ?? '')) ?: null,
            trim((string) ($data['preferred_location'] ?? '')) ?: null,
            $profileLevel,
        ));

        $pdo->commit();

        return $userId;
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $exception;
    }
}

function fp_admin_update_jobseeker($userId, array $data, $adminId) {
    $record = fp_admin_fetch_jobseeker($userId);
    if (!$record) {
        throw new RuntimeException('Job seeker not found.');
    }

    $accountData = array(
        'name' => $data['name'] ?? '',
        'email' => $data['email'] ?? '',
        'phone' => $data['phone'] ?? '',
        'status' => $data['status'] ?? 'active',
        'blocked_reason' => $data['blocked_reason'] ?? '',
        'blocked_by_user_id' => ($data['status'] ?? 'active') === 'blocked' ? $adminId : null,
    );
    fp_admin_update_user_account($userId, $accountData, 'job_seeker');

    $profileData = array(
        'headline' => $data['headline'] ?? '',
        'skills' => $data['skills'] ?? '',
        'experience_years' => $data['experience_years'] ?? '0',
        'qualification' => $data['qualification'] ?? '',
        'current_location' => $data['current_location'] ?? '',
        'preferred_location' => $data['preferred_location'] ?? '',
    );
    fp_update_jobseeker_profile($userId, $profileData);

    $profileLevel = trim((string) ($data['profile_level'] ?? ''));
    if (in_array($profileLevel, array('basic', 'skilled'), true)) {
        fp_db()->prepare('UPDATE job_seeker_profiles SET profile_level = ? WHERE user_id = ?')
            ->execute(array($profileLevel, (int) $userId));
    }

    $password = (string) ($data['password'] ?? '');
    if ($password !== '') {
        fp_admin_update_user_password($userId, $password);
    }

    return true;
}

function fp_admin_update_employer($userId, array $data, $adminId) {
    $record = fp_admin_fetch_employer($userId);
    if (!$record) {
        throw new RuntimeException('Employer not found.');
    }

    if (trim((string) ($data['company_name'] ?? '')) === '') {
        throw new RuntimeException('Company name is required.');
    }

    $accountData = array(
        'name' => $data['name'] ?? '',
        'email' => $data['email'] ?? '',
        'phone' => $data['phone'] ?? '',
        'status' => $data['status'] ?? 'active',
        'blocked_reason' => $data['blocked_reason'] ?? '',
        'blocked_by_user_id' => ($data['status'] ?? 'active') === 'blocked' ? $adminId : null,
    );
    fp_admin_update_user_account($userId, $accountData, 'employer');

    fp_update_employer_user($userId, $accountData);
    fp_update_employer_profile($userId, array(
        'company_name' => $data['company_name'] ?? '',
        'company_website' => $data['company_website'] ?? '',
        'industry' => $data['industry'] ?? '',
        'company_size' => $data['company_size'] ?? '',
        'contact_person_name' => $data['contact_person_name'] ?? '',
        'contact_designation' => $data['contact_designation'] ?? '',
        'address_line' => $data['address_line'] ?? '',
        'city' => $data['city'] ?? '',
        'state' => $data['state'] ?? '',
        'country' => $data['country'] ?? 'India',
    ));

    $accessLevel = trim((string) ($data['access_level'] ?? 'free'));
    fp_admin_update_employer_access($userId, $accessLevel);

    $isVerified = !empty($data['is_verified']) ? 1 : 0;
    fp_db()->prepare('UPDATE employer_profiles SET is_verified = ? WHERE user_id = ?')
        ->execute(array($isVerified, (int) $userId));

    $password = (string) ($data['password'] ?? '');
    if ($password !== '') {
        fp_admin_update_user_password($userId, $password);
    }

    return true;
}

function fp_admin_delete_user($userId, $adminId) {
    $user = fp_admin_fetch_user($userId);
    if (!$user) {
        throw new RuntimeException('User not found.');
    }

    if ($user['status'] === 'deleted') {
        return false;
    }

    $statement = fp_db()->prepare(
        "UPDATE users SET status = 'deleted', blocked_reason = NULL, blocked_at = NULL, blocked_by_user_id = NULL
         WHERE id = ? AND role IN ('job_seeker', 'employer')"
    );
    $statement->execute(array((int) $userId));

    return $statement->rowCount() > 0;
}

function fp_admin_build_job_filters(array $input) {
    $status = trim((string) ($input['status'] ?? ''));
    $q = trim((string) ($input['q'] ?? ''));
    $employerId = (int) ($input['employer_id'] ?? 0);

    if (!in_array($status, array('draft', 'open', 'closed'), true)) {
        $status = '';
    }

    return array(
        'status' => $status,
        'q' => $q,
        'employer_id' => $employerId > 0 ? $employerId : 0,
    );
}

function fp_admin_job_query(array $filters, $countOnly = false, $limit = 25, $offset = 0) {
    $where = array("j.status != 'deleted'");
    $params = array();

    if ($filters['status'] !== '') {
        $where[] = 'j.status = ?';
        $params[] = $filters['status'];
    }

    if ($filters['employer_id'] > 0) {
        $where[] = 'j.employer_id = ?';
        $params[] = $filters['employer_id'];
    }

    if ($filters['q'] !== '') {
        $where[] = '(j.title LIKE ? OR j.location LIKE ? OR ep.company_name LIKE ?)';
        $like = '%' . $filters['q'] . '%';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    $whereSql = implode(' AND ', $where);
    $join = 'INNER JOIN employer_profiles ep ON ep.id = j.employer_id';

    if ($countOnly) {
        $statement = fp_db()->prepare("SELECT COUNT(*) FROM jobs j {$join} WHERE {$whereSql}");
        $statement->execute($params);

        return (int) $statement->fetchColumn();
    }

    $params[] = (int) $limit;
    $params[] = (int) $offset;

    $statement = fp_db()->prepare(
        "SELECT j.*, ep.company_name,
                (SELECT COUNT(*) FROM job_applications ja WHERE ja.job_id = j.id) AS application_count
         FROM jobs j
         {$join}
         WHERE {$whereSql}
         ORDER BY j.posted_at DESC, j.created_at DESC
         LIMIT ? OFFSET ?"
    );
    $statement->execute($params);

    return $statement->fetchAll();
}

function fp_admin_count_jobs(array $filters) {
    return fp_admin_job_query($filters, true);
}

function fp_admin_fetch_jobs(array $filters, $limit = 25, $offset = 0) {
    return fp_admin_job_query($filters, false, $limit, $offset);
}

function fp_admin_fetch_job($jobId) {
    $statement = fp_db()->prepare(
        "SELECT j.*, ep.company_name, ep.user_id AS employer_user_id
         FROM jobs j
         INNER JOIN employer_profiles ep ON ep.id = j.employer_id
         WHERE j.id = ? AND j.status != 'deleted'
         LIMIT 1"
    );
    $statement->execute(array((int) $jobId));

    return $statement->fetch() ?: null;
}

function fp_admin_delete_job($jobId, $adminId) {
    $statement = fp_db()->prepare(
        "UPDATE jobs SET status = 'deleted', deleted_at = NOW(), deleted_by_user_id = ?
         WHERE id = ? AND status != 'deleted'"
    );
    $statement->execute(array((int) $adminId, (int) $jobId));

    return $statement->rowCount() > 0;
}

function fp_admin_fetch_employers_for_select() {
    $statement = fp_db()->query(
        "SELECT ep.id, ep.company_name, u.name AS contact_name, u.email, ep.access_level
         FROM employer_profiles ep
         INNER JOIN users u ON u.id = ep.user_id
         WHERE u.status = 'active'
         ORDER BY ep.company_name ASC"
    );

    return $statement->fetchAll();
}

function fp_admin_fetch_all_settings() {
    $statement = fp_db()->query('SELECT setting_key, setting_value, value_type FROM admin_settings ORDER BY setting_key ASC');
    $rows = $statement->fetchAll();
    $settings = array();

    foreach ($rows as $row) {
        $settings[$row['setting_key']] = $row;
    }

    return $settings;
}

function fp_admin_update_setting($key, $value, $adminId, $valueType = 'string') {
    $allowedKeys = array(
        'site_name',
        'allow_public_signup',
        'free_employer_can_view_resume',
        'max_resume_upload_mb',
    );

    if (!in_array($key, $allowedKeys, true)) {
        throw new RuntimeException('Unknown setting.');
    }

    if (!in_array($valueType, array('string', 'number', 'boolean', 'json'), true)) {
        $valueType = 'string';
    }

    $statement = fp_db()->prepare(
        'INSERT INTO admin_settings (setting_key, setting_value, value_type, updated_by_user_id)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value),
                                 value_type = VALUES(value_type),
                                 updated_by_user_id = VALUES(updated_by_user_id)'
    );
    $statement->execute(array($key, (string) $value, $valueType, (int) $adminId));

    return true;
}

function fp_format_user_role($role) {
    $map = array(
        'job_seeker' => 'Job Seeker',
        'employer' => 'Employer',
        'admin' => 'Admin',
    );

    return $map[$role] ?? ucwords(str_replace('_', ' ', (string) $role));
}

function fp_user_status_badge_class($status) {
    $map = array(
        'active' => 'status-shortlisted',
        'blocked' => 'status-rejected',
        'deleted' => 'status-reviewed',
    );

    return $map[$status] ?? 'status-reviewed';
}
