<?php
if (!function_exists('fp_url')) {
    function fp_url($path) {
        $basePath = $GLOBALS['basePath'] ?? '';
        return htmlspecialchars($basePath . $path, ENT_QUOTES, 'UTF-8');
    }
}

$footerClass = trim($GLOBALS['footerClass'] ?? '');
$footerClassAttribute = $footerClass === '' ? 'section-py' : 'section-py ' . htmlspecialchars($footerClass, ENT_QUOTES, 'UTF-8');
?>
<footer class="<?php echo $footerClassAttribute; ?>" style="padding-bottom: 40px !important;">
    <div class="container">
        <div class="row g-5 mb-5">
            <div class="col-lg-4 text-center text-lg-start">
                <a class="navbar-brand mb-4 d-inline-flex justify-content-center justify-content-lg-start text-white" href="<?php echo fp_url('index.php'); ?>" style="color: white !important;">
                    <div class="brand-dot"></div>
                    Finance Port
                </a>
                <p class="pe-lg-5 text-balance text-white-50 fs-6">
                    The premium operating system for modern finance recruitment. Designed for ambition, engineered for excellence.
                </p>
            </div>
            <div class="col-lg-2 col-6">
                <h5 class="footer-heading">Company</h5>
                <a href="<?php echo fp_url('index.php'); ?>" class="footer-link">Home</a>
                <a href="<?php echo fp_url('job-listings.php'); ?>" class="footer-link">Opportunities</a>
                <a href="<?php echo fp_url('about.php'); ?>" class="footer-link">About Us</a>
                <a href="<?php echo fp_url('contact.php'); ?>" class="footer-link">Contact</a>
            </div>
            <div class="col-lg-2 col-6">
                <h5 class="footer-heading">Login</h5>
                <a href="<?php echo fp_url('login.php'); ?>" class="footer-link">Login</a>
                <a href="<?php echo fp_url('signup.php'); ?>" class="footer-link">Sign Up</a>
                <a href="<?php echo fp_url('jobseeker/login.php'); ?>" class="footer-link">Job Seeker Login</a>
                <a href="<?php echo fp_url('login.php?role=employer'); ?>" class="footer-link">Employer Login</a>
            </div>
            <div class="col-lg-2 col-6">
                <h5 class="footer-heading">Legal</h5>
                <a href="<?php echo fp_url('privacy.php'); ?>" class="footer-link">Privacy Policy</a>
                <a href="<?php echo fp_url('terms.php'); ?>" class="footer-link">Terms of Service</a>
            </div>
        </div>
        <div class="pt-4 border-top" style="border-color: rgba(255,255,255,0.1) !important;">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
                <p class="text-white-50 mb-0 text-center" style="font-size: 0.9rem;">&copy; 2026 Finance Port. All rights reserved.</p>
                <div class="d-flex gap-4">
                    <a href="#" class="text-white-50 text-decoration-none footer-social"><i class="fa-brands fa-linkedin fs-5"></i></a>
                    <a href="#" class="text-white-50 text-decoration-none footer-social"><i class="fa-brands fa-twitter fs-5"></i></a>
                    <a href="#" class="text-white-50 text-decoration-none footer-social"><i class="fa-brands fa-facebook fs-5"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php
if (!function_exists('fp_current_user')) {
    require_once __DIR__ . '/app.php';
}
$footerUser = fp_current_user();
if (!$footerUser) {
    include __DIR__ . '/auth_modal.php';
}
fp_sweetalert_foot();
require_once __DIR__ . '/password_toggle.php';
fp_password_toggle_styles();
fp_password_toggle_script();
?>
