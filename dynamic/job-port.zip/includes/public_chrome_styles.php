<style>
    :root {
        --primary: #071126;
        --secondary: #1E63FF;
        --accent: #D84000;
        --accent-light: #FF8C42;
        --bg-base: #FFFFFF;
        --bg-light: #F8FAFC;
        --text-main: #1E293B;
        --text-muted: #64748B;
        --border-light: #E2E8F0;
        --radius-md: 16px;
        --shadow-sm: 0 4px 6px -1px rgba(13, 43, 78, 0.05);
        --shadow-lg: 0 20px 40px -10px rgba(13, 43, 78, 0.12);
        --transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    }

    html, body {
        overflow-x: hidden;
        width: 100%;
        max-width: 100vw;
    }

    body {
        font-family: 'Inter', sans-serif;
        -webkit-font-smoothing: antialiased;
    }

    .section-py {
        padding-top: clamp(40px, 8vw, 100px);
        padding-bottom: clamp(40px, 8vw, 100px);
    }

    .btn-premium {
        background: var(--accent);
        color: white;
        border: 1px solid var(--accent);
        border-radius: var(--radius-md);
        padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
        font-weight: 600;
        transition: var(--transition);
        text-align: center;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        white-space: nowrap;
    }

    .btn-premium:hover {
        background: #A83000;
        border-color: #A83000;
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(13, 43, 78, 0.2);
        color: white;
    }

    .btn-outline-custom {
        background: transparent;
        color: var(--primary);
        border: 1px solid var(--border-light);
        border-radius: var(--radius-md);
        padding: clamp(10px, 2vw, 12px) clamp(20px, 4vw, 28px);
        font-weight: 600;
        transition: var(--transition);
        white-space: nowrap;
    }

    .btn-outline-custom:hover {
        background: var(--bg-light);
        border-color: var(--primary);
        color: var(--primary);
    }

    .navbar-premium {
        background: rgba(255, 255, 255, 0.98);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-bottom: 1px solid var(--border-light);
        padding: 16px 0;
        transition: background-color 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
        box-shadow: var(--shadow-sm);
    }

    .navbar-brand {
        font-weight: 800;
        font-size: clamp(1.2rem, 3vw, 1.5rem);
        color: var(--primary) !important;
        display: flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
    }

    .brand-dot {
        width: clamp(10px, 2vw, 14px);
        height: clamp(10px, 2vw, 14px);
        background: var(--accent);
        border-radius: 50%;
        flex-shrink: 0;
    }

    .nav-link {
        color: var(--text-muted) !important;
        font-weight: 600;
        font-size: 0.95rem;
        margin: 0 12px;
        transition: color 0.3s ease;
    }

    .nav-link:hover,
    .nav-link.active {
        color: var(--accent) !important;
    }

    .navbar-scrolled {
        background: rgba(13, 43, 78, 0.98) !important;
        box-shadow: 0 10px 30px rgba(13, 43, 78, 0.2) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
    }

    .navbar-scrolled .navbar-brand { color: #FFFFFF !important; }
    .navbar-scrolled .nav-link { color: rgba(255, 255, 255, 0.8) !important; }
    .navbar-scrolled .nav-link:hover,
    .navbar-scrolled .nav-link.active { color: var(--accent-light) !important; }
    .navbar-scrolled .btn-outline-custom {
        color: #FFFFFF !important;
        border-color: rgba(255, 255, 255, 0.4) !important;
    }
    .navbar-scrolled .btn-outline-custom:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        border-color: #FFFFFF !important;
        color: #FFFFFF !important;
    }
    .navbar-scrolled .navbar-toggler { border-color: rgba(255, 255, 255, 0.3) !important; }
    .navbar-scrolled .navbar-toggler-icon { filter: brightness(0) invert(1); }

    @media (max-width: 991px) {
        .navbar-collapse {
            background: var(--bg-base);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-md);
            padding: 20px;
            box-shadow: var(--shadow-lg);
            position: absolute;
            top: 100%;
            left: 15px;
            right: 15px;
            margin-top: 10px;
            max-height: calc(100vh - 80px);
            overflow-y: auto;
            z-index: 1050;
        }
        .navbar-nav { margin-bottom: 20px; }
        .nav-link { margin: 8px 0; font-size: 1.1rem; }
        .navbar-scrolled .navbar-collapse {
            background: var(--primary);
            border-color: rgba(255, 255, 255, 0.1);
        }
    }

    footer {
        background: var(--primary);
        color: white;
    }

    .footer-heading {
        color: var(--accent-light);
        font-weight: 600;
        margin-bottom: 24px;
        font-size: clamp(1rem, 2vw, 1.1rem);
    }

    .footer-link {
        color: rgba(255, 255, 255, 0.7);
        text-decoration: none;
        display: block;
        margin-bottom: 12px;
        transition: var(--transition);
        font-size: clamp(0.9rem, 2vw, 1rem);
    }

    .footer-link:hover {
        color: white;
        padding-left: 4px;
    }

    .footer-social { transition: var(--transition); }
    .footer-social:hover { color: var(--accent) !important; }

    .text-balance { text-wrap: balance; }
</style>
<?php
require_once __DIR__ . '/password_toggle.php';
fp_password_toggle_styles();
?>
