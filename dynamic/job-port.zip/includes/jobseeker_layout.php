<?php
require_once __DIR__ . '/app.php';

function fp_jobseeker_nav_items() {
    return array(
        'dashboard' => array('Home', 'dashboard.php', 'fa-solid fa-house'),
        'jobs' => array('Jobs', 'jobs.php', 'fa-solid fa-briefcase'),
        'applications' => array('Applications', 'applications.php', 'fa-solid fa-file-circle-check'),
        'profile' => array('Profile', 'profile.php', 'fa-solid fa-user'),
    );
}

function fp_jobseeker_auth_start($title, $wide = false) {
    $shellClass = 'portal-auth-shell' . ($wide ? ' portal-auth-shell-wide' : '');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> | Finance Port</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <?php fp_jobseeker_styles(); ?>
    <?php
    require_once __DIR__ . '/password_toggle.php';
    fp_password_toggle_styles();
    ?>
</head>
<body class="js-auth-page" style="background:#F8FAFC;color:#1E293B;">
<header class="portal-topbar">
    <div class="portal-topbar-inner">
        <a class="portal-brand" href="../index.php">
            <span class="brand-dot"></span>
            Finance Port
        </a>
        <a class="portal-topbar-link" href="../job-listings.php">Browse Jobs</a>
    </div>
</header>
<main class="<?php echo e($shellClass); ?>">
    <?php fp_render_flashes(); ?>
<?php
}

function fp_jobseeker_auth_end() {
    ?>
</main>
<?php fp_sweetalert_foot(); ?>
<?php
require_once __DIR__ . '/password_toggle.php';
fp_password_toggle_script();
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}

function fp_jobseeker_portal_start($title, $active = 'dashboard') {
    $user = fp_require_login('job_seeker', 'login.php');
    $profile = fp_ensure_jobseeker_profile($user['id']);
    $completion = fp_profile_completion($profile);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#071126">
    <title><?php echo e($title); ?> | Finance Port</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <?php fp_jobseeker_styles(); ?>
</head>
<body class="js-portal-page" style="background:#F8FAFC;color:#1E293B;">
<header class="portal-topbar">
    <div class="portal-topbar-inner">
        <a class="portal-brand" href="dashboard.php">
            <span class="brand-dot"></span>
            <span class="portal-brand-text">Finance Port</span>
        </a>
        <div class="portal-topbar-actions">
            <?php if ($completion < 100): ?>
                <span class="portal-pill d-none d-md-inline-flex"><?php echo e($completion); ?>% complete</span>
            <?php endif; ?>
            <a class="portal-avatar" href="profile.php" title="<?php echo e($user['name']); ?>">
                <?php echo e(fp_company_initials($user['name'])); ?>
            </a>
        </div>
    </div>
</header>

<main class="portal-shell">
    <?php fp_render_flashes(); ?>
    <div class="portal-layout">
        <?php fp_jobseeker_sidebar($active); ?>
        <section class="portal-content">
<?php
    return array('user' => $user, 'profile' => $profile, 'completion' => $completion);
}

function fp_jobseeker_portal_end($active = 'dashboard') {
    ?>
        </section>
    </div>
</main>

<?php fp_jobseeker_bottom_nav($active); ?>

<?php fp_sweetalert_foot(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}

function fp_jobseeker_styles() {
    ?>
<style>
    :root {
        --primary: #071126;
        --secondary: #1E63FF;
        --accent: #D84000;
        --accent-light: #FF8C42;
        --bg-page: #F8FAFC;
        --bg-surface: #FFFFFF;
        --bg-light: #F1F5F9;
        --border-light: #E2E8F0;
        --text-main: #1E293B;
        --text-muted: #64748B;
        --radius-lg: 20px;
        --radius-md: 16px;
        --shadow-sm: 0 4px 6px -1px rgba(13, 43, 78, 0.05);
        --shadow-md: 0 10px 30px -5px rgba(13, 43, 78, 0.08);
        --nav-height: 64px;
        --bottom-nav-height: 72px;
        --transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    }
    * { box-sizing: border-box; }
    html, body { width: 100%; overflow-x: hidden; }
    body {
        margin: 0;
        min-height: 100vh;
        font-family: 'Inter', sans-serif;
        background: var(--bg-page);
        color: var(--text-main);
        -webkit-font-smoothing: antialiased;
    }
    h1, h2, h3, h4, h5, h6 { color: var(--primary); font-weight: 700; letter-spacing: -0.02em; }
    a { color: var(--secondary); text-decoration: none; }
    .portal-topbar {
        position: fixed;
        top: 0; left: 0; right: 0;
        z-index: 1040;
        background: rgba(7, 17, 38, 0.98);
        backdrop-filter: blur(16px);
        border-bottom: 1px solid rgba(255,255,255,0.08);
        box-shadow: var(--shadow-sm);
    }
    .portal-topbar-inner {
        max-width: 1180px;
        margin: 0 auto;
        padding: 14px 16px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
    }
    .portal-brand {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        color: #fff !important;
        font-weight: 800;
        font-size: 1rem;
        text-decoration: none;
    }
    .brand-dot {
        width: 12px; height: 12px;
        border-radius: 50%;
        background: var(--accent);
        flex-shrink: 0;
    }
    .portal-topbar-link {
        color: rgba(255,255,255,0.85);
        font-weight: 600;
        font-size: 0.9rem;
    }
    .portal-topbar-link:hover { color: var(--accent-light); }
    .portal-topbar-actions { display: flex; align-items: center; gap: 10px; }
    .portal-pill {
        align-items: center;
        padding: 6px 12px;
        border-radius: 999px;
        background: rgba(255,255,255,0.1);
        color: rgba(255,255,255,0.9);
        font-size: 0.78rem;
        font-weight: 700;
    }
    .portal-avatar {
        width: 38px; height: 38px;
        border-radius: 12px;
        background: rgba(216, 64, 0, 0.2);
        border: 1px solid rgba(255,255,255,0.15);
        color: #fff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 0.85rem;
    }
    .portal-shell {
        max-width: 1180px;
        margin: 0 auto;
        padding: calc(var(--nav-height) + 16px) 16px calc(var(--bottom-nav-height) + 24px);
    }
    .js-auth-page .portal-shell,
    .portal-auth-shell {
        max-width: 560px;
        margin: 0 auto;
        padding: calc(var(--nav-height) + 24px) 16px 48px;
    }
    .portal-auth-shell:has(.auth-shell-wide) {
        max-width: 820px;
    }
    .portal-auth-shell-wide {
        max-width: 820px;
    }
    .portal-layout {
        display: grid;
        grid-template-columns: 250px minmax(0, 1fr);
        gap: 24px;
        align-items: start;
    }
    .portal-sidebar {
        position: sticky;
        top: calc(var(--nav-height) + 16px);
        background: var(--bg-surface);
        border: 1px solid var(--border-light);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-sm);
        padding: 12px;
    }
    .portal-sidebar a {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 16px;
        border-radius: 12px;
        color: var(--text-muted);
        font-weight: 600;
        font-size: 0.95rem;
        margin-bottom: 4px;
        transition: var(--transition);
    }
    .portal-sidebar a:hover,
    .portal-sidebar a.active {
        background: rgba(216, 64, 0, 0.08);
        color: var(--accent);
    }
    .portal-sidebar a.logout-link {
        margin-top: 8px;
        border-top: 1px solid var(--border-light);
        padding-top: 18px;
        color: var(--text-muted);
    }
    .portal-content { min-width: 0; }
    .portal-bottom-nav {
        display: none;
        position: fixed;
        left: 0; right: 0; bottom: 0;
        z-index: 1050;
        background: rgba(255,255,255,0.98);
        backdrop-filter: blur(16px);
        border-top: 1px solid var(--border-light);
        padding: 8px 8px calc(8px + env(safe-area-inset-bottom));
        box-shadow: 0 -8px 24px rgba(13, 43, 78, 0.06);
    }
    .portal-bottom-nav-inner {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 4px;
        max-width: 520px;
        margin: 0 auto;
    }
    .portal-bottom-nav a {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 4px;
        min-height: 56px;
        border-radius: 14px;
        color: var(--text-muted);
        font-size: 0.68rem;
        font-weight: 700;
        text-decoration: none;
        transition: var(--transition);
    }
    .portal-bottom-nav a i { font-size: 1.15rem; }
    .portal-bottom-nav a.active {
        color: var(--accent);
        background: rgba(216, 64, 0, 0.08);
    }
    .panel, .metric-card, .job-card, .empty-card {
        background: var(--bg-surface);
        border: 1px solid var(--border-light);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-sm);
    }
    .panel { padding: clamp(20px, 4vw, 28px); }
    .page-heading {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 16px;
        margin-bottom: 20px;
    }
    .page-heading h1 { font-size: clamp(1.45rem, 4vw, 2rem); margin: 0 0 6px; }
    .muted { color: var(--text-muted); }
    .section-tag {
        display: inline-block;
        padding: 6px 14px;
        background: rgba(216, 64, 0, 0.1);
        color: var(--accent);
        border-radius: 999px;
        font-size: 0.75rem;
        font-weight: 800;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        margin-bottom: 12px;
        border: 1px solid rgba(216, 64, 0, 0.2);
    }
    .btn-premium {
        background: var(--accent);
        color: #fff;
        border: 1px solid var(--accent);
        border-radius: var(--radius-md);
        padding: 12px 20px;
        font-weight: 700;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: var(--transition);
        border: none;
        cursor: pointer;
        text-decoration: none;
    }
    .btn-premium:hover { background: #A83000; color: #fff; transform: translateY(-1px); }
    .btn-outline-custom {
        background: transparent;
        color: var(--primary);
        border: 1px solid var(--border-light);
        border-radius: var(--radius-md);
        padding: 12px 20px;
        font-weight: 700;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        text-decoration: none;
        transition: var(--transition);
    }
    .btn-outline-custom:hover { border-color: var(--primary); color: var(--primary); }
    .metric-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
        margin-bottom: 20px;
    }
    .metric-card { padding: 18px; }
    .metric-value { font-size: clamp(1.6rem, 4vw, 2rem); font-weight: 800; color: var(--primary); line-height: 1; }
    .metric-label { color: var(--text-muted); font-size: 0.88rem; margin-top: 8px; font-weight: 600; }
    .completion-banner {
        background: linear-gradient(135deg, var(--primary) 0%, #0f2848 100%);
        color: #fff;
        border-radius: var(--radius-md);
        padding: 20px;
        margin-bottom: 20px;
        border: 1px solid rgba(255,255,255,0.08);
    }
    .completion-bar {
        height: 8px;
        background: rgba(255,255,255,0.15);
        border-radius: 999px;
        overflow: hidden;
        margin: 12px 0 16px;
    }
    .completion-bar span {
        display: block;
        height: 100%;
        background: linear-gradient(90deg, var(--accent), var(--accent-light));
        border-radius: 999px;
    }
    .form-label { font-weight: 700; color: var(--primary); margin-bottom: 8px; font-size: 0.9rem; }
    .form-control, .form-select {
        border-radius: 12px;
        border: 1px solid var(--border-light);
        padding: 12px 14px;
        font-size: 1rem;
        min-height: 48px;
    }
    .form-control:focus, .form-select:focus {
        border-color: var(--accent);
        box-shadow: 0 0 0 0.15rem rgba(216, 64, 0, 0.12);
    }
    .status-pill {
        display: inline-flex;
        align-items: center;
        border-radius: 999px;
        padding: 5px 10px;
        font-weight: 800;
        font-size: 0.75rem;
        border: 1px solid var(--border-light);
    }
    .status-applied, .status-reviewed { background: rgba(30, 99, 255, 0.1); color: var(--secondary); border-color: rgba(30, 99, 255, 0.2); }
    .status-shortlisted, .status-hired { background: rgba(20, 130, 80, 0.1); color: #0f7a48; border-color: rgba(20, 130, 80, 0.2); }
    .status-rejected, .status-withdrawn { background: rgba(216, 64, 0, 0.1); color: var(--accent); border-color: rgba(216, 64, 0, 0.2); }
    .job-card { padding: 18px; margin-bottom: 14px; transition: var(--transition); }
    .job-card:hover { box-shadow: var(--shadow-md); border-color: rgba(7, 17, 38, 0.12); }
    .job-logo {
        width: 52px; height: 52px;
        border-radius: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: var(--bg-light);
        border: 1px solid var(--border-light);
        font-weight: 800;
        color: var(--primary);
        flex-shrink: 0;
    }
    .tag {
        display: inline-flex;
        border: 1px solid var(--border-light);
        border-radius: 8px;
        padding: 4px 10px;
        color: var(--text-muted);
        background: var(--bg-light);
        font-size: 0.78rem;
        font-weight: 700;
        margin: 0 6px 6px 0;
    }
    .empty-card { padding: 40px 24px; text-align: center; }
    .empty-card i { font-size: 2.2rem; color: var(--accent); margin-bottom: 12px; }
    .resume-box {
        border: 1px dashed var(--border-light);
        border-radius: var(--radius-md);
        padding: clamp(14px, 3vw, 20px);
        background: var(--bg-light);
    }
    .resume-panel { min-width: 0; }
    .resume-current {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        margin-bottom: 14px;
        min-width: 0;
    }
    .resume-current-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        background: rgba(216, 64, 0, 0.1);
        color: var(--accent);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }
    .resume-current-body { min-width: 0; flex: 1 1 auto; }
    .resume-current-name {
        font-weight: 700;
        color: var(--primary);
        word-break: break-word;
        line-height: 1.35;
        margin-bottom: 4px;
    }
    .resume-actions {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
        width: 100%;
    }
    .resume-actions .btn {
        width: 100%;
        min-height: 44px;
        padding: 10px 12px;
        font-size: 0.88rem;
        white-space: nowrap;
    }
    .resume-file-picker {
        position: relative;
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-bottom: 4px;
    }
    .resume-file-picker input[type="file"] {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }
    .resume-file-picker-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
        min-height: 48px;
        padding: 12px 16px;
        border: 1px dashed var(--border-light);
        border-radius: 12px;
        background: #fff;
        color: var(--primary);
        font-weight: 700;
        font-size: 0.92rem;
        cursor: pointer;
        transition: var(--transition);
        text-align: center;
    }
    .resume-file-picker-btn:hover {
        border-color: var(--accent);
        color: var(--accent);
        background: rgba(216, 64, 0, 0.04);
    }
    .resume-file-name {
        display: block;
        font-size: 0.85rem;
        color: var(--text-muted);
        word-break: break-word;
        line-height: 1.4;
        padding: 0 2px;
    }
    .resume-file-icon {
        width: 52px;
        height: 52px;
        border-radius: 14px;
        background: rgba(216, 64, 0, 0.1);
        color: var(--accent);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.4rem;
        flex-shrink: 0;
    }
    .resume-preview-panel {
        min-height: 70vh;
        background: #E2E8F0;
    }
    .resume-preview-frame {
        width: 100%;
        min-height: 70vh;
        border: 0;
        display: block;
        background: #fff;
    }
    .search-bar {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 18px;
    }
    .text-accent { color: var(--accent) !important; }
    .profile-pill {
        display: inline-flex;
        align-items: center;
        padding: 8px 14px;
        border-radius: 999px;
        background: rgba(216, 64, 0, 0.1);
        color: var(--accent);
        font-size: 0.82rem;
        font-weight: 800;
        border: 1px solid rgba(216, 64, 0, 0.2);
        white-space: nowrap;
    }
    .alert {
        border-radius: 14px;
        border: 1px solid transparent;
        font-weight: 600;
        font-size: 0.92rem;
    }
    .alert-success { background: rgba(20, 130, 80, 0.1); border-color: rgba(20, 130, 80, 0.2); color: #0f7a48; }
    .alert-danger { background: rgba(216, 64, 0, 0.1); border-color: rgba(216, 64, 0, 0.2); color: #a83000; }
    .alert-warning { background: rgba(255, 140, 66, 0.12); border-color: rgba(255, 140, 66, 0.25); color: #9a4a00; }
    .portal-sticky-apply {
        display: none;
        position: fixed;
        left: 0; right: 0;
        bottom: calc(var(--bottom-nav-height) + env(safe-area-inset-bottom));
        z-index: 1045;
        padding: 12px 16px;
        background: rgba(255,255,255,0.98);
        backdrop-filter: blur(16px);
        border-top: 1px solid var(--border-light);
        box-shadow: 0 -8px 24px rgba(13, 43, 78, 0.08);
    }
    .portal-sticky-apply .btn { width: 100%; }
    .auth-shell-wide { width: min(760px, 100%); margin: 0 auto; }
    @media (min-width: 768px) {
        .search-bar { flex-direction: row; flex-wrap: wrap; }
        .search-bar .form-control { flex: 1 1 180px; }
        .search-bar .btn-premium { flex: 0 0 auto; }
        .portal-sticky-apply { display: none !important; }
    }
    @media (max-width: 991px) {
        .portal-layout { grid-template-columns: 1fr; }
        .portal-sidebar { display: none; }
        .portal-bottom-nav { display: block; }
        .portal-brand-text { font-size: 0.95rem; }
        .metric-grid { grid-template-columns: 1fr 1fr; }
        .metric-grid .metric-card:last-child { grid-column: span 2; }
        .page-heading { flex-direction: column; align-items: stretch; }
        .page-heading .btn { width: 100%; }
        .job-card .d-flex.gap-3 > .flex-grow-1 .d-flex.flex-wrap.gap-2 .btn { flex: 1 1 auto; }
        .portal-sticky-apply.is-visible { display: block; }
        .js-portal-page .portal-shell.has-sticky-apply {
            padding-bottom: calc(var(--bottom-nav-height) + 88px + env(safe-area-inset-bottom));
        }
    }
    @media (max-width: 575px) {
        .metric-grid { grid-template-columns: 1fr; }
        .metric-grid .metric-card:last-child { grid-column: auto; }
        .portal-topbar-inner { padding: 12px 14px; }
        .portal-shell { padding-left: 14px; padding-right: 14px; }
    }
    @media (min-width: 992px) {
        .portal-sticky-apply { display: none !important; }
    }
    .portal-auth-shell .panel,
    .js-auth-page .panel {
        background: var(--bg-surface);
        border: 1px solid var(--border-light);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-md);
        padding: clamp(24px, 5vw, 36px);
    }
    .auth-shell { width: 100%; }
</style>
<?php
}

function fp_jobseeker_sidebar($active) {
    $items = fp_jobseeker_nav_items();
    ?>
<aside class="portal-sidebar">
    <?php foreach ($items as $key => $item): ?>
        <a class="<?php echo $active === $key ? 'active' : ''; ?>" href="<?php echo e($item[1]); ?>">
            <i class="<?php echo e($item[2]); ?>"></i>
            <span><?php echo e($item[0]); ?></span>
        </a>
    <?php endforeach; ?>
    <a class="logout-link" href="logout.php">
        <i class="fa-solid fa-arrow-right-from-bracket"></i>
        <span>Logout</span>
    </a>
</aside>
<?php
}

function fp_jobseeker_bottom_nav($active) {
    $items = fp_jobseeker_nav_items();
    ?>
<nav class="portal-bottom-nav" aria-label="Student navigation">
    <div class="portal-bottom-nav-inner">
        <?php foreach ($items as $key => $item): ?>
            <a class="<?php echo $active === $key ? 'active' : ''; ?>" href="<?php echo e($item[1]); ?>">
                <i class="<?php echo e($item[2]); ?>"></i>
                <span><?php echo e($item[0]); ?></span>
            </a>
        <?php endforeach; ?>
    </div>
</nav>
<?php
}

// Legacy aliases for login/signup pages
function fp_jobseeker_page_start($title, $active = 'dashboard', $headerPage = 'jobseeker-dashboard', $wide = false) {
    fp_jobseeker_auth_start($title, $wide);
}

function fp_jobseeker_page_end() {
    fp_jobseeker_auth_end();
}

function fp_jobseeker_layout_open($active) {}

function fp_jobseeker_layout_close() {}
