<?php
if (!function_exists('fp_url')) {
    function fp_url($path) {
        $basePath = $GLOBALS['basePath'] ?? '';
        return htmlspecialchars($basePath . $path, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('fp_active_class')) {
    function fp_active_class($page) {
        $currentPage = $GLOBALS['currentPage'] ?? '';
        return $currentPage === $page ? ' active' : '';
    }
}

if (!function_exists('fp_current_user')) {
    require_once __DIR__ . '/app.php';
}

$headerUser = fp_current_user();
?>
<nav class="navbar navbar-expand-lg navbar-premium fixed-top">
    <div class="container">
        <a class="navbar-brand" href="<?php echo fp_url('index.php'); ?>">
            <div class="brand-dot"></div>
            Finance Port
        </a>
        <button class="navbar-toggler p-2" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" style="border:1px solid var(--border-light);">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link<?php echo fp_active_class('home'); ?>" href="<?php echo fp_url('index.php'); ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link<?php echo fp_active_class('opportunities'); ?>" href="<?php echo fp_url('job-listings.php'); ?>">Opportunities</a></li>
                <li class="nav-item"><a class="nav-link<?php echo fp_active_class('about'); ?>" href="<?php echo fp_url('about.php'); ?>">About Us</a></li>
                <li class="nav-item"><a class="nav-link<?php echo fp_active_class('contact'); ?>" href="<?php echo fp_url('contact.php'); ?>">Contact</a></li>
            </ul>
            <div class="d-flex flex-column flex-lg-row gap-3 mt-3 mt-lg-0">
                <?php if ($headerUser): ?>
                    <span class="btn btn-outline-custom w-100 w-lg-auto text-center disabled opacity-100"><?php echo e($headerUser['name']); ?></span>
                    <?php if ($headerUser['role'] === 'job_seeker'): ?>
                        <a href="<?php echo fp_url('jobseeker/dashboard.php'); ?>" class="btn btn-outline-custom w-100 w-lg-auto text-center">Dashboard</a>
                        <a href="<?php echo fp_url('jobseeker/logout.php'); ?>" class="btn btn-premium w-100 w-lg-auto text-center">Logout</a>
                    <?php elseif ($headerUser['role'] === 'employer'): ?>
                        <a href="<?php echo fp_url('employer/dashboard.php'); ?>" class="btn btn-outline-custom w-100 w-lg-auto text-center">Dashboard</a>
                        <a href="<?php echo fp_url('employer/logout.php'); ?>" class="btn btn-premium w-100 w-lg-auto text-center">Logout</a>
                    <?php elseif ($headerUser['role'] === 'admin'): ?>
                        <a href="<?php echo fp_url('admin/dashboard.php'); ?>" class="btn btn-outline-custom w-100 w-lg-auto text-center">Admin</a>
                        <a href="<?php echo fp_url('admin/logout.php'); ?>" class="btn btn-premium w-100 w-lg-auto text-center">Logout</a>
                    <?php endif; ?>
                <?php else: ?>
                    <button type="button" class="btn btn-outline-custom w-100 w-lg-auto text-center fp-open-auth<?php echo fp_active_class('login'); ?>" data-auth-mode="login">Sign In</button>
                    <button type="button" class="btn btn-premium w-100 w-lg-auto text-center fp-open-auth<?php echo fp_active_class('employer-login'); ?>" data-auth-mode="login" data-auth-role="employer">Post a Role</button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
