<?php

function fp_password_toggle_styles() {
    static $loaded = false;
    if ($loaded) {
        return;
    }
    $loaded = true;
    ?>
<style>
.fp-password-field {
    position: relative;
}
.fp-password-field > .form-control,
.fp-password-field > .fp-auth-input {
    padding-right: 3rem;
}
.fp-password-toggle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    border: none;
    background: transparent;
    color: #64748B;
    padding: 0;
    width: 2rem;
    height: 2rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    line-height: 1;
    z-index: 2;
}
.fp-password-toggle:hover {
    color: #071126;
}
.fp-password-toggle:focus-visible {
    outline: 2px solid #D84000;
    outline-offset: 2px;
    border-radius: 4px;
}
</style>
    <?php
}

function fp_password_toggle_script() {
    static $loaded = false;
    if ($loaded) {
        return;
    }
    $loaded = true;
    ?>
<script>
(function () {
    function fpEnhancePasswordFields(root) {
        var scope = root || document;
        scope.querySelectorAll('input[type="password"]:not([data-fp-pw-ready])').forEach(function (input) {
            if (input.closest('.fp-password-field')) {
                return;
            }

            input.setAttribute('data-fp-pw-ready', '1');

            var wrap = document.createElement('div');
            wrap.className = 'fp-password-field';
            input.parentNode.insertBefore(wrap, input);
            wrap.appendChild(input);

            var toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = 'fp-password-toggle';
            toggle.setAttribute('aria-label', 'Show password');
            toggle.innerHTML = '<i class="fa-solid fa-eye" aria-hidden="true"></i>';

            toggle.addEventListener('click', function () {
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                toggle.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
                toggle.querySelector('i').className = show ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
            });

            wrap.appendChild(toggle);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            fpEnhancePasswordFields();
        });
    } else {
        fpEnhancePasswordFields();
    }

    window.fpEnhancePasswordFields = fpEnhancePasswordFields;
})();
</script>
    <?php
}
