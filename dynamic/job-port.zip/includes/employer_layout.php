<?php
require_once __DIR__ . '/jobseeker_layout.php';

function fp_employer_nav_items() {
    return array(
        'dashboard' => array('Home', 'dashboard.php', 'fa-solid fa-house'),
        'jobs' => array('Jobs', 'jobs.php', 'fa-solid fa-briefcase'),
        'applicants' => array('Applicants', 'applicants.php', 'fa-solid fa-users'),
        'candidates' => array('Talent', 'candidates.php', 'fa-solid fa-magnifying-glass'),
        'profile' => array('Company', 'profile.php', 'fa-solid fa-building'),
    );
}

function fp_employer_auth_start($title, $wide = false) {
    $shellClass = 'portal-auth-shell' . ($wide ? ' portal-auth-shell-wide' : '');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> | Finance Port Employer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <?php fp_jobseeker_styles(); ?>
</head>
<body class="js-auth-page" style="background:#F8FAFC;color:#1E293B;">
<header class="portal-topbar">
    <div class="portal-topbar-inner">
        <a class="portal-brand" href="../index.php">
            <span class="brand-dot"></span>
            Finance Port
        </a>
        <a class="portal-topbar-link" href="../job-listings.php">Public Jobs</a>
    </div>
</header>
<main class="<?php echo e($shellClass); ?>">
    <?php fp_render_flashes(); ?>
<?php
}

function fp_employer_auth_end() {
    ?>
</main>
<?php fp_sweetalert_foot(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}

function fp_employer_portal_start($title, $active = 'dashboard') {
    $user = fp_require_login('employer', 'login.php');
    $profile = fp_ensure_employer_profile($user['id']);
    $companyName = $profile['company_name'] ?? $user['name'];
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#071126">
    <title><?php echo e($title); ?> | Finance Port Employer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <?php fp_jobseeker_styles(); ?>
    <style>
        .portal-bottom-nav-inner a { min-width: 0; padding: 8px 4px; }
        .portal-bottom-nav-inner a span { font-size: 0.62rem; letter-spacing: 0; }
    </style>
</head>
<body class="js-portal-page" style="background:#F8FAFC;color:#1E293B;">
<header class="portal-topbar">
    <div class="portal-topbar-inner">
        <a class="portal-brand" href="dashboard.php">
            <span class="brand-dot"></span>
            <span class="portal-brand-text">Finance Port</span>
        </a>
        <div class="portal-topbar-actions">
            <span class="portal-pill d-none d-md-inline-flex text-truncate" style="max-width:160px;"><?php echo e($companyName); ?></span>
            <a class="portal-avatar" href="profile.php" title="<?php echo e($companyName); ?>">
                <?php echo e(fp_company_initials($companyName)); ?>
            </a>
        </div>
    </div>
</header>

<main class="portal-shell">
    <?php fp_render_flashes(); ?>
    <div class="portal-layout">
        <?php fp_employer_sidebar($active); ?>
        <section class="portal-content">
<?php
    return array('user' => $user, 'profile' => $profile);
}

function fp_employer_portal_end($active = 'dashboard') {
    ?>
        </section>
    </div>
</main>

<?php fp_employer_bottom_nav($active); ?>

<?php fp_sweetalert_foot(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}

function fp_employer_sidebar($active) {
    $items = fp_employer_nav_items();
    ?>
<aside class="portal-sidebar">
    <?php foreach ($items as $key => $item): ?>
        <a class="<?php echo $active === $key ? 'active' : ''; ?>" href="<?php echo e($item[1]); ?>">
            <i class="<?php echo e($item[2]); ?>"></i>
            <span><?php echo e($item[0]); ?></span>
        </a>
    <?php endforeach; ?>
    <a class="logout-link" href="logout.php">
        <i class="fa-solid fa-arrow-right-from-bracket"></i>
        <span>Logout</span>
    </a>
</aside>
<?php
}

function fp_employer_bottom_nav($active) {
    $items = fp_employer_nav_items();
    ?>
<nav class="portal-bottom-nav" aria-label="Employer navigation">
    <div class="portal-bottom-nav-inner">
        <?php foreach ($items as $key => $item): ?>
            <a class="<?php echo $active === $key ? 'active' : ''; ?>" href="<?php echo e($item[1]); ?>">
                <i class="<?php echo e($item[2]); ?>"></i>
                <span><?php echo e($item[0]); ?></span>
            </a>
        <?php endforeach; ?>
    </div>
</nav>
<?php
}
