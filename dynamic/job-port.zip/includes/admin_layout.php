<?php
require_once __DIR__ . '/app.php';

function fp_admin_nav_items() {
    return array(
        'dashboard' => array('Dashboard', 'dashboard.php', 'fa-solid fa-gauge-high'),
        'users' => array('Users', 'users.php', 'fa-solid fa-users'),
        'jobs' => array('Jobs', 'jobs.php', 'fa-solid fa-briefcase'),
        'settings' => array('Settings', 'settings.php', 'fa-solid fa-gear'),
    );
}

function fp_admin_page_start($title) {
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> | Finance Port Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php fp_sweetalert_head(); ?>
    <style>
        :root {
            --primary: #071126;
            --secondary: #1E63FF;
            --accent: #D84000;
            --bg-page: #F4F7FB;
            --bg-surface: #FFFFFF;
            --border-light: #D7E2EF;
            --text-main: #0F1B34;
            --text-muted: #64748B;
            --radius-lg: 20px;
            --shadow-sm: 0 12px 32px rgba(13, 43, 78, 0.08);
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'Inter', sans-serif;
            background: var(--bg-page);
            color: var(--text-main);
        }
        .admin-login-shell {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 24px 16px;
        }
        .admin-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-weight: 800;
            color: var(--primary);
            text-decoration: none;
            margin-bottom: 24px;
        }
        .admin-brand-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--accent);
        }
        .admin-login-card {
            width: min(460px, 100%);
            background: var(--bg-surface);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            padding: 40px 32px;
        }
        .admin-login-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 999px;
            background: rgba(7, 17, 38, 0.08);
            color: var(--primary);
            font-size: 0.75rem;
            font-weight: 800;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            margin-bottom: 16px;
        }
        .form-control, .form-select {
            border-radius: 14px;
            border: 1px solid var(--border-light);
            padding: 12px 16px;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 0.12rem rgba(216, 64, 0, 0.16);
        }
        .btn-admin {
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 14px;
            padding: 12px 18px;
            font-weight: 700;
        }
        .btn-admin:hover { background: var(--accent); color: #fff; }
        .btn-admin-outline {
            background: transparent;
            color: var(--primary);
            border: 1px solid var(--border-light);
            border-radius: 14px;
            padding: 10px 16px;
            font-weight: 600;
        }
        .btn-admin-outline:hover {
            border-color: var(--accent);
            color: var(--accent);
        }
        .btn-admin-danger {
            background: #fff;
            color: #B42318;
            border: 1px solid rgba(180, 35, 24, 0.25);
            border-radius: 14px;
            padding: 10px 16px;
            font-weight: 600;
        }
        .btn-admin-danger:hover {
            background: #FEF3F2;
            color: #912018;
        }
        .muted { color: var(--text-muted); }
        .admin-topbar {
            background: var(--primary);
            color: #fff;
            padding: 14px 24px;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .admin-topbar-inner {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
        }
        .admin-topbar a { color: rgba(255,255,255,0.85); text-decoration: none; font-weight: 600; font-size: 0.9rem; }
        .admin-topbar a:hover { color: #fff; }
        .admin-shell {
            max-width: 1400px;
            margin: 0 auto;
            padding: 24px;
            display: grid;
            grid-template-columns: 240px minmax(0, 1fr);
            gap: 24px;
            align-items: start;
        }
        .admin-sidebar {
            background: var(--bg-surface);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            padding: 16px;
            position: sticky;
            top: 84px;
        }
        .admin-sidebar-label {
            font-size: 0.7rem;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--text-muted);
            padding: 8px 12px 12px;
        }
        .admin-nav-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 14px;
            border-radius: 14px;
            color: var(--text-main);
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 4px;
        }
        .admin-nav-link:hover {
            background: rgba(7, 17, 38, 0.05);
            color: var(--primary);
        }
        .admin-nav-link.active {
            background: rgba(216, 64, 0, 0.1);
            color: var(--accent);
        }
        .admin-nav-link i { width: 18px; text-align: center; }
        .admin-content { min-width: 0; }
        .admin-panel-card {
            background: var(--bg-surface);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            padding: 28px;
        }
        .admin-stat-card {
            background: var(--bg-surface);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-lg);
            padding: 24px;
            height: 100%;
        }
        .admin-stat-card .label {
            font-size: 0.8rem;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .admin-stat-card .value {
            font-size: 2rem;
            font-weight: 800;
            color: var(--primary);
            line-height: 1.2;
        }
        .page-heading {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }
        .page-heading h1 {
            font-size: 1.75rem;
            font-weight: 800;
            margin: 0 0 6px;
        }
        .section-tag {
            display: inline-block;
            font-size: 0.72rem;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--accent);
            margin-bottom: 8px;
        }
        .status-pill {
            display: inline-flex;
            align-items: center;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: capitalize;
        }
        .status-shortlisted { background: rgba(34, 197, 94, 0.12); color: #15803D; }
        .status-reviewed { background: rgba(100, 116, 139, 0.12); color: #475569; }
        .status-rejected { background: rgba(239, 68, 68, 0.12); color: #B91C1C; }
        .status-applied { background: rgba(30, 99, 255, 0.12); color: #1D4ED8; }
        .admin-table-wrap { overflow-x: auto; }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 720px;
        }
        .admin-table th,
        .admin-table td {
            padding: 14px 12px;
            border-bottom: 1px solid var(--border-light);
            text-align: left;
            vertical-align: middle;
        }
        .admin-table th {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-muted);
            font-weight: 800;
        }
        .admin-table tbody tr:hover { background: rgba(7, 17, 38, 0.02); }
        .admin-filter-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 20px;
        }
        .empty-card {
            text-align: center;
            padding: 48px 24px;
        }
        .empty-card i {
            font-size: 2rem;
            color: var(--text-muted);
            margin-bottom: 16px;
        }
        @media (max-width: 991px) {
            .admin-shell {
                grid-template-columns: 1fr;
                padding: 16px;
            }
            .admin-sidebar {
                position: static;
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                padding: 12px;
            }
            .admin-sidebar-label { display: none; }
            .admin-nav-link {
                margin-bottom: 0;
                padding: 10px 12px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
<?php
}

function fp_admin_page_end() {
    ?>
<?php fp_sweetalert_foot(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}

function fp_admin_render_flashes() {
    fp_render_flashes();
}

function fp_admin_sidebar($active) {
    $items = fp_admin_nav_items();
    ?>
<aside class="admin-sidebar">
    <div class="admin-sidebar-label">Admin Panel</div>
    <?php foreach ($items as $key => $item): ?>
        <a class="admin-nav-link<?php echo $active === $key ? ' active' : ''; ?>" href="<?php echo e($item[1]); ?>">
            <i class="<?php echo e($item[2]); ?>"></i>
            <span><?php echo e($item[0]); ?></span>
        </a>
    <?php endforeach; ?>
</aside>
<?php
}

function fp_admin_shell_start($title, $active = 'dashboard') {
    fp_admin_page_start($title);
    $user = fp_current_user();
    ?>
<div class="admin-topbar">
    <div class="admin-topbar-inner">
        <div class="fw-bold">Finance Port Admin</div>
        <div class="d-flex align-items-center gap-3">
            <?php if ($user): ?>
                <span class="small d-none d-sm-inline"><?php echo e($user['name']); ?></span>
                <a href="logout.php">Logout</a>
            <?php endif; ?>
            <a href="../index.php">View Site</a>
        </div>
    </div>
</div>
<div class="admin-shell">
    <?php fp_admin_sidebar($active); ?>
    <div class="admin-content">
        <?php fp_admin_render_flashes(); ?>
<?php
}

function fp_admin_shell_end() {
    ?>
    </div>
</div>
<?php
    fp_admin_page_end();
}

