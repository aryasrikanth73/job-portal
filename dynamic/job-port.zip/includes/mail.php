<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as MailException;

function fp_mail_config() {
    static $config = null;

    if ($config !== null) {
        return $config;
    }

    $localPath = FP_BASE_DIR . '/config/mail.local.php';
    $examplePath = FP_BASE_DIR . '/config/mail.example.php';

    if (is_file($localPath)) {
        $config = require $localPath;
    } elseif (is_file($examplePath)) {
        $config = require $examplePath;
    } else {
        $config = array();
    }

    return is_array($config) ? $config : array();
}

function fp_site_url($path = '') {
    $config = fp_mail_config();
    $base = rtrim((string) ($config['site_url'] ?? ''), '/');

    if ($base === '') {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $appBase = fp_app_base_path();
        $base = $scheme . '://' . $host . rtrim($appBase, '/');
    }

    $path = ltrim((string) $path, '/');

    return $path === '' ? $base : $base . '/' . $path;
}

function fp_send_mail($toEmail, $toName, $subject, $htmlBody, $textBody = '') {
    $autoload = FP_BASE_DIR . '/vendor/autoload.php';
    if (!is_file($autoload)) {
        throw new RuntimeException('PHPMailer is not installed. Run: composer require phpmailer/phpmailer');
    }

    require_once $autoload;

    $cfg = fp_mail_config();
    $username = trim((string) ($cfg['smtp_username'] ?? ''));
    $password = preg_replace('/\s+/', '', (string) ($cfg['smtp_password'] ?? ''));

    if ($username === '' || $password === '') {
        throw new RuntimeException('Mail is not configured. Copy config/mail.example.php to config/mail.local.php.');
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = $cfg['smtp_host'] ?? 'smtp.gmail.com';
        $mail->SMTPAuth = !empty($cfg['smtp_auth']);
        $mail->Username = $username;
        $mail->Password = $password;

        $secure = strtolower((string) ($cfg['smtp_secure'] ?? 'tls'));
        if ($secure === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($secure === '' || $secure === 'none') {
            $mail->SMTPSecure = false;
            $mail->SMTPAutoTLS = false;
        } else {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }

        $mail->Port = (int) ($cfg['smtp_port'] ?? 587);
        $mail->CharSet = 'UTF-8';
        $mail->Timeout = 20;

        $fromEmail = $cfg['from_email'] ?? $username;
        $fromName = $cfg['from_name'] ?? 'Finance Port';
        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($toEmail, $toName !== '' ? $toName : $toEmail);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $htmlBody;
        $mail->AltBody = $textBody !== '' ? $textBody : strip_tags(str_replace(array('<br>', '<br/>', '<br />'), "\n", $htmlBody));

        $mail->send();

        return true;
    } catch (MailException $exception) {
        $errorInfo = (string) $mail->ErrorInfo;
        if (stripos($errorInfo, 'Could not authenticate') !== false
            || stripos($errorInfo, 'BadCredentials') !== false
            || stripos($errorInfo, 'Username and Password not accepted') !== false) {
            throw new RuntimeException(
                'Gmail rejected the SMTP login. Use a Google App Password (not your normal Gmail password) in config/mail.local.php. '
                . 'Create one at https://myaccount.google.com/apppasswords after enabling 2-Step Verification.'
            );
        }

        throw new RuntimeException('Email could not be sent: ' . $errorInfo, 0, $exception);
    }
}

function fp_send_password_reset_email(array $user, $resetUrl) {
    $name = htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8');
    $safeUrl = htmlspecialchars($resetUrl, ENT_QUOTES, 'UTF-8');
    $subject = 'Reset your Finance Port password';

    $htmlBody = '
        <div style="font-family:Inter,Arial,sans-serif;color:#0F1B34;line-height:1.6;max-width:560px;">
            <p>Dear <strong>' . $name . '</strong>,</p>
            <p>We received a request to reset your Finance Port password. Click the button below to choose a new password. This link expires in 1 hour.</p>
            <p style="margin:28px 0;">
                <a href="' . $safeUrl . '" style="background:#071126;color:#ffffff;text-decoration:none;padding:14px 24px;border-radius:12px;font-weight:700;display:inline-block;">Reset Password</a>
            </p>
            <p style="font-size:14px;color:#64748B;">If you did not request this, you can ignore this email. Your password will stay the same.</p>
            <p style="font-size:14px;color:#64748B;">If the button does not work, copy and paste this link into your browser:<br>' . $safeUrl . '</p>
            <p>Best regards,<br><strong>Finance Port</strong></p>
        </div>';

    return fp_send_mail($user['email'], $user['name'], $subject, $htmlBody);
}
