<script>
document.addEventListener('DOMContentLoaded', function () {
    var navbar = document.querySelector('.navbar-premium');
    if (!navbar) return;

    function updateNavbar() {
        if (window.scrollY > 40) {
            navbar.classList.add('navbar-scrolled');
        } else {
            navbar.classList.remove('navbar-scrolled');
        }
    }

    updateNavbar();
    window.addEventListener('scroll', updateNavbar, { passive: true });
});
</script>
<?php
require_once __DIR__ . '/password_toggle.php';
fp_password_toggle_script();
?>