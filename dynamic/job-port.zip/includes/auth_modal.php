<?php
if (!function_exists('fp_csrf_token')) {
    require_once __DIR__ . '/app.php';
}

$authBasePath = $GLOBALS['basePath'] ?? '';
$authAppBase = fp_app_base_path();
$authLookupUrl = $authBasePath . 'auth/lookup.php';
$authLoginUrl = $authBasePath . 'auth/login.php';
$authSignupUrl = $authBasePath . 'auth/signup.php';
$authCsrf = fp_csrf_token();
?>
<div class="modal fade fp-auth-modal" id="fpAuthModal" tabindex="-1" aria-labelledby="fpAuthModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content fp-auth-modal-content">
            <div class="modal-header border-0 pb-0">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-4 px-md-5 pb-5 pt-0">
                <div class="fp-auth-step" data-step="email">
                    <h2 class="fp-auth-title text-center mb-2" id="fpAuthModalLabel">Log in or sign up</h2>
                    <p class="fp-auth-subtitle text-center mb-4">Access job applications, saved listings, and your Finance Port profile.</p>

                    <div class="d-flex flex-column gap-3">
                        <button type="button" class="fp-auth-social-btn" data-fp-social="google">
                            <span class="fp-auth-social-icon fp-auth-google" aria-hidden="true">G</span>
                            <span>Continue with Google</span>
                        </button>
                        <button type="button" class="fp-auth-social-btn" data-fp-social="apple">
                            <span class="fp-auth-social-icon fp-auth-apple" aria-hidden="true"><i class="fa-brands fa-apple"></i></span>
                            <span>Continue with Apple</span>
                        </button>
                    </div>

                    <div class="fp-auth-divider my-4"><span>OR</span></div>

                    <form id="fpAuthEmailForm" novalidate>
                        <label class="visually-hidden" for="fpAuthEmail">Email address</label>
                        <input class="fp-auth-input form-control" type="email" id="fpAuthEmail" name="email" placeholder="Email address" autocomplete="email" required>
                        <button class="fp-auth-primary-btn w-100 mt-3" type="submit">Continue</button>
                    </form>
                    <p class="fp-auth-note text-center mt-3 mb-0">By continuing, you agree to our <a href="<?php echo fp_url('terms.php'); ?>">Terms</a> and <a href="<?php echo fp_url('privacy.php'); ?>">Privacy Policy</a>.</p>
                </div>

                <div class="fp-auth-step d-none" data-step="login">
                    <button type="button" class="fp-auth-back-btn mb-3" data-fp-auth-back><i class="fa-solid fa-arrow-left"></i> Back</button>
                    <h2 class="fp-auth-title text-center mb-2">Welcome back</h2>
                    <p class="fp-auth-subtitle text-center mb-4">Sign in to <span class="fp-auth-email-display fw-semibold"></span></p>

                    <form id="fpAuthLoginForm" method="post" action="<?php echo e($authLoginUrl); ?>" novalidate>
                        <input type="hidden" name="csrf_token" value="<?php echo e($authCsrf); ?>">
                        <input type="hidden" name="email" id="fpAuthLoginEmail" value="">
                        <input type="hidden" name="return_url" id="fpAuthLoginReturn" value="">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="form-label fw-semibold mb-0" for="fpAuthLoginPassword">Password</label>
                            <a id="fpAuthForgotPasswordLink" class="small fw-semibold text-decoration-none" style="color:#D84000;" href="<?php echo e(fp_forgot_password_url('job_seeker')); ?>">Forgot password?</a>
                        </div>
                        <input class="fp-auth-input form-control" type="password" id="fpAuthLoginPassword" name="password" placeholder="Enter your password" autocomplete="current-password" required>
                        <button class="fp-auth-primary-btn w-100 mt-3" type="submit">Sign In</button>
                    </form>
                </div>

                <div class="fp-auth-step d-none" data-step="signup">
                    <button type="button" class="fp-auth-back-btn mb-3" data-fp-auth-back><i class="fa-solid fa-arrow-left"></i> Back</button>
                    <h2 class="fp-auth-title text-center mb-2">Create your account</h2>
                    <p class="fp-auth-subtitle text-center mb-4">Join Finance Port as <span class="fp-auth-email-display fw-semibold"></span></p>

                    <div class="fp-auth-role-toggle mb-4" role="group" aria-label="Account type">
                        <button type="button" class="fp-auth-role-btn active" data-role="job_seeker">Job Seeker</button>
                        <button type="button" class="fp-auth-role-btn" data-role="employer">Employer</button>
                    </div>

                    <form id="fpAuthSignupForm" method="post" action="<?php echo e($authSignupUrl); ?>" enctype="multipart/form-data" novalidate>
                        <input type="hidden" name="csrf_token" value="<?php echo e($authCsrf); ?>">
                        <input type="hidden" name="email" id="fpAuthSignupEmail" value="">
                        <input type="hidden" name="role" id="fpAuthSignupRole" value="job_seeker">
                        <input type="hidden" name="return_url" id="fpAuthSignupReturn" value="">

                        <div class="mb-3">
                            <label class="form-label fw-semibold" for="fpAuthSignupName">Full name</label>
                            <input class="fp-auth-input form-control" type="text" id="fpAuthSignupName" name="name" placeholder="Your name" required>
                        </div>

                        <div class="mb-3 fp-auth-employer-field d-none">
                            <label class="form-label fw-semibold" for="fpAuthSignupCompany">Company name</label>
                            <input class="fp-auth-input form-control" type="text" id="fpAuthSignupCompany" name="company_name" placeholder="Company or firm name">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold" for="fpAuthSignupPassword">Password</label>
                            <input class="fp-auth-input form-control" type="password" id="fpAuthSignupPassword" name="password" placeholder="At least 8 characters" minlength="8" autocomplete="new-password" required>
                        </div>

                        <div class="mb-3 fp-auth-seeker-field">
                            <label class="form-label fw-semibold" for="fpAuthSignupResume">Resume (optional)</label>
                            <input class="form-control" type="file" id="fpAuthSignupResume" name="resume" accept=".pdf,.doc,.docx">
                            <div class="form-text">PDF, DOC, or DOCX. Max 5 MB.</div>
                        </div>

                        <button class="fp-auth-primary-btn w-100" type="submit">Create Account</button>
                    </form>
                </div>

                <div class="fp-auth-alert alert d-none mt-3 mb-0" role="alert"></div>
            </div>
        </div>
    </div>
</div>

<style>
.fp-auth-modal-content {
    border: none;
    border-radius: 24px;
    box-shadow: 0 20px 40px -10px rgba(13, 43, 78, 0.18);
}
.fp-auth-title {
    font-size: clamp(1.5rem, 4vw, 1.85rem);
    font-weight: 800;
    color: #071126;
    letter-spacing: -0.02em;
}
.fp-auth-subtitle {
    color: #64748B;
    font-size: 0.98rem;
    line-height: 1.6;
}
.fp-auth-social-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    width: 100%;
    padding: 14px 18px;
    border-radius: 999px;
    border: 1px solid #E2E8F0;
    background: #fff;
    color: #071126;
    font-weight: 600;
    transition: all 0.25s ease;
}
.fp-auth-social-btn:hover {
    background: #F8FAFC;
    border-color: #CBD5E1;
}
.fp-auth-social-icon {
    width: 22px;
    height: 22px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 0.95rem;
}
.fp-auth-google {
    background: linear-gradient(135deg, #4285F4, #EA4335 45%, #FBBC05 70%, #34A853);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.fp-auth-apple {
    color: #071126;
    font-size: 1.15rem;
}
.fp-auth-divider {
    display: flex;
    align-items: center;
    gap: 16px;
    color: #94A3B8;
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.08em;
}
.fp-auth-divider::before,
.fp-auth-divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: #E2E8F0;
}
.fp-auth-input {
    border-radius: 999px !important;
    border: 1px solid #E2E8F0 !important;
    padding: 14px 18px !important;
    font-size: 1rem;
}
.fp-auth-input:focus {
    border-color: #D84000 !important;
    box-shadow: 0 0 0 0.15rem rgba(216, 64, 0, 0.12) !important;
}
.fp-auth-primary-btn {
    border: none;
    border-radius: 999px;
    background: #071126;
    color: #fff;
    font-weight: 700;
    padding: 14px 18px;
    transition: all 0.25s ease;
}
.fp-auth-primary-btn:hover {
    background: #D84000;
    color: #fff;
}
.fp-auth-back-btn {
    border: none;
    background: transparent;
    color: #64748B;
    font-weight: 600;
    padding: 0;
}
.fp-auth-back-btn:hover { color: #071126; }
.fp-auth-role-toggle {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    padding: 4px;
    border-radius: 999px;
    background: #F8FAFC;
    border: 1px solid #E2E8F0;
}
.fp-auth-role-btn {
    border: none;
    border-radius: 999px;
    background: transparent;
    color: #64748B;
    font-weight: 700;
    padding: 10px 12px;
}
.fp-auth-role-btn.active {
    background: #071126;
    color: #fff;
}
.fp-auth-note {
    color: #64748B;
    font-size: 0.85rem;
}
.fp-auth-note a { color: #1E63FF; text-decoration: none; font-weight: 600; }
</style>

<script>
(function () {
    function initFpAuthModal() {
    if (window.fpAuthModalInitialized) {
        return;
    }

    const modalEl = document.getElementById('fpAuthModal');
    if (!modalEl || typeof bootstrap === 'undefined') {
        return;
    }

    window.fpAuthModalInitialized = true;

    const lookupUrl = <?php echo json_encode($authLookupUrl); ?>;
    const authAppBase = <?php echo json_encode($authAppBase); ?>;
    const modal = new bootstrap.Modal(modalEl);
    let currentEmail = '';
    let defaultRole = 'job_seeker';
    let returnUrl = '';

    const steps = modalEl.querySelectorAll('.fp-auth-step');
    const alertBox = modalEl.querySelector('.fp-auth-alert');
    const emailForm = document.getElementById('fpAuthEmailForm');
    const loginForm = document.getElementById('fpAuthLoginForm');
    const signupForm = document.getElementById('fpAuthSignupForm');
    const emailInput = document.getElementById('fpAuthEmail');
    const roleInput = document.getElementById('fpAuthSignupRole');
    const roleButtons = modalEl.querySelectorAll('.fp-auth-role-btn');
    const employerField = modalEl.querySelector('.fp-auth-employer-field');
    const seekerField = modalEl.querySelector('.fp-auth-seeker-field');
    const companyInput = document.getElementById('fpAuthSignupCompany');
    const forgotPasswordLink = document.getElementById('fpAuthForgotPasswordLink');
    const forgotPasswordBase = <?php echo json_encode(fp_site_path('forgot-password.php')); ?>;
    let loginRole = 'job_seeker';

    function updateForgotPasswordLink(email, role) {
        if (!forgotPasswordLink) {
            return;
        }

        loginRole = role === 'employer' ? 'employer' : 'job_seeker';
        const params = new URLSearchParams();
        params.set('role', loginRole);
        if (email) {
            params.set('email', email);
        }
        forgotPasswordLink.href = forgotPasswordBase + '?' + params.toString();
    }

    function showAlert(message, type) {
        hideAlert();
        if (window.Swal) {
            window.fpSwalAlert(message, type || 'info');
            return;
        }
        if (!alertBox) return;
        alertBox.textContent = message;
        alertBox.className = 'fp-auth-alert alert alert-' + type + ' mt-3 mb-0';
        alertBox.classList.remove('d-none');
    }

    function hideAlert() {
        if (!alertBox) return;
        alertBox.classList.add('d-none');
    }

    function showStep(stepName) {
        hideAlert();
        steps.forEach(function (step) {
            step.classList.toggle('d-none', step.getAttribute('data-step') !== stepName);
        });
    }

    function resetModal() {
        currentEmail = '';
        showStep('email');
        hideAlert();
        if (emailInput) emailInput.value = '';
        if (loginForm) loginForm.reset();
        if (signupForm) signupForm.reset();
        setRole('job_seeker');
    }

    function setRole(role) {
        defaultRole = role;
        if (roleInput) roleInput.value = role;
        roleButtons.forEach(function (btn) {
            btn.classList.toggle('active', btn.getAttribute('data-role') === role);
        });
        if (employerField) employerField.classList.toggle('d-none', role !== 'employer');
        if (seekerField) seekerField.classList.toggle('d-none', role === 'employer');
        if (companyInput) companyInput.required = role === 'employer';
    }

    function resolveReturnUrl(explicitReturn) {
        if (explicitReturn) {
            return explicitReturn;
        }

        let path = window.location.pathname || '';
        const search = window.location.search || '';

        if (authAppBase && path.indexOf(authAppBase) === 0) {
            path = path.slice(authAppBase.length) || '/';
        }

        path = path.replace(/^\/+/, '');
        if (path === '' || path === 'index.php') {
            return '';
        }

        return path + search;
    }

    function openAuthModal(options) {
        options = options || {};
        resetModal();
        returnUrl = resolveReturnUrl(options.returnUrl || '');
        defaultRole = options.role || 'job_seeker';
        setRole(defaultRole);

        if (options.email && emailInput) {
            emailInput.value = options.email;
        }

        updateForgotPasswordLink(options.email || '', defaultRole);

        if (options.mode === 'signup' && options.email) {
            currentEmail = options.email;
            modalEl.querySelectorAll('.fp-auth-email-display').forEach(function (el) {
                el.textContent = currentEmail;
            });
            document.getElementById('fpAuthSignupEmail').value = currentEmail;
            document.getElementById('fpAuthSignupReturn').value = returnUrl;
            setRole(defaultRole);
            showStep('signup');
        }

        modal.show();
    }

    window.fpOpenAuthModal = openAuthModal;

    document.addEventListener('click', function (event) {
        const trigger = event.target.closest('.fp-open-auth, [data-fp-auth-open]');
        if (!trigger) return;
        event.preventDefault();
        openAuthModal({
            mode: trigger.getAttribute('data-auth-mode') || 'login',
            role: trigger.getAttribute('data-auth-role') || 'job_seeker',
            returnUrl: trigger.getAttribute('data-return-url') || '',
            email: trigger.getAttribute('data-auth-email') || ''
        });
    });

    modalEl.querySelectorAll('[data-fp-social]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            showAlert('Social sign-in is coming soon. Please continue with your email address.', 'info');
        });
    });

    modalEl.querySelectorAll('[data-fp-auth-back]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            showStep('email');
        });
    });

    roleButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            setRole(btn.getAttribute('data-role'));
        });
    });

    if (emailForm) {
        emailForm.addEventListener('submit', function (event) {
            event.preventDefault();
            hideAlert();

            const email = emailInput.value.trim();
            if (!email) {
                showAlert('Enter a valid email address.', 'danger');
                return;
            }

            const body = new URLSearchParams();
            body.set('email', email);
            body.set('csrf_token', <?php echo json_encode($authCsrf); ?>);

            fetch(lookupUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString()
            })
                .then(function (response) { return response.json(); })
                .then(function (data) {
                    if (!data.success) {
                        showAlert(data.message || 'Unable to continue. Please try again.', 'danger');
                        return;
                    }

                    currentEmail = email;
                    modalEl.querySelectorAll('.fp-auth-email-display').forEach(function (el) {
                        el.textContent = email;
                    });

                    if (data.exists) {
                        document.getElementById('fpAuthLoginEmail').value = email;
                        document.getElementById('fpAuthLoginReturn').value = returnUrl;
                        const resolvedRole = data.role === 'employer' ? 'employer' : (data.role === 'job_seeker' ? 'job_seeker' : defaultRole);
                        updateForgotPasswordLink(email, resolvedRole);
                        showStep('login');
                    } else {
                        document.getElementById('fpAuthSignupEmail').value = email;
                        document.getElementById('fpAuthSignupReturn').value = returnUrl;
                        setRole(defaultRole);
                        showStep('signup');
                    }
                })
                .catch(function () {
                    showAlert('Network error. Please try again.', 'danger');
                });
        });
    }

    modalEl.addEventListener('hidden.bs.modal', resetModal);

    if (document.body.getAttribute('data-fp-auth-open') === '1') {
        openAuthModal({
            mode: document.body.getAttribute('data-fp-auth-mode') || 'login',
            role: document.body.getAttribute('data-fp-auth-role') || 'job_seeker',
            email: document.body.getAttribute('data-fp-auth-email') || ''
        });
    }
    }

    document.addEventListener('DOMContentLoaded', initFpAuthModal);
    window.addEventListener('load', initFpAuthModal);
})();
</script>
