<?php
require_once __DIR__ . '/../includes/app.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fp_redirect('../signup.php');
}

fp_require_csrf();

if (fp_get_admin_setting('allow_public_signup', '1') !== '1') {
    fp_flash('danger', 'Public signup is currently disabled. Please contact the platform administrator.');
    fp_redirect('../signup.php');
}

$email = trim($_POST['email'] ?? '');
$name = trim($_POST['name'] ?? '');
$password = (string) ($_POST['password'] ?? '');
$role = trim($_POST['role'] ?? 'job_seeker');
$companyName = trim($_POST['company_name'] ?? '');
$returnUrl = trim($_POST['return_url'] ?? '');

$errors = array();

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'A valid email address is required.';
}

if ($name === '') {
    $errors[] = 'Full name is required.';
}

if (strlen($password) < 8) {
    $errors[] = 'Password must be at least 8 characters.';
}

if (!in_array($role, array('job_seeker', 'employer'), true)) {
    $errors[] = 'Choose a valid account type.';
}

if ($role === 'employer' && $companyName === '') {
    $errors[] = 'Company name is required for employer accounts.';
}

if (empty($errors)) {
    $existing = fp_lookup_user_by_email($email);
    if ($existing) {
        $errors[] = 'An account already exists with this email. Please sign in instead.';
    }
}

if (!empty($errors)) {
    foreach ($errors as $error) {
        fp_flash('danger', $error);
    }
    fp_redirect('../signup.php?email=' . urlencode($email) . '&role=' . urlencode($role));
}

$pdo = fp_db();

try {
    $pdo->beginTransaction();

    $userStatement = $pdo->prepare(
        "INSERT INTO users (role, name, email, password_hash, status)
         VALUES (?, ?, ?, ?, 'active')"
    );
    $userStatement->execute(array(
        $role,
        $name,
        $email,
        password_hash($password, PASSWORD_DEFAULT),
    ));

    $userId = (int) $pdo->lastInsertId();

    if ($role === 'job_seeker') {
        $pdo->prepare(
            'INSERT INTO job_seeker_profiles (user_id, profile_level) VALUES (?, ?)'
        )->execute(array($userId, 'basic'));

        $resume = fp_upload_resume('resume', $userId);
        if ($resume) {
            $pdo->prepare(
                'UPDATE job_seeker_profiles
                 SET resume_file_path = ?, resume_original_name = ?, resume_uploaded_at = NOW()
                 WHERE user_id = ?'
            )->execute(array($resume['path'], $resume['original_name'], $userId));
        }
    } else {
        $pdo->prepare(
            'INSERT INTO employer_profiles (user_id, company_name, contact_person_name, access_level)
             VALUES (?, ?, ?, ?)'
        )->execute(array($userId, $companyName, $name, 'free'));
    }

    $pdo->commit();

    $statement = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $statement->execute(array($userId));
    $user = $statement->fetch();

    fp_login_user($user);
    fp_flash('success', 'Your account is ready.');

    $safeReturn = fp_sanitize_return_url($returnUrl);
    if ($safeReturn !== '') {
        fp_redirect_site($safeReturn);
    }

    fp_redirect_site(fp_auth_redirect_for_role($role));
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    fp_flash('danger', $exception->getMessage());
    fp_redirect('../signup.php?email=' . urlencode($email) . '&role=' . urlencode($role));
}
