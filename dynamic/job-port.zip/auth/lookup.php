<?php
require_once __DIR__ . '/../includes/app.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array('success' => false, 'message' => 'Method not allowed.'));
    exit;
}

if (!fp_verify_csrf()) {
    http_response_code(403);
    echo json_encode(array('success' => false, 'message' => 'Session expired. Refresh the page and try again.'));
    exit;
}

$email = trim($_POST['email'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(array('success' => false, 'message' => 'Enter a valid email address.'));
    exit;
}

$user = fp_lookup_user_by_email($email);

echo json_encode(array(
    'success' => true,
    'exists' => (bool) $user,
    'role' => $user['role'] ?? null,
    'name' => $user['name'] ?? null,
    'status' => $user['status'] ?? null,
));
