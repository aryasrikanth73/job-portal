<?php
require_once __DIR__ . '/../includes/app.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fp_redirect('../login.php');
}

fp_require_csrf();

$email = trim($_POST['email'] ?? '');
$password = (string) ($_POST['password'] ?? '');
$returnUrl = trim($_POST['return_url'] ?? '');

if ($email === '' || $password === '') {
    fp_flash('danger', 'Enter your email and password.');
    fp_redirect('../login.php');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    fp_flash('danger', 'Enter a valid email address.');
    fp_redirect('../login.php?email=' . urlencode($email));
}

$statement = fp_db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
$statement->execute(array($email));
$user = $statement->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    fp_flash('danger', 'Invalid email or password.');
    fp_redirect('../login.php?email=' . urlencode($email));
}

if ($user['role'] === 'admin') {
    fp_flash('info', 'Please use the admin login page.');
    fp_redirect('../admin/login.php');
}

if ($user['status'] !== 'active') {
    fp_flash('danger', 'Your account is not active. Please contact support.');
    fp_redirect('../login.php?email=' . urlencode($email));
}

fp_db()->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?')->execute(array($user['id']));
fp_login_user($user);
fp_flash('success', 'Welcome back, ' . $user['name'] . '.');

$safeReturn = fp_sanitize_return_url($returnUrl);
if ($safeReturn !== '') {
    fp_redirect_site($safeReturn);
}

fp_redirect_site(fp_auth_redirect_for_role($user['role']));
