<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$user = fp_require_login('admin', 'login.php');

$form = array(
    'name' => '',
    'email' => '',
    'phone' => '',
    'password' => '',
    'headline' => '',
    'skills' => '',
    'experience_years' => '0',
    'qualification' => '',
    'current_location' => '',
    'preferred_location' => '',
    'profile_level' => 'basic',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $form = array(
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'password' => (string) ($_POST['password'] ?? ''),
        'headline' => trim($_POST['headline'] ?? ''),
        'skills' => trim($_POST['skills'] ?? ''),
        'experience_years' => trim($_POST['experience_years'] ?? '0'),
        'qualification' => trim($_POST['qualification'] ?? ''),
        'current_location' => trim($_POST['current_location'] ?? ''),
        'preferred_location' => trim($_POST['preferred_location'] ?? ''),
        'profile_level' => trim($_POST['profile_level'] ?? 'basic'),
    );

    try {
        $newUserId = fp_admin_create_jobseeker($form);
        fp_flash('success', 'Job seeker account created successfully.');
        fp_redirect('jobseeker-edit.php?id=' . $newUserId);
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }
}

fp_admin_shell_start('Create Job Seeker', 'users');
?>
<div class="admin-panel-card">
    <div class="page-heading mb-4">
        <div>
            <div class="section-tag">Job Seeker Onboarding</div>
            <h1>Create Job Seeker</h1>
            <p class="muted mb-0">Add a new candidate account and profile.</p>
        </div>
        <a href="users.php?role=job_seeker" class="btn btn-admin-outline">Back to Users</a>
    </div>

    <form method="post" action="jobseeker-create.php" novalidate>
        <?php echo fp_csrf_field(); ?>
        <h2 class="h6 fw-bold mb-3">Account</h2>
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="name">Full name</label>
                <input class="form-control" type="text" id="name" name="name" value="<?php echo e($form['name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="email">Email address</label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo e($form['email']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="phone">Phone (optional)</label>
                <input class="form-control" type="text" id="phone" name="phone" value="<?php echo e($form['phone']); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="password">Temporary password</label>
                <input class="form-control" type="password" id="password" name="password" minlength="8" required>
            </div>
        </div>

        <h2 class="h6 fw-bold mb-3">Profile</h2>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="headline">Headline</label>
                <input class="form-control" type="text" id="headline" name="headline" value="<?php echo e($form['headline']); ?>" placeholder="Senior Accountant">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="profile_level">Profile level</label>
                <select class="form-select" id="profile_level" name="profile_level">
                    <option value="basic" <?php echo $form['profile_level'] === 'basic' ? 'selected' : ''; ?>>Basic</option>
                    <option value="skilled" <?php echo $form['profile_level'] === 'skilled' ? 'selected' : ''; ?>>Skilled</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="skills">Skills</label>
                <input class="form-control" type="text" id="skills" name="skills" value="<?php echo e($form['skills']); ?>" placeholder="Excel, GST, Tally">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="qualification">Qualification</label>
                <input class="form-control" type="text" id="qualification" name="qualification" value="<?php echo e($form['qualification']); ?>" placeholder="B.Com, CA">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="experience_years">Experience (years)</label>
                <input class="form-control" type="number" min="0" step="0.5" id="experience_years" name="experience_years" value="<?php echo e($form['experience_years']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="current_location">Current location</label>
                <input class="form-control" type="text" id="current_location" name="current_location" value="<?php echo e($form['current_location']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="preferred_location">Preferred location</label>
                <input class="form-control" type="text" id="preferred_location" name="preferred_location" value="<?php echo e($form['preferred_location']); ?>">
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2 mt-4">
            <button class="btn btn-admin" type="submit">
                <i class="fa-solid fa-user-plus me-2"></i>Create Job Seeker
            </button>
            <a href="users.php" class="btn btn-admin-outline">Cancel</a>
        </div>
    </form>
</div>
<?php fp_admin_shell_end(); ?>
