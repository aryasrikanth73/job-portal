<?php

require_once __DIR__ . '/../includes/admin_layout.php';



$user = fp_require_login('admin', 'login.php');

$stats = fp_admin_dashboard_stats();



fp_admin_shell_start('Dashboard', 'dashboard');

?>

<div class="admin-panel-card">

    <div class="page-heading mb-4">

        <div>

            <div class="section-tag">Overview</div>

            <h1>Dashboard</h1>

            <p class="muted mb-0">Platform overview and quick actions.</p>

        </div>

    </div>



    <div class="row g-3 mb-4">

        <div class="col-sm-6 col-xl-3">

            <div class="admin-stat-card">

                <div class="label">Total Users</div>

                <div class="value"><?php echo e((string) $stats['users']); ?></div>

            </div>

        </div>

        <div class="col-sm-6 col-xl-3">

            <div class="admin-stat-card">

                <div class="label">Job Seekers</div>

                <div class="value"><?php echo e((string) $stats['job_seekers']); ?></div>

            </div>

        </div>

        <div class="col-sm-6 col-xl-3">

            <div class="admin-stat-card">

                <div class="label">Employers</div>

                <div class="value"><?php echo e((string) $stats['employers']); ?></div>

            </div>

        </div>

        <div class="col-sm-6 col-xl-3">

            <div class="admin-stat-card">

                <div class="label">Blocked Users</div>

                <div class="value"><?php echo e((string) $stats['blocked_users']); ?></div>

            </div>

        </div>

        <div class="col-sm-6 col-xl-4">

            <div class="admin-stat-card">

                <div class="label">Open Jobs</div>

                <div class="value"><?php echo e((string) $stats['open_jobs']); ?></div>

            </div>

        </div>

        <div class="col-sm-6 col-xl-4">

            <div class="admin-stat-card">

                <div class="label">Total Jobs</div>

                <div class="value"><?php echo e((string) $stats['total_jobs']); ?></div>

            </div>

        </div>

        <div class="col-sm-6 col-xl-4">

            <div class="admin-stat-card">

                <div class="label">Applications</div>

                <div class="value"><?php echo e((string) $stats['applications']); ?></div>

            </div>

        </div>

    </div>



    <div class="d-flex flex-wrap gap-2">

        <a href="users.php" class="btn btn-admin"><i class="fa-solid fa-users me-2"></i>Manage Users</a>

        <a href="jobseeker-create.php" class="btn btn-admin-outline"><i class="fa-solid fa-user-plus me-2"></i>Create Job Seeker</a>

        <a href="employer-create.php" class="btn btn-admin-outline"><i class="fa-solid fa-building me-2"></i>Create Employer</a>

        <a href="jobs.php" class="btn btn-admin-outline"><i class="fa-solid fa-briefcase me-2"></i>Manage Jobs</a>

        <a href="job-create.php" class="btn btn-admin-outline"><i class="fa-solid fa-plus me-2"></i>Create Job</a>

        <a href="settings.php" class="btn btn-admin-outline"><i class="fa-solid fa-gear me-2"></i>Settings</a>

    </div>

</div>

<?php fp_admin_shell_end(); ?>

