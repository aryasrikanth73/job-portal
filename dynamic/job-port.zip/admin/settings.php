<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$user = fp_require_login('admin', 'login.php');

$settings = fp_admin_fetch_all_settings();
$form = array(
    'site_name' => $settings['site_name']['setting_value'] ?? 'Finance Port',
    'allow_public_signup' => ($settings['allow_public_signup']['setting_value'] ?? '1') === '1',
    'free_employer_can_view_resume' => ($settings['free_employer_can_view_resume']['setting_value'] ?? '0') === '1',
    'max_resume_upload_mb' => $settings['max_resume_upload_mb']['setting_value'] ?? '5',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $form = array(
        'site_name' => trim($_POST['site_name'] ?? ''),
        'allow_public_signup' => isset($_POST['allow_public_signup']),
        'free_employer_can_view_resume' => isset($_POST['free_employer_can_view_resume']),
        'max_resume_upload_mb' => trim($_POST['max_resume_upload_mb'] ?? '5'),
    );

    try {
        if ($form['site_name'] === '') {
            throw new RuntimeException('Site name is required.');
        }

        $maxMb = (int) $form['max_resume_upload_mb'];
        if ($maxMb < 1 || $maxMb > 20) {
            throw new RuntimeException('Resume upload limit must be between 1 and 20 MB.');
        }

        fp_admin_update_setting('site_name', $form['site_name'], $user['id'], 'string');
        fp_admin_update_setting('allow_public_signup', $form['allow_public_signup'] ? '1' : '0', $user['id'], 'boolean');
        fp_admin_update_setting('free_employer_can_view_resume', $form['free_employer_can_view_resume'] ? '1' : '0', $user['id'], 'boolean');
        fp_admin_update_setting('max_resume_upload_mb', (string) $maxMb, $user['id'], 'number');

        fp_flash('success', 'Settings saved successfully.');
        fp_redirect('settings.php');
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }
}

fp_admin_shell_start('Settings', 'settings');
?>
<div class="admin-panel-card">
    <div class="page-heading mb-4">
        <div>
            <div class="section-tag">Platform Settings</div>
            <h1>Settings</h1>
            <p class="muted mb-0">Basic system configuration for the job portal.</p>
        </div>
    </div>

    <form method="post" action="settings.php" novalidate>
        <?php echo fp_csrf_field(); ?>

        <div class="row g-4">
            <div class="col-lg-8">
                <label class="form-label fw-semibold" for="site_name">Site name</label>
                <input class="form-control" type="text" id="site_name" name="site_name" value="<?php echo e($form['site_name']); ?>" required>
            </div>

            <div class="col-lg-4">
                <label class="form-label fw-semibold" for="max_resume_upload_mb">Max resume upload (MB)</label>
                <input class="form-control" type="number" min="1" max="20" id="max_resume_upload_mb" name="max_resume_upload_mb" value="<?php echo e((string) $form['max_resume_upload_mb']); ?>" required>
            </div>

            <div class="col-12">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="allow_public_signup" name="allow_public_signup" <?php echo $form['allow_public_signup'] ? 'checked' : ''; ?>>
                    <label class="form-check-label fw-semibold" for="allow_public_signup">Allow public signup</label>
                    <div class="form-text">When disabled, only admin-created accounts can access the platform.</div>
                </div>
            </div>

            <div class="col-12">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="free_employer_can_view_resume" name="free_employer_can_view_resume" <?php echo $form['free_employer_can_view_resume'] ? 'checked' : ''; ?>>
                    <label class="form-check-label fw-semibold" for="free_employer_can_view_resume">Free employers can view resumes</label>
                    <div class="form-text">By default, only paid employers can download candidate resumes.</div>
                </div>
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2 mt-4">
            <button class="btn btn-admin" type="submit">
                <i class="fa-solid fa-floppy-disk me-2"></i>Save Settings
            </button>
        </div>
    </form>
</div>
<?php fp_admin_shell_end(); ?>
