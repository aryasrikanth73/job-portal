<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$existingUser = fp_current_user();
if ($existingUser && $existingUser['role'] === 'admin' && $existingUser['status'] === 'active') {
    fp_redirect('dashboard.php');
}

$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        fp_flash('danger', 'Enter your email and password.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fp_flash('danger', 'Enter a valid email address.');
    } else {
        $statement = fp_db()->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin' LIMIT 1");
        $statement->execute(array($email));
        $user = $statement->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            fp_flash('danger', 'Invalid admin credentials.');
        } elseif ($user['status'] !== 'active') {
            fp_flash('danger', 'This admin account is not active.');
        } else {
            fp_db()->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?')->execute(array($user['id']));
            fp_login_user($user);
            fp_flash('success', 'Welcome back, ' . $user['name'] . '.');
            fp_redirect('dashboard.php');
        }
    }
}

fp_admin_page_start('Admin Login');
?>
<div class="admin-login-shell">
    <a class="admin-brand" href="../index.php">
        <span class="admin-brand-dot"></span>
        Finance Port
    </a>

    <div class="admin-login-card">
        <div class="admin-login-badge">Admin Panel</div>
        <h1 class="h3 mb-2">Admin Login</h1>
        <p class="muted mb-4">Sign in to manage users, jobs, and platform settings.</p>

        <?php fp_admin_render_flashes(); ?>

        <form method="post" action="login.php" novalidate>
            <?php echo fp_csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label fw-semibold" for="email">Email address</label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo e($email); ?>" placeholder="admin@financeport.com" autocomplete="username" required>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold" for="password">Password</label>
                <input class="form-control" type="password" id="password" name="password" placeholder="Enter your password" autocomplete="current-password" required>
            </div>
            <button class="btn btn-admin" type="submit">
                <i class="fa-solid fa-shield-halved me-2"></i>
                Sign In
            </button>
        </form>

        <p class="muted small mt-4 mb-0 text-center">
            Admin accounts are created by the platform operator only. No public signup is available.
        </p>
    </div>
</div>
<?php fp_admin_page_end(); ?>
