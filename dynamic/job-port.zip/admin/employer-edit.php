<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$admin = fp_require_login('admin', 'login.php');
$userId = (int) ($_GET['id'] ?? 0);
$record = $userId > 0 ? fp_admin_fetch_employer($userId) : null;

if (!$record) {
    fp_flash('danger', 'Employer not found.');
    fp_redirect('users.php?role=employer');
}

$form = array(
    'name' => $record['name'],
    'email' => $record['email'],
    'phone' => $record['phone'] ?? '',
    'status' => $record['status'],
    'blocked_reason' => $record['blocked_reason'] ?? '',
    'company_name' => $record['company_name'] ?? '',
    'company_website' => $record['company_website'] ?? '',
    'industry' => $record['industry'] ?? '',
    'company_size' => $record['company_size'] ?? '',
    'contact_person_name' => $record['contact_person_name'] ?? '',
    'contact_designation' => $record['contact_designation'] ?? '',
    'address_line' => $record['address_line'] ?? '',
    'city' => $record['city'] ?? '',
    'state' => $record['state'] ?? '',
    'country' => $record['country'] ?? 'India',
    'access_level' => $record['access_level'] ?? 'free',
    'is_verified' => !empty($record['is_verified']),
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();
    $action = $_POST['action'] ?? 'save';

    if ($action === 'delete') {
        try {
            if (fp_admin_delete_user($userId, $admin['id'])) {
                fp_flash('success', 'Employer deleted successfully.');
                fp_redirect('users.php?role=employer');
            }
            fp_flash('warning', 'Unable to delete this employer.');
        } catch (Throwable $exception) {
            fp_flash('danger', $exception->getMessage());
        }
        fp_redirect('employer-edit.php?id=' . $userId);
    }

    foreach (array_keys($form) as $key) {
        if ($key === 'is_verified') {
            $form[$key] = isset($_POST['is_verified']);
        } elseif ($key !== 'blocked_reason') {
            $form[$key] = trim($_POST[$key] ?? '');
        }
    }
    $form['blocked_reason'] = trim($_POST['blocked_reason'] ?? '');
    $form['password'] = (string) ($_POST['password'] ?? '');

    try {
        fp_admin_update_employer($userId, $form, $admin['id']);
        fp_flash('success', 'Employer updated successfully.');
        fp_redirect('employer-edit.php?id=' . $userId);
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }
}

$record = fp_admin_fetch_employer($userId);
$jobCount = fp_count_employer_jobs((int) $record['id']);

fp_admin_shell_start('Edit Employer', 'users');
?>
<div class="admin-panel-card mb-3">
    <div class="page-heading mb-4">
        <div>
            <div class="section-tag">Employer</div>
            <h1><?php echo e($record['company_name']); ?></h1>
            <p class="muted mb-0">
                <?php echo e((string) $jobCount); ?> job listing<?php echo $jobCount === 1 ? '' : 's'; ?>
                · Member since <?php echo e(date('M j, Y', strtotime($record['created_at']))); ?>
            </p>
        </div>
        <a href="users.php?role=employer" class="btn btn-admin-outline">Back to Users</a>
    </div>

    <form method="post" action="employer-edit.php?id=<?php echo $userId; ?>" novalidate>
        <?php echo fp_csrf_field(); ?>
        <input type="hidden" name="action" value="save">

        <h2 class="h6 fw-bold mb-3">Account</h2>
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="name">Account name</label>
                <input class="form-control" type="text" id="name" name="name" value="<?php echo e($form['name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="email">Email address</label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo e($form['email']); ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="phone">Phone</label>
                <input class="form-control" type="text" id="phone" name="phone" value="<?php echo e($form['phone']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="status">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="active" <?php echo $form['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="blocked" <?php echo $form['status'] === 'blocked' ? 'selected' : ''; ?>>Blocked</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="access_level">Access level</label>
                <select class="form-select" id="access_level" name="access_level">
                    <option value="free" <?php echo $form['access_level'] === 'free' ? 'selected' : ''; ?>>Free</option>
                    <option value="paid" <?php echo $form['access_level'] === 'paid' ? 'selected' : ''; ?>>Paid</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="password">New password</label>
                <input class="form-control" type="password" id="password" name="password" minlength="8" placeholder="Leave blank to keep current">
            </div>
            <div class="col-md-6 d-flex align-items-end">
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" id="is_verified" name="is_verified" <?php echo $form['is_verified'] ? 'checked' : ''; ?>>
                    <label class="form-check-label fw-semibold" for="is_verified">Verified employer</label>
                </div>
            </div>
            <div class="col-12">
                <label class="form-label fw-semibold" for="blocked_reason">Block reason (optional)</label>
                <input class="form-control" type="text" id="blocked_reason" name="blocked_reason" value="<?php echo e($form['blocked_reason']); ?>">
            </div>
        </div>

        <h2 class="h6 fw-bold mb-3">Company profile</h2>
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="company_name">Company name</label>
                <input class="form-control" type="text" id="company_name" name="company_name" value="<?php echo e($form['company_name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="company_website">Website</label>
                <input class="form-control" type="url" id="company_website" name="company_website" value="<?php echo e($form['company_website']); ?>" placeholder="https://">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="industry">Industry</label>
                <input class="form-control" type="text" id="industry" name="industry" value="<?php echo e($form['industry']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="company_size">Company size</label>
                <input class="form-control" type="text" id="company_size" name="company_size" value="<?php echo e($form['company_size']); ?>" placeholder="51-200">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="contact_person_name">Contact person</label>
                <input class="form-control" type="text" id="contact_person_name" name="contact_person_name" value="<?php echo e($form['contact_person_name']); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="contact_designation">Contact designation</label>
                <input class="form-control" type="text" id="contact_designation" name="contact_designation" value="<?php echo e($form['contact_designation']); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="address_line">Address</label>
                <input class="form-control" type="text" id="address_line" name="address_line" value="<?php echo e($form['address_line']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="city">City</label>
                <input class="form-control" type="text" id="city" name="city" value="<?php echo e($form['city']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="state">State</label>
                <input class="form-control" type="text" id="state" name="state" value="<?php echo e($form['state']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="country">Country</label>
                <input class="form-control" type="text" id="country" name="country" value="<?php echo e($form['country']); ?>">
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2">
            <button class="btn btn-admin" type="submit">
                <i class="fa-solid fa-floppy-disk me-2"></i>Save Changes
            </button>
            <a href="jobs.php?employer_id=<?php echo (int) $record['id']; ?>" class="btn btn-admin-outline">View Jobs</a>
            <a href="job-create.php" class="btn btn-admin-outline">Post Job</a>
        </div>
    </form>
</div>

<div class="admin-panel-card border-danger-subtle">
    <h2 class="h6 fw-bold text-danger mb-2">Danger zone</h2>
    <p class="muted small mb-3">Deleting removes this employer from the platform. Their job listings will cascade per database rules.</p>
    <form method="post" action="employer-edit.php?id=<?php echo $userId; ?>" data-fp-confirm="Permanently delete this employer and their data? This cannot be undone.">
        <?php echo fp_csrf_field(); ?>
        <input type="hidden" name="action" value="delete">
        <button class="btn btn-admin-danger" type="submit">
            <i class="fa-solid fa-trash me-2"></i>Delete Employer
        </button>
    </form>
</div>
<?php fp_admin_shell_end(); ?>
