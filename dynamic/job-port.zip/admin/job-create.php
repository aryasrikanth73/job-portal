<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$user = fp_require_login('admin', 'login.php');

$employers = fp_admin_fetch_employers_for_select();
$jobForm = array(
    'employer_id' => '',
    'title' => '',
    'short_description' => '',
    'description' => '',
    'responsibilities' => '',
    'requirements' => '',
    'skills_required' => '',
    'qualification_required' => '',
    'category_id' => '',
    'location' => '',
    'openings' => '1',
    'job_type' => 'full_time',
    'workplace_type' => 'onsite',
    'application_deadline' => '',
    'experience_min_years' => '0',
    'experience_max_years' => '',
    'salary_min' => '',
    'salary_max' => '',
    'status' => 'open',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $employerId = (int) ($_POST['employer_id'] ?? 0);
    $jobForm = array_merge($jobForm, array(
        'employer_id' => (string) $employerId,
        'title' => trim($_POST['title'] ?? ''),
        'short_description' => trim($_POST['short_description'] ?? ''),
        'description' => trim($_POST['description'] ?? ''),
        'responsibilities' => trim($_POST['responsibilities'] ?? ''),
        'requirements' => trim($_POST['requirements'] ?? ''),
        'skills_required' => trim($_POST['skills_required'] ?? ''),
        'qualification_required' => trim($_POST['qualification_required'] ?? ''),
        'category_id' => trim($_POST['category_id'] ?? ''),
        'location' => trim($_POST['location'] ?? ''),
        'openings' => trim($_POST['openings'] ?? '1'),
        'job_type' => trim($_POST['job_type'] ?? 'full_time'),
        'workplace_type' => trim($_POST['workplace_type'] ?? 'onsite'),
        'application_deadline' => trim($_POST['application_deadline'] ?? ''),
        'experience_min_years' => trim($_POST['experience_min_years'] ?? '0'),
        'experience_max_years' => trim($_POST['experience_max_years'] ?? ''),
        'salary_min' => trim($_POST['salary_min'] ?? ''),
        'salary_max' => trim($_POST['salary_max'] ?? ''),
        'status' => trim($_POST['status'] ?? 'open'),
    ));

    try {
        if ($employerId <= 0) {
            throw new RuntimeException('Select an employer for this job.');
        }

        $employerExists = false;
        foreach ($employers as $employer) {
            if ((int) $employer['id'] === $employerId) {
                $employerExists = true;
                break;
            }
        }

        if (!$employerExists) {
            throw new RuntimeException('Selected employer is not available.');
        }

        $jobId = fp_save_job($employerId, $user['id'], $jobForm);
        fp_flash('success', 'Job created successfully.');
        fp_redirect('jobs.php?q=' . urlencode($jobForm['title']));
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }
}

fp_admin_shell_start('Create Job', 'jobs');
?>
<div class="admin-panel-card">
    <div class="page-heading mb-4">
        <div>
            <div class="section-tag">Job Posting</div>
            <h1>Create Job</h1>
            <p class="muted mb-0">Publish a vacancy on behalf of an employer.</p>
        </div>
        <a href="jobs.php" class="btn btn-admin-outline">Back to Jobs</a>
    </div>

    <?php if (empty($employers)): ?>
        <div class="empty-card">
            <i class="fa-solid fa-building d-block"></i>
            <h2 class="h5">No active employers</h2>
            <p class="muted mb-3">Create an employer account before posting a job.</p>
            <a href="employer-create.php" class="btn btn-admin">Create Employer</a>
        </div>
    <?php else: ?>
        <form method="post" action="job-create.php" novalidate>
            <?php echo fp_csrf_field(); ?>
            <div class="mb-4">
                <label class="form-label fw-semibold" for="employer_id">Employer</label>
                <select class="form-select" id="employer_id" name="employer_id" required>
                    <option value="">Select employer</option>
                    <?php foreach ($employers as $employer): ?>
                        <option value="<?php echo (int) $employer['id']; ?>" <?php echo (string) $jobForm['employer_id'] === (string) $employer['id'] ? 'selected' : ''; ?>>
                            <?php echo e($employer['company_name']); ?> — <?php echo e($employer['email']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <?php
            $form = $jobForm;
            require __DIR__ . '/../includes/partials/employer_job_form.php';
            ?>

            <div class="d-flex flex-wrap gap-2 mt-4">
                <button class="btn btn-admin" type="submit">
                    <i class="fa-solid fa-briefcase me-2"></i>Create Job
                </button>
                <a href="jobs.php" class="btn btn-admin-outline">Cancel</a>
            </div>
        </form>
    <?php endif; ?>
</div>
<?php fp_admin_shell_end(); ?>
