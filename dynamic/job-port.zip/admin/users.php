<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$user = fp_require_login('admin', 'login.php');

$filters = fp_admin_build_user_filters($_GET);
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$totalUsers = fp_admin_count_users($filters);
$totalPages = max(1, (int) ceil($totalUsers / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $perPage;
}

$users = fp_admin_fetch_users($filters, $perPage, $offset);

fp_admin_shell_start('Manage Users', 'users');
?>
<div class="admin-panel-card">
    <div class="page-heading">
        <div>
            <div class="section-tag">User Management</div>
            <h1>Manage Users</h1>
            <p class="muted mb-0"><?php echo e((string) $totalUsers); ?> user<?php echo $totalUsers === 1 ? '' : 's'; ?> found</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="jobseeker-create.php" class="btn btn-admin-outline">
                <i class="fa-solid fa-user-plus me-2"></i>Create Job Seeker
            </a>
            <a href="employer-create.php" class="btn btn-admin">
                <i class="fa-solid fa-building me-2"></i>Create Employer
            </a>
        </div>
    </div>

    <form class="admin-filter-bar" method="get" action="users.php">
        <select class="form-select" name="role" style="max-width:180px;">
            <option value="">All roles</option>
            <option value="job_seeker" <?php echo $filters['role'] === 'job_seeker' ? 'selected' : ''; ?>>Job Seekers</option>
            <option value="employer" <?php echo $filters['role'] === 'employer' ? 'selected' : ''; ?>>Employers</option>
        </select>
        <select class="form-select" name="status" style="max-width:180px;">
            <option value="">All statuses</option>
            <option value="active" <?php echo $filters['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
            <option value="blocked" <?php echo $filters['status'] === 'blocked' ? 'selected' : ''; ?>>Blocked</option>
        </select>
        <input class="form-control" type="search" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Search name or email" style="max-width:260px;">
        <button class="btn btn-admin" type="submit">Filter</button>
        <?php if ($filters['role'] !== '' || $filters['status'] !== '' || $filters['q'] !== ''): ?>
            <a href="users.php" class="btn btn-admin-outline">Clear</a>
        <?php endif; ?>
    </form>

    <?php if (empty($users)): ?>
        <div class="empty-card">
            <i class="fa-solid fa-users d-block"></i>
            <h2 class="h5">No users found</h2>
            <p class="muted mb-3">Try adjusting your filters or create a new account.</p>
            <div class="d-flex flex-wrap gap-2 justify-content-center">
                <a href="jobseeker-create.php" class="btn btn-admin-outline">Create Job Seeker</a>
                <a href="employer-create.php" class="btn btn-admin">Create Employer</a>
            </div>
        </div>
    <?php else: ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Role</th>
                        <th>Details</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $row): ?>
                        <?php
                        $editUrl = $row['role'] === 'employer'
                            ? 'employer-edit.php?id=' . (int) $row['id']
                            : 'jobseeker-edit.php?id=' . (int) $row['id'];
                        ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?php echo e($row['name']); ?></div>
                                <div class="small muted"><?php echo e($row['email']); ?></div>
                            </td>
                            <td><?php echo e(fp_format_user_role($row['role'])); ?></td>
                            <td>
                                <?php if ($row['role'] === 'employer'): ?>
                                    <div class="small"><?php echo e($row['company_name'] ?? '—'); ?></div>
                                    <div class="small muted text-capitalize"><?php echo e($row['access_level'] ?? 'free'); ?> plan</div>
                                <?php else: ?>
                                    <div class="small"><?php echo e($row['current_location'] ?? '—'); ?></div>
                                    <div class="small muted text-capitalize"><?php echo e($row['profile_level'] ?? 'basic'); ?> profile</div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="status-pill <?php echo e(fp_user_status_badge_class($row['status'])); ?>">
                                    <?php echo e(ucfirst($row['status'])); ?>
                                </span>
                            </td>
                            <td class="small muted"><?php echo e(date('M j, Y', strtotime($row['created_at']))); ?></td>
                            <td>
                                <a href="<?php echo e($editUrl); ?>" class="btn btn-sm btn-admin">
                                    <i class="fa-solid fa-pen me-1"></i>Edit
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
            <div class="d-flex justify-content-between align-items-center mt-4">
                <span class="small muted">Page <?php echo e((string) $page); ?> of <?php echo e((string) $totalPages); ?></span>
                <div class="d-flex gap-2">
                    <?php
                    $baseQuery = array_filter(array(
                        'role' => $filters['role'] !== '' ? $filters['role'] : null,
                        'status' => $filters['status'] !== '' ? $filters['status'] : null,
                        'q' => $filters['q'] !== '' ? $filters['q'] : null,
                    ));
                    ?>
                    <?php if ($page > 1): ?>
                        <?php $prevQuery = http_build_query(array_merge($baseQuery, array('page' => $page - 1))); ?>
                        <a href="users.php?<?php echo e($prevQuery); ?>" class="btn btn-sm btn-admin-outline">Previous</a>
                    <?php endif; ?>
                    <?php if ($page < $totalPages): ?>
                        <?php $nextQuery = http_build_query(array_merge($baseQuery, array('page' => $page + 1))); ?>
                        <a href="users.php?<?php echo e($nextQuery); ?>" class="btn btn-sm btn-admin-outline">Next</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php fp_admin_shell_end(); ?>
