<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$user = fp_require_login('admin', 'login.php');

$filters = fp_admin_build_job_filters($_GET);
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $action = $_POST['action'] ?? '';
    $jobId = (int) ($_POST['job_id'] ?? 0);
    $redirectQuery = http_build_query(array_filter(array(
        'status' => $filters['status'] !== '' ? $filters['status'] : null,
        'employer_id' => $filters['employer_id'] > 0 ? $filters['employer_id'] : null,
        'q' => $filters['q'] !== '' ? $filters['q'] : null,
        'page' => $page > 1 ? $page : null,
    )));

    try {
        if ($action === 'delete') {
            if (fp_admin_delete_job($jobId, $user['id'])) {
                fp_flash('success', 'Job deleted successfully.');
            } else {
                fp_flash('warning', 'Unable to delete that job.');
            }
        } else {
            fp_flash('warning', 'Unknown action.');
        }
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }

    fp_redirect('jobs.php' . ($redirectQuery !== '' ? '?' . $redirectQuery : ''));
}

$totalJobs = fp_admin_count_jobs($filters);
$totalPages = max(1, (int) ceil($totalJobs / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $perPage;
}

$jobs = fp_admin_fetch_jobs($filters, $perPage, $offset);
$employers = fp_admin_fetch_employers_for_select();

fp_admin_shell_start('Manage Jobs', 'jobs');
?>
<div class="admin-panel-card">
    <div class="page-heading">
        <div>
            <div class="section-tag">Job Management</div>
            <h1>Manage Jobs</h1>
            <p class="muted mb-0"><?php echo e((string) $totalJobs); ?> job<?php echo $totalJobs === 1 ? '' : 's'; ?> found</p>
        </div>
        <a href="job-create.php" class="btn btn-admin">
            <i class="fa-solid fa-plus me-2"></i>Create Job
        </a>
    </div>

    <form class="admin-filter-bar" method="get" action="jobs.php">
        <select class="form-select" name="status" style="max-width:160px;">
            <option value="">All statuses</option>
            <option value="open" <?php echo $filters['status'] === 'open' ? 'selected' : ''; ?>>Open</option>
            <option value="draft" <?php echo $filters['status'] === 'draft' ? 'selected' : ''; ?>>Draft</option>
            <option value="closed" <?php echo $filters['status'] === 'closed' ? 'selected' : ''; ?>>Closed</option>
        </select>
        <select class="form-select" name="employer_id" style="max-width:220px;">
            <option value="">All employers</option>
            <?php foreach ($employers as $employer): ?>
                <option value="<?php echo (int) $employer['id']; ?>" <?php echo $filters['employer_id'] === (int) $employer['id'] ? 'selected' : ''; ?>>
                    <?php echo e($employer['company_name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <input class="form-control" type="search" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Search title, location, company" style="max-width:280px;">
        <button class="btn btn-admin" type="submit">Filter</button>
        <?php if ($filters['status'] !== '' || $filters['employer_id'] > 0 || $filters['q'] !== ''): ?>
            <a href="jobs.php" class="btn btn-admin-outline">Clear</a>
        <?php endif; ?>
    </form>

    <?php if (empty($jobs)): ?>
        <div class="empty-card">
            <i class="fa-solid fa-briefcase d-block"></i>
            <h2 class="h5">No jobs found</h2>
            <p class="muted mb-3">Create a job posting or adjust your filters.</p>
            <a href="job-create.php" class="btn btn-admin">Create Job</a>
        </div>
    <?php else: ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Job</th>
                        <th>Employer</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Applications</th>
                        <th>Posted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($jobs as $job): ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?php echo e($job['title']); ?></div>
                                <div class="small muted"><?php echo e(fp_format_job_type($job['job_type'])); ?></div>
                            </td>
                            <td><?php echo e($job['company_name']); ?></td>
                            <td><?php echo e($job['location']); ?></td>
                            <td>
                                <span class="status-pill <?php echo e(fp_job_status_badge_class($job['status'])); ?>">
                                    <?php echo e(fp_format_job_status($job['status'])); ?>
                                </span>
                            </td>
                            <td><?php echo e((string) ($job['application_count'] ?? 0)); ?></td>
                            <td class="small muted">
                                <?php echo $job['posted_at'] ? e(date('M j, Y', strtotime($job['posted_at']))) : '—'; ?>
                            </td>
                            <td>
                                <div class="d-flex flex-wrap gap-2">
                                    <a href="../job-details.php?id=<?php echo (int) $job['id']; ?>" class="btn btn-sm btn-admin-outline" target="_blank" rel="noopener">View</a>
                                    <form method="post" class="d-inline" data-fp-confirm="Delete this job? This cannot be undone.">
                                        <?php echo fp_csrf_field(); ?>
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="job_id" value="<?php echo (int) $job['id']; ?>">
                                        <button class="btn btn-sm btn-admin-danger" type="submit">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
            <div class="d-flex justify-content-between align-items-center mt-4">
                <span class="small muted">Page <?php echo e((string) $page); ?> of <?php echo e((string) $totalPages); ?></span>
                <div class="d-flex gap-2">
                    <?php
                    $baseQuery = array_filter(array(
                        'status' => $filters['status'] !== '' ? $filters['status'] : null,
                        'employer_id' => $filters['employer_id'] > 0 ? $filters['employer_id'] : null,
                        'q' => $filters['q'] !== '' ? $filters['q'] : null,
                    ));
                    ?>
                    <?php if ($page > 1): ?>
                        <?php $prevQuery = http_build_query(array_merge($baseQuery, array('page' => $page - 1))); ?>
                        <a href="jobs.php?<?php echo e($prevQuery); ?>" class="btn btn-sm btn-admin-outline">Previous</a>
                    <?php endif; ?>
                    <?php if ($page < $totalPages): ?>
                        <?php $nextQuery = http_build_query(array_merge($baseQuery, array('page' => $page + 1))); ?>
                        <a href="jobs.php?<?php echo e($nextQuery); ?>" class="btn btn-sm btn-admin-outline">Next</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php fp_admin_shell_end(); ?>
