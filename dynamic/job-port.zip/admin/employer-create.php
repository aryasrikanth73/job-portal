<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$user = fp_require_login('admin', 'login.php');

$form = array(
    'name' => '',
    'email' => '',
    'phone' => '',
    'company_name' => '',
    'access_level' => 'free',
    'password' => '',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();

    $form = array(
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'company_name' => trim($_POST['company_name'] ?? ''),
        'access_level' => trim($_POST['access_level'] ?? 'free'),
        'password' => (string) ($_POST['password'] ?? ''),
    );

    try {
        $newUserId = fp_admin_create_employer($form);
        fp_flash('success', 'Employer account created successfully.');
        fp_redirect('employer-edit.php?id=' . $newUserId);
    } catch (Throwable $exception) {
        fp_flash('danger', $exception->getMessage());
    }
}

fp_admin_shell_start('Create Employer', 'users');
?>
<div class="admin-panel-card">
    <div class="page-heading mb-4">
        <div>
            <div class="section-tag">Employer Onboarding</div>
            <h1>Create Employer</h1>
            <p class="muted mb-0">Add a new employer account and company profile.</p>
        </div>
        <a href="users.php?role=employer" class="btn btn-admin-outline">Back to Users</a>
    </div>

    <form method="post" action="employer-create.php" novalidate>
        <?php echo fp_csrf_field(); ?>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="company_name">Company name</label>
                <input class="form-control" type="text" id="company_name" name="company_name" value="<?php echo e($form['company_name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="access_level">Access level</label>
                <select class="form-select" id="access_level" name="access_level">
                    <option value="free" <?php echo $form['access_level'] === 'free' ? 'selected' : ''; ?>>Free</option>
                    <option value="paid" <?php echo $form['access_level'] === 'paid' ? 'selected' : ''; ?>>Paid</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="name">Contact person</label>
                <input class="form-control" type="text" id="name" name="name" value="<?php echo e($form['name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="phone">Phone (optional)</label>
                <input class="form-control" type="text" id="phone" name="phone" value="<?php echo e($form['phone']); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="email">Email address</label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo e($form['email']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="password">Temporary password</label>
                <input class="form-control" type="password" id="password" name="password" minlength="8" required>
                <div class="form-text">Minimum 8 characters. Share securely with the employer.</div>
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2 mt-4">
            <button class="btn btn-admin" type="submit">
                <i class="fa-solid fa-building me-2"></i>Create Employer
            </button>
            <a href="users.php" class="btn btn-admin-outline">Cancel</a>
        </div>
    </form>
</div>
<?php fp_admin_shell_end(); ?>
