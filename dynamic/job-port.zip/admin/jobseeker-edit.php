<?php
require_once __DIR__ . '/../includes/admin_layout.php';

$admin = fp_require_login('admin', 'login.php');
$userId = (int) ($_GET['id'] ?? 0);
$record = $userId > 0 ? fp_admin_fetch_jobseeker($userId) : null;

if (!$record) {
    fp_flash('danger', 'Job seeker not found.');
    fp_redirect('users.php?role=job_seeker');
}

$form = array(
    'name' => $record['name'],
    'email' => $record['email'],
    'phone' => $record['phone'] ?? '',
    'status' => $record['status'],
    'blocked_reason' => $record['blocked_reason'] ?? '',
    'headline' => $record['headline'] ?? '',
    'skills' => $record['skills'] ?? '',
    'experience_years' => (string) ($record['experience_years'] ?? '0'),
    'qualification' => $record['qualification'] ?? '',
    'current_location' => $record['current_location'] ?? '',
    'preferred_location' => $record['preferred_location'] ?? '',
    'profile_level' => $record['profile_level'] ?? 'basic',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    fp_require_csrf();
    $action = $_POST['action'] ?? 'save';

    if ($action === 'delete') {
        try {
            if (fp_admin_delete_user($userId, $admin['id'])) {
                fp_flash('success', 'Job seeker deleted successfully.');
                fp_redirect('users.php?role=job_seeker');
            }
            fp_flash('warning', 'Unable to delete this job seeker.');
        } catch (Throwable $exception) {
            fp_flash('danger', $exception->getMessage());
        }
        fp_redirect('jobseeker-edit.php?id=' . $userId);
    }

    if ($action === 'resume') {
        try {
            $resume = fp_upload_resume('resume', $userId);
            if (!$resume) {
                fp_flash('warning', 'Choose a resume file to upload.');
            } else {
                fp_db()->prepare(
                    'UPDATE job_seeker_profiles
                     SET resume_file_path = ?, resume_original_name = ?, resume_uploaded_at = NOW()
                     WHERE user_id = ?'
                )->execute(array($resume['path'], $resume['original_name'], $userId));
                fp_flash('success', 'Resume uploaded successfully.');
                fp_redirect('jobseeker-edit.php?id=' . $userId);
            }
        } catch (Throwable $exception) {
            fp_flash('danger', $exception->getMessage());
        }
    } else {
        foreach (array_keys($form) as $key) {
            if ($key !== 'blocked_reason') {
                $form[$key] = trim($_POST[$key] ?? '');
            }
        }
        $form['blocked_reason'] = trim($_POST['blocked_reason'] ?? '');
        $form['password'] = (string) ($_POST['password'] ?? '');

        try {
            fp_admin_update_jobseeker($userId, $form, $admin['id']);
            fp_flash('success', 'Job seeker updated successfully.');
            fp_redirect('jobseeker-edit.php?id=' . $userId);
        } catch (Throwable $exception) {
            fp_flash('danger', $exception->getMessage());
        }
    }
}

$record = fp_admin_fetch_jobseeker($userId);
$hasResume = !empty($record['resume_file_path']);

fp_admin_shell_start('Edit Job Seeker', 'users');
?>
<div class="admin-panel-card mb-3">
    <div class="page-heading mb-4">
        <div>
            <div class="section-tag">Job Seeker</div>
            <h1><?php echo e($record['name']); ?></h1>
            <p class="muted mb-0">
                Member since <?php echo e(date('M j, Y', strtotime($record['created_at']))); ?>
                <?php if ($record['last_login_at']): ?>
                    · Last login <?php echo e(date('M j, Y', strtotime($record['last_login_at']))); ?>
                <?php endif; ?>
            </p>
        </div>
        <a href="users.php?role=job_seeker" class="btn btn-admin-outline">Back to Users</a>
    </div>

    <form method="post" action="jobseeker-edit.php?id=<?php echo $userId; ?>" novalidate>
        <?php echo fp_csrf_field(); ?>
        <input type="hidden" name="action" value="save">

        <h2 class="h6 fw-bold mb-3">Account</h2>
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="name">Full name</label>
                <input class="form-control" type="text" id="name" name="name" value="<?php echo e($form['name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="email">Email address</label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo e($form['email']); ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="phone">Phone</label>
                <input class="form-control" type="text" id="phone" name="phone" value="<?php echo e($form['phone']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="status">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="active" <?php echo $form['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="blocked" <?php echo $form['status'] === 'blocked' ? 'selected' : ''; ?>>Blocked</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="password">New password</label>
                <input class="form-control" type="password" id="password" name="password" minlength="8" placeholder="Leave blank to keep current">
            </div>
            <div class="col-12">
                <label class="form-label fw-semibold" for="blocked_reason">Block reason (optional)</label>
                <input class="form-control" type="text" id="blocked_reason" name="blocked_reason" value="<?php echo e($form['blocked_reason']); ?>" placeholder="Only used when status is blocked">
            </div>
        </div>

        <h2 class="h6 fw-bold mb-3">Profile</h2>
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="headline">Headline</label>
                <input class="form-control" type="text" id="headline" name="headline" value="<?php echo e($form['headline']); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="profile_level">Profile level</label>
                <select class="form-select" id="profile_level" name="profile_level">
                    <option value="basic" <?php echo $form['profile_level'] === 'basic' ? 'selected' : ''; ?>>Basic</option>
                    <option value="skilled" <?php echo $form['profile_level'] === 'skilled' ? 'selected' : ''; ?>>Skilled</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="skills">Skills</label>
                <input class="form-control" type="text" id="skills" name="skills" value="<?php echo e($form['skills']); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold" for="qualification">Qualification</label>
                <input class="form-control" type="text" id="qualification" name="qualification" value="<?php echo e($form['qualification']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="experience_years">Experience (years)</label>
                <input class="form-control" type="number" min="0" step="0.5" id="experience_years" name="experience_years" value="<?php echo e($form['experience_years']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="current_location">Current location</label>
                <input class="form-control" type="text" id="current_location" name="current_location" value="<?php echo e($form['current_location']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" for="preferred_location">Preferred location</label>
                <input class="form-control" type="text" id="preferred_location" name="preferred_location" value="<?php echo e($form['preferred_location']); ?>">
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2">
            <button class="btn btn-admin" type="submit">
                <i class="fa-solid fa-floppy-disk me-2"></i>Save Changes
            </button>
            <a href="users.php?role=job_seeker" class="btn btn-admin-outline">Cancel</a>
        </div>
    </form>
</div>

<div class="admin-panel-card mb-3">
    <h2 class="h6 fw-bold mb-3">Resume</h2>
    <?php if ($hasResume): ?>
        <p class="muted mb-3">
            <i class="fa-solid fa-file-pdf me-1"></i>
            <?php echo e($record['resume_original_name'] ?? 'Resume on file'); ?>
            <?php if ($record['resume_uploaded_at']): ?>
                · Uploaded <?php echo e(date('M j, Y', strtotime($record['resume_uploaded_at']))); ?>
            <?php endif; ?>
        </p>
    <?php else: ?>
        <p class="muted mb-3">No resume uploaded yet.</p>
    <?php endif; ?>

    <form method="post" action="jobseeker-edit.php?id=<?php echo $userId; ?>" enctype="multipart/form-data">
        <?php echo fp_csrf_field(); ?>
        <input type="hidden" name="action" value="resume">
        <div class="row g-3 align-items-end">
            <div class="col-md-8">
                <label class="form-label fw-semibold" for="resume">Upload / replace resume</label>
                <input class="form-control" type="file" id="resume" name="resume" accept=".pdf,.doc,.docx">
            </div>
            <div class="col-md-4">
                <button class="btn btn-admin-outline w-100" type="submit">Upload Resume</button>
            </div>
        </div>
    </form>
</div>

<div class="admin-panel-card border-danger-subtle">
    <h2 class="h6 fw-bold text-danger mb-2">Danger zone</h2>
    <p class="muted small mb-3">Deleting removes this job seeker from the platform. Their applications remain in the database but the account cannot sign in.</p>
    <form method="post" action="jobseeker-edit.php?id=<?php echo $userId; ?>" data-fp-confirm="Permanently delete this job seeker? This cannot be undone.">
        <?php echo fp_csrf_field(); ?>
        <input type="hidden" name="action" value="delete">
        <button class="btn btn-admin-danger" type="submit">
            <i class="fa-solid fa-trash me-2"></i>Delete Job Seeker
        </button>
    </form>
</div>
<?php fp_admin_shell_end(); ?>
